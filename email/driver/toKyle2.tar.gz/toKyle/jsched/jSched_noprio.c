#include <cilk/cilk.h>
#include <cilk/cilk_io.h>
#include <cilk/future.h>
#include <cilk/sync_handle.h>
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/timerfd.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <netdb.h>
#include <sys/un.h>
#include <fcntl.h>
#include <math.h>
#include "../jsched/utils/util.h"
#include "../jsched/utils/arg.h"
#include "../jsched/utils/timing.h"







#define Version "0.1"
#define numFuns 4
#define SIZE_OF_ALPHABETS 4

#define us 1000000
#define ns 1000000000
long ns2=ns;
//SW_STUFF
#define BLOCK_IND_TO_IND(i) (i << base_case_log)
#define NUM_BLOCKS(n) (n >> base_case_log)

static inline int max(int a, int b) { return (a < b) ? b : a; }
static inline int ilog2(int x) { return 32 - __builtin_clz(x) - 1; }
int base_case_log=0;

//MM_STUFF
#define REAL int
static int BASE_CASE; //the base case of the computation (2*POWER)
static int POWER; //the power of two the base case is based on
static const unsigned int Q[] = {0x55555555, 0x33333333, 0x0F0F0F0F, 0x00FF00FF};
static const unsigned int S[] = {1, 2, 4, 8};

//SORT_STUFF
typedef long ELM;
#define KILO 1024
#define MERGESIZE KILO
#define QUICKSIZE KILO
#define INSERTIONSIZE 20
static unsigned long rand_nxt = 0;

#define swap_indices(a, b)			\
  {						\
    ELM *tmp;					\
    tmp = a;					\
    a = b;					\
    b = tmp;					\
  }
#define swap(a, b)				\
  {						\
    ELM tmp;					\
    tmp = a;					\
    a = b;					\
    b = tmp;					\
  }

static inline void my_srand(unsigned long seed) {

  rand_nxt = seed;
}

static inline unsigned long my_rand(void) {

  rand_nxt = rand_nxt * 1103515245 + 12345;
  return rand_nxt;
}

void scramble_array(ELM *arr, unsigned long size) {

  unsigned long i;
  unsigned long j;

  for (i = 0; i < size; ++i) {
    j = my_rand();
    j = j % size;
    long temp=arr[i];
    arr[i]=arr[j];
    arr[j]=temp;

  }
}

void fill_array(ELM *arr, unsigned long size) {

  unsigned long i;


  /* first, fill with integers 1..size */
  for (i = 0; i < size; ++i) {
    arr[i] = i;
  }

  /* then, scramble randomly */
  scramble_array(arr, size);
}


//cilk::future<int>** f_futs;
cilk::future<int>* f_futs0=NULL;
cilk::future<int>* f_futs1=NULL;
cilk::future<int>* f_futs2=NULL;
cilk::future<int>* f_futs3=NULL;

int verbose=0; //verbose (bool)
double fWait[numFuns]={0}; //period for each function
long duration=0; //total duration to run for (seconds)
long requests=0; //amount of items for timing array
int echo=0; //echo back cmdline
int rseed=0; //rand number seed
pthread_barrier_t sBarrier; //barrier so that scheduling doesnt start till all functions ready


//cilk vars
int cilk_quantum_length_us ;
double cilk_rho ;
double cilk_util_bound ;
double cilk_init_desire ;
int cilk_rr_worker_count ;
int cilk_reserved_w_per_lvl ;

//denominator for poisson scheduling
double den=((double)RAND_MAX)+1.0;

static ArgOption args[] = {
  // Kind,        Type,   name,         reqd, variable,                 help
  { KindOption,   Integer,"-v",            0, &verbose,                 "Turn on verbosity (0-2)" },
  { KindOption,   Double, "-f0",           0, &fWait[0],                "Calls to fun0 per sec" },
  { KindOption,   Double, "-f1",           0, &fWait[1],                "Calls to fun1 per sec" },
  { KindOption,   Double, "-f2",           0, &fWait[2],                "Calls to fun2 per sec" },
  { KindOption,   Double, "-f3",           0, &fWait[3],                "Calls to fun3 per sec" },
  { KindOption,   Integer,"--seed",        0, &rseed,                   "random number seed" },
  { KindOption,   Integer,"--duration",    0, &duration,                "Time in seconds to run" },
  { KindOption,   Set,    "--echo",        0, &echo,                    "echo cmdline" },
  { KindOption,   Integer,"--quantlen",    0, &cilk_quantum_length_us,  "cilk_quant_len" },
  { KindOption,   Double, "--cilkrho",     0, &cilk_rho,                "cilkrho" },
  { KindOption,   Double, "--cilkutil",    0, &cilk_util_bound,         "cilk_util_bound" },
  { KindOption,   Double, "--cilkinit",    0, &cilk_init_desire,        "cilk_init_desire" },
  { KindOption,   Integer,"--cilkWrks",    0, &cilk_rr_worker_count,    "cilk_rr_worker_count" },
  { KindOption,   Integer,"--cilkres",     0, &cilk_reserved_w_per_lvl, "cilk_reserved_w_per_lvl" },
  { KindHelp,     Help,    "-h" },
  { KindEnd }
};
static ArgDefs argp = { args, "Job Scheduler Nopriority", Version, NULL };

//turns timeval to us
//t: timeval to convert
suseconds_t to_usecs(struct timeval t) {
  return t.tv_sec * 1000000 + t.tv_usec;
}

//returns difference between two timevals in us
//t1: timeval to subtract from
//t2: timeval whose value is subtracted
long difftimevals(struct timeval t1, struct timeval t2) {
  return (to_usecs(t1) - to_usecs(t2));
}

//SW_FUNCTIONS
__attribute__((unused)) static
void gen_rand_string(char * s, int s_length, int range) {
  for(int i = 0; i < s_length; ++i ) {
    s[i] = (char)(rand() % range + 97);
  }
}


static int 
process_sw_tile(int *stor, char *a, char *b, int n, int iB, int jB) {

  int bSize = 1 << base_case_log;

  for(int i = 0; i < bSize; i++) {
    for(int j = 0; j < bSize; j++) {

      int i_ind = BLOCK_IND_TO_IND(iB) + i;
      int j_ind = BLOCK_IND_TO_IND(jB) + j;

      if(i_ind == 0 || j_ind == 0) {
        stor[i_ind*n + j_ind] = 0;
      } else {
        int max_val = 0;
        for(int k = 1; k < i_ind; k++) {
          max_val = max(stor[k*n + j_ind]-(i_ind-k), max_val);
        }
        for(int k = 1; k < j_ind; k++) {
          max_val = max(stor[i_ind*n + k]-(j_ind-k), max_val);
        }
        stor[i_ind*n + j_ind] = 
          max( stor[(i_ind-1)*n + (j_ind-1)] + (a[i_ind-1]==b[j_ind-1]), 
               max_val );
      }
    }
  }
    
  return 0;
}


void recursive_process_sw_tiles(int *stor, char *a, char *b, int n, int ibase, int start, int end) {
  int count = end - start;
  int mid;
  cilk_enable_spawn_in_this_func();
  while (count > 1) {
    mid = start + count/2;
    cilk_spawn3_void(recursive_process_sw_tiles,stor, a, b, n, ibase, start, mid);
    start = mid;
    count = end - start;
  }
  int iB = ibase - start;
  process_sw_tile(stor, a, b, n, iB, start);
  cilk_sync2();
}

int __attribute__((noinline)) wave_sw_with_futures(int *stor, char *a, char *b, int n) {
  int nBlocks = NUM_BLOCKS(n);
  for(int wave_front = 0; wave_front < nBlocks; wave_front++) {
    recursive_process_sw_tiles(stor, a, b, n, wave_front, 0, wave_front+1);
  }
  for(int wave_front = 1; wave_front < nBlocks; wave_front++) {
    int iBase = nBlocks + wave_front - 1;
    recursive_process_sw_tiles(stor, a, b, n, iBase, wave_front, nBlocks);
  }
  return stor[n*(n-1) + n-1];
}



//FIB_FUNCTIONS
int fib(int n) {
  int x;
  int y;

  if(n < 2) {
    return n;
  }
  cilk_enable_spawn_in_this_func();    
  cilk_spawn3(x,fib,n-1);
  
  y = fib(n - 2);
  cilk_sync2();
  return x+y;
}



//MM_FUNCTIONS
int cilk_rand(void) {
    int result;
    rand_nxt = rand_nxt * 1103515245 + 12345;
    result = (rand_nxt >> 16) % ((unsigned int) RAND_MAX + 1);
    return result;
}

void zero(REAL *M, int n){
    int i;
    for(i = 0; i < n * n; i++) {
        M[i] = 0.0;
    }
}

void init_rm(REAL *M, int n){
    int i;
    for(i = 0; i < n * n; i++) {
        M[i] = (REAL) cilk_rand();
    }
}

unsigned int z_convert(int row, int col){

  unsigned int z; // z gets the resulting 32-bit Morton Number.  
  // x and y must initially be less than 65536.
  // The top and the left boundary 

  col = (col | (col << S[3])) & Q[3];
  col = (col | (col << S[2])) & Q[2];
  col = (col | (col << S[1])) & Q[1];
  col = (col | (col << S[0])) & Q[0];

  row = (row | (row << S[3])) & Q[3];
  row = (row | (row << S[2])) & Q[2];
  row = (row | (row << S[1])) & Q[1];
  row = (row | (row << S[0])) & Q[0];

  z = col | (row << 1);

  return z;
}
int block_convert(int row, int col){
  int block_index = z_convert(row >> POWER, col >> POWER);
  return (block_index * BASE_CASE << POWER) 
    + ((row - ((row >> POWER) << POWER)) << POWER) 
    + (col - ((col >> POWER) << POWER));
}


void mat_mul_par(const REAL *const A, const REAL *const B, REAL *C, int n){
  //BASE CASE: here computation is switched to itterative matrix multiplication
  //At the base case A, B, and C point to row order matrices of n x n
  if(n == BASE_CASE) {
    int i, j, k;
    for(i = 0; i < n; i++){
      for(k = 0; k < n; k++){
	REAL c = 0.0;
	for(j = 0; j < n; j++){
	  c += A[i * n + j] * B[j* n + k];
	}
	C[i * n + k] += c;
      }
    }
    return;
  }
  cilk_enable_spawn_in_this_func();
  //partition each matrix into 4 sub matrices
  //each sub-matrix points to the start of the z pattern
  const REAL *const A1 = &A[block_convert(0,0)];
  const REAL *const A2 = &A[block_convert(0, n >> 1)]; //bit shift to divide by 2
  const REAL *const A3 = &A[block_convert(n >> 1,0)];
  const REAL *const A4 = &A[block_convert(n >> 1, n >> 1)];

  const REAL *const B1 = &B[block_convert(0,0)];
  const REAL *const B2 = &B[block_convert(0, n >> 1)];
  const REAL *const B3 = &B[block_convert(n >> 1, 0)];
  const REAL *const B4 = &B[block_convert(n >> 1, n >> 1)];
    
  REAL *C1 = &C[block_convert(0,0)];
  REAL *C2 = &C[block_convert(0, n >> 1)];
  REAL *C3 = &C[block_convert(n >> 1,0)];
  REAL *C4 = &C[block_convert(n >> 1, n >> 1)];

  //recrusively call the sub-matrices for evaluation in parallel
  cilk_spawn3_void(mat_mul_par,A1, B1, C1, n >> 1);
  cilk_spawn3_void(mat_mul_par,A1, B2, C2, n >> 1);
  cilk_spawn3_void(mat_mul_par,A3, B1, C3, n >> 1);
  mat_mul_par(A3, B2, C4, n >> 1);
  cilk_sync2(); //wait here for first round to finish
  cilk_spawn3_void(mat_mul_par,A2, B3, C1, n >> 1);
  cilk_spawn3_void(mat_mul_par,A2, B4, C2, n >> 1);
  cilk_spawn3_void(mat_mul_par,A4, B3, C3, n >> 1);
  mat_mul_par(A4, B4, C4, n >> 1);
  cilk_sync2(); //wait here for all second round to finish

}

//SORT_FUNCTIONS
static inline ELM med3(ELM a, ELM b, ELM c) {

  if (a < b) {
    if (b < c) {
      return b;
    } else {
      if (a < c)
        return c;
      else
        return a;
    }
  } else {
    if (b > c) {
      return b;
    } else {
      if (a > c)
        return c;
      else
        return a;
    }
  }
}

static inline ELM choose_pivot(ELM *low, ELM *high) {

  return med3(*low, *high, low[(high - low) / 2]);
}
ELM *binsplit(ELM val, ELM *low, ELM *high) {

  /*
   * returns index which contains greatest element <= val.  If val is
   * less than all elements, returns low-1
   */
  ELM *mid;

  while (low != high) {
    mid = low + ((high - low + 1) >> 1);
    if (val <= *mid)
      high = mid - 1;
    else
      low = mid;
  }

  if (*low > val)
    return low - 1;
  else
    return low;
}

static ELM *seqpart(ELM *low, ELM *high) {

  ELM pivot;
  ELM h, l;
  ELM *curr_low = low;
  ELM *curr_high = high;

  pivot = choose_pivot(low, high);

  while (1) {
    while ((h = *curr_high) > pivot)
      curr_high--;

    while ((l = *curr_low) < pivot)
      curr_low++;

    if (curr_low >= curr_high)
      break;

    *curr_high-- = l;
    *curr_low++ = h;
  }

  /*
   * I don't know if this is really necessary.
   * The problem is that the pivot is not always the
   * first element, and the partition may be trivial.
   * However, if the partition is trivial, then
   * *high is the largest element, whence the following
   * code.
   */
  if (curr_high < high)
    return curr_high;
  else
    return curr_high - 1;
}

static void insertion_sort(ELM *low, ELM *high) {

  ELM *p, *q;
  ELM a, b;

  for (q = low + 1; q <= high; ++q) {
    a = q[0];
    for (p = q - 1; p >= low && (b = p[0]) > a; p--)
      p[1] = b;
    p[1] = a;
  }
}

void seqquick(ELM *low, ELM *high) {

  ELM *p;

  while (high - low >= INSERTIONSIZE) {
    p = seqpart(low, high);
    seqquick(low, p);
    low = p + 1;
  }

  insertion_sort(low, high);
}

void seqmerge(ELM *low1, ELM *high1, 
	      ELM *low2, ELM *high2, ELM *lowdest) {

  ELM a1, a2;

  /*
   * The following 'if' statement is not necessary
   * for the correctness of the algorithm, and is
   * in fact subsumed by the rest of the function.
   * However, it is a few percent faster.  Here is why.
   *
   * The merging loop below has something like
   *   if (a1 < a2) {
   *        *dest++ = a1;
   *        ++low1;
   *        if (end of array) break;
   *        a1 = *low1;
   *   }
   *
   * Now, a1 is needed immediately in the next iteration
   * and there is no way to mask the latency of the load.
   * A better approach is to load a1 *before* the end-of-array
   * check; the problem is that we may be speculatively
   * loading an element out of range.  While this is
   * probably not a problem in practice, yet I don't feel
   * comfortable with an incorrect algorithm.  Therefore,
   * I use the 'fast' loop on the array (except for the last 
   * element) and the 'slow' loop for the rest, saving both
   * performance and correctness.
   */

  if (low1 < high1 && low2 < high2) {
    a1 = *low1;
    a2 = *low2;
    for (;;) {
      if (a1 < a2) {
        *lowdest++ = a1;
        a1 = *++low1;
        if (low1 >= high1)
          break;
      } else {
        *lowdest++ = a2;
        a2 = *++low2;
        if (low2 >= high2)
          break;
      }
    }
  }
  if (low1 <= high1 && low2 <= high2) {
    a1 = *low1;
    a2 = *low2;
    for (;;) {
      if (a1 < a2) {
        *lowdest++ = a1;
        ++low1;
        if (low1 > high1)
          break;
        a1 = *low1;
      } else {
        *lowdest++ = a2;
        ++low2;
        if (low2 > high2)
          break;
        a2 = *low2;
      }
    }
  }
  if (low1 > high1) {
    memcpy(lowdest, low2, sizeof(ELM) * (high2 - low2 + 1));
  } else {
    memcpy(lowdest, low1, sizeof(ELM) * (high1 - low1 + 1));
  }
}

void cilkmerge(ELM *low1, ELM *high1, 
	       ELM *low2, ELM *high2, ELM *lowdest) {

  /*
   * Cilkmerge: Merges range [low1, high1] with range [low2, high2] 
   * into the range [lowdest, ...]  
   */

  /*
   * We want to take the middle element (indexed by split1) from the
   * larger of the two arrays.  The following code assumes that split1
   * is taken from range [low1, high1].  So if [low1, high1] is
   * actually the smaller range, we should swap it with [low2, high2] 
   */

  ELM *split1, *split2;	/*
                         * where each of the ranges are broken for 
                         * recursive merge 
                         */
  long int lowsize;		/*
                                 * total size of lower halves of two
                                 * ranges - 2 
                                 */

  if (high2 - low2 > high1 - low1) {
    swap_indices(low1, low2);
    swap_indices(high1, high2);
  }

  if (high1 < low1) {
    /* smaller range is empty */
    memcpy(lowdest, low2, sizeof(ELM) * (high2 - low2));
    return;
  }

  if (high2 - low2 < MERGESIZE) {
    seqmerge(low1, high1, low2, high2, lowdest);
    return;
  }
  /*
   * Basic approach: Find the middle element of one range (indexed by
   * split1). Find where this element would fit in the other range
   * (indexed by split 2). Then merge the two lower halves and the two
   * upper halves. 
   */

  split1 = ((high1 - low1 + 1) / 2) + low1;
  split2 = binsplit(*split1, low2, high2);
  lowsize = split1 - low1 + split2 - low2;

  /* 
   * directly put the splitting element into
   * the appropriate location
   */
  *(lowdest + lowsize + 1) = *split1;
  cilk_enable_spawn_in_this_func();
  cilk_spawn3_void(cilkmerge,low1, split1 - 1, low2, split2, lowdest);
  cilkmerge(split1 + 1, high1, split2 + 1, high2, lowdest + lowsize + 2);
  cilk_sync2();

  return;
}

void cilksort(ELM *low, ELM *tmp, long size) {

  /*
   * divide the input in four parts of the same size (A, B, C, D)
   * Then:
   *   1) recursively sort A, B, C, and D (in parallel)
   *   2) merge A and B into tmp1, and C and D into tmp2 (in parallel)
   *   3) merbe tmp1 and tmp2 into the original array
   */

  long quarter = size / 4;
  ELM *A, *B, *C, *D, *tmpA, *tmpB, *tmpC, *tmpD;

  if (size < QUICKSIZE) {
    /* quicksort when less than 1024 elements */
    seqquick(low, low + size - 1);
    return;
  }

  A = low;
  tmpA = tmp;
  B = A + quarter;
  tmpB = tmpA + quarter;
  C = B + quarter;
  tmpC = tmpB + quarter;
  D = C + quarter;
  tmpD = tmpC + quarter;
  cilk_enable_spawn_in_this_func();
  cilk_spawn3_void(cilksort,A, tmpA, quarter);
  cilk_spawn3_void(cilksort,B, tmpB, quarter);
  cilk_spawn3_void(cilksort,C, tmpC, quarter);
  cilksort(D, tmpD, size - 3 * quarter);
  cilk_sync2();

  cilk_spawn3_void(cilkmerge,A, A + quarter - 1, B, B + quarter - 1, tmpA);
  cilkmerge(C, C + quarter - 1, D, low + size - 1, tmpC);
  cilk_sync2();

  cilkmerge(tmpA, tmpC - 1, tmpC, tmpA + size - 1, A);

  return;
}

//fun0 -> wrapper for sw
int fun0(int index, struct timeval* starts, struct timeval * ends, cilk::future<int>* f,
	 int* stor1, char* a1, char* b1, int n){

  wave_sw_with_futures(stor1, a1, b1, n);
  gettimeofday(&ends[index],NULL);
  free(stor1);
  if(f){
    cilk_future_get(f);
  }
  return 0;
}

//fun1 -> wrapper for fib
int fun1(int index, struct timeval* starts, struct timeval * ends, cilk::future<int>* f,
	 int n){
  fib(n);
  gettimeofday(&ends[index],NULL);
  if(f){
    cilk_future_get(f);
  }
  return 0;
}

//fun2 -> wrapper for mm
int fun2(int index, struct timeval* starts, struct timeval * ends, cilk::future<int>* f,
	 REAL* A,REAL* B,REAL* C,int n){
  mat_mul_par(A,B,C,n);
  gettimeofday(&ends[index],NULL);
  free(C);
  if(f){
    cilk_future_get(f);
  }
  return 0;
}

//fun3 -> wrapper for sort
int fun3(int index, struct timeval* starts, struct timeval * ends, cilk::future<int>* f,
	 ELM* array, ELM* tmp, long size){
  cilksort(array, tmp, size);
  gettimeofday(&ends[index],NULL);
  free(array);
  free(tmp);
  if(f){
    cilk_future_get(f);
  }
  return 0;
}

//gets wait till next time (poisson process)
//rateParameter: wait time
double nextTime(float rateParameter){
  return (double)(-logf(1.0f-((float)random()/den))/rateParameter);
}

//runs a given job wrapper (based on fNum)
//fNum: which function to run
//starts: start time for job
//ends: //end time for job
int runner(int fNum, struct timeval * starts, struct timeval* ends){
  if(verbose){
  printf("Running: %d\n", fNum);
  }
  if(fNum==0){

    //SETUP SW
    int n=1024;
    int bSize=16;
    base_case_log = ilog2(bSize);
    char *a1 = (char *)malloc(n * sizeof(char));
    char *b1 = (char *)malloc(n * sizeof(char));
    /* Generate random inputs; a/b[n-1] not used */
    gen_rand_string(a1, n-1, SIZE_OF_ALPHABETS);
    gen_rand_string(b1, n-1, SIZE_OF_ALPHABETS);
    a1[n-1] = '\0';
    b1[n-1] = '\0';

    pthread_barrier_wait(&sBarrier);
    if(duration){
	struct timeval curT, startT;

	int timerfd = timerfd_create(CLOCK_MONOTONIC,0);
	int old_flags=fcntl(timerfd, F_GETFL,0);
	if(fcntl(timerfd, F_SETFL, old_flags|O_NONBLOCK)<0){
	  fprintf(stderr,"Error setting timer fd\n");
	  fprintf(stderr,"%s\n", strerror(errno));
	  return 0;
	}
      
	struct itimerspec timspec;
      
      	bzero(&timspec, sizeof(timspec));
	timspec.it_interval.tv_sec = 0;
	timspec.it_interval.tv_nsec = 0;
	  long nt=(long)(ns*nextTime((float)fWait[fNum]));
	  long sec = nt/ns;
	  nt=nt-(ns2*sec);
	  if((!sec)&&(!nt)){
	    nt=1;
	  }
	  timspec.it_value.tv_sec = sec;
	  timspec.it_value.tv_nsec = nt;
	
	int res = timerfd_settime(timerfd, 0, &timspec, 0);
	  if(res < 0){
	    perror("timerfd_settime:");
	  }
	uint64_t expirations = 0;
	int i =0;
	gettimeofday(&startT, NULL);
	while( (res = cilk_read_sync(timerfd, (char*)&expirations, sizeof(expirations)))){
	  if(res < 0){ perror("read:"); 
	  gettimeofday(&curT, NULL);
	  if(difftimevals(curT, startT)>=duration){
	    return 0;
	  }
	  continue; }
	  gettimeofday(&curT, NULL);
	  if(difftimevals(curT, startT)>=duration){
	    return 0;
	  }
	  nt=(long)(ns*nextTime((float)fWait[fNum]));
	  sec = nt/ns;
	  nt=nt-(ns2*sec);
	  if((!sec)&&(!nt)){
	    nt=1;
	  }
	  timspec.it_value.tv_sec = sec;
	  timspec.it_value.tv_nsec = nt;

	  res = timerfd_settime(timerfd, 0, &timspec, 0);
	  if(res < 0){
	    perror("timerfd_settime:");
	  }
	  int * stor1 = (int *) malloc(sizeof(int) * n * n);
	  gettimeofday(&starts[i],NULL);
	cilk::future<int>* temp = new cilk::future<int>();
	cilk_future_create(temp, fun0,i, starts, ends,f_futs0,
			   stor1, a1, b1,n);
	f_futs0=temp;
	i++;
      }
    }

  }
  else if(fNum==1){
    int n = 36;
    pthread_barrier_wait(&sBarrier);
        if(duration){
	struct timeval curT, startT;

	int timerfd = timerfd_create(CLOCK_MONOTONIC,0);
	int old_flags=fcntl(timerfd, F_GETFL,0);
	if(fcntl(timerfd, F_SETFL, old_flags|O_NONBLOCK)<0){
	  fprintf(stderr,"Error setting timer fd\n");
	  fprintf(stderr,"%s\n", strerror(errno));
	  return 0;
	}
      
	struct itimerspec timspec;
      
      	bzero(&timspec, sizeof(timspec));
	timspec.it_interval.tv_sec = 0;
	timspec.it_interval.tv_nsec = 0;
	  long nt=(long)(ns*nextTime((float)fWait[fNum]));
	  long sec = nt/ns;
	  nt=nt-(ns2*sec);
	  if((!sec)&&(!nt)){
	    nt=1;
	  }
	  timspec.it_value.tv_sec = sec;
	  timspec.it_value.tv_nsec = nt;
	
	int res = timerfd_settime(timerfd, 0, &timspec, 0);
	  if(res < 0){
	    perror("timerfd_settime:");
	  }
	uint64_t expirations = 0;
	int i =0;
	gettimeofday(&startT, NULL);
	while( (res = cilk_read_sync(timerfd, (char*)&expirations, sizeof(expirations)))){
	  if(res < 0){ perror("read:"); 
	  gettimeofday(&curT, NULL);
	  if(difftimevals(curT, startT)>=duration){
	    return 0;
	  }
	  continue; }
	  gettimeofday(&curT, NULL);
	  if(difftimevals(curT, startT)>=duration){
	    return 0;
	  }
	  nt=(long)(ns*nextTime((float)fWait[fNum]));
	  sec = nt/ns;
	  nt=nt-(ns2*sec);
	  if((!sec)&&(!nt)){
	    nt=1;
	  }
	  timspec.it_value.tv_sec = sec;
	  timspec.it_value.tv_nsec = nt;

	  res = timerfd_settime(timerfd, 0, &timspec, 0);
	  if(res < 0){
	    perror("timerfd_settime:");
	  }
	  gettimeofday(&starts[i],NULL);
	cilk::future<int>* temp = new cilk::future<int>();
	cilk_future_create(temp, fun1,i, starts, ends, f_futs1,
			   n);
	
	f_futs1=temp;
	i++;
      }
    }

  }
  else if(fNum==2){
    int n=1024;
    POWER=6;
    BASE_CASE=1<<POWER;
    REAL *A, *B;

    A = (REAL *) malloc(n * n * sizeof(REAL)); //source matrix 
    B = (REAL *) malloc(n * n * sizeof(REAL)); //source matrix
    init_rm(A, n);
    init_rm(B, n);
    pthread_barrier_wait(&sBarrier);
       if(duration){
	struct timeval curT, startT;

	int timerfd = timerfd_create(CLOCK_MONOTONIC,0);
	int old_flags=fcntl(timerfd, F_GETFL,0);
	if(fcntl(timerfd, F_SETFL, old_flags|O_NONBLOCK)<0){
	  fprintf(stderr,"Error setting timer fd\n");
	  fprintf(stderr,"%s\n", strerror(errno));
	  return 0;
	}
      
	struct itimerspec timspec;
      
      	bzero(&timspec, sizeof(timspec));
	timspec.it_interval.tv_sec = 0;
	timspec.it_interval.tv_nsec = 0;
	  long nt=(long)(ns*nextTime((float)fWait[fNum]));
	  long sec = nt/ns;
	  nt=nt-(ns2*sec);
	  if((!sec)&&(!nt)){
	    nt=1;
	  }
	  timspec.it_value.tv_sec = sec;
	  timspec.it_value.tv_nsec = nt;
	
	int res = timerfd_settime(timerfd, 0, &timspec, 0);
	  if(res < 0){
	    perror("timerfd_settime:");
	  }
	uint64_t expirations = 0;
	int i =0;
	gettimeofday(&startT, NULL);
	while( (res = cilk_read_sync(timerfd, (char*)&expirations, sizeof(expirations)))){
	  if(res < 0){ perror("read:"); 
	  gettimeofday(&curT, NULL);
	  if(difftimevals(curT, startT)>=duration){
	    return 0;
	  }
	  continue; }
	  gettimeofday(&curT, NULL);

	  if(difftimevals(curT, startT)>=duration){
	    return 0;
	  }

	  nt=(long)(ns*nextTime((float)fWait[fNum]));
	  sec = nt/ns;
	  nt=nt-(ns2*sec);
	  if((!sec)&&(!nt)){
	    nt=1;
	  }
	  timspec.it_value.tv_sec = sec;
	  timspec.it_value.tv_nsec = nt;
	  res = timerfd_settime(timerfd, 0, &timspec, 0);
	  if(res < 0){
	    perror("timerfd_settime:");
	  }
	  REAL* C = (REAL *) malloc(n * n * sizeof(REAL)); //result matrix
	  zero(C, n);
	  gettimeofday(&starts[i],NULL);
	  cilk::future<int>* temp = new cilk::future<int>();
	  cilk_future_create(temp, fun2,i, starts, ends,f_futs2,
			     A,B,C,n);
	  //      f_futs[fNum]=temp;
	  f_futs2=temp;
	  
	  i++;
      }
    }

  }
  else{

    
    pthread_barrier_wait(&sBarrier);
       if(duration){
	struct timeval curT, startT;

	int timerfd = timerfd_create(CLOCK_MONOTONIC,0);
	int old_flags=fcntl(timerfd, F_GETFL,0);
	if(fcntl(timerfd, F_SETFL, old_flags|O_NONBLOCK)<0){
	  fprintf(stderr,"Error setting timer fd\n");
	  fprintf(stderr,"%s\n", strerror(errno));
	  return 0;
	}
      
	struct itimerspec timspec;
      
      	bzero(&timspec, sizeof(timspec));
	timspec.it_interval.tv_sec = 0;
	timspec.it_interval.tv_nsec = 0;
	  long nt=(long)(ns*nextTime((float)fWait[fNum]));
	  long sec = nt/ns;
	  nt=nt-(ns2*sec);
	  if((!sec)&&(!nt)){
	    nt=1;
	  }
	  timspec.it_value.tv_sec = sec;
	  timspec.it_value.tv_nsec = nt;
	
	int res = timerfd_settime(timerfd, 0, &timspec, 0);
	  if(res < 0){
	    perror("timerfd_settime:");
	  }
	uint64_t expirations = 0;
	int i =0;
	gettimeofday(&startT, NULL);
	while( (res = cilk_read_sync(timerfd, (char*)&expirations, sizeof(expirations)))){
	  if(res < 0){ perror("read:"); 
	  gettimeofday(&curT, NULL);
	  if(difftimevals(curT, startT)>=duration){
	    return 0;
	  }
	  continue; }
	  gettimeofday(&curT, NULL);
	  if(difftimevals(curT, startT)>=duration){
	    return 0;
	  }
	  nt=(long)(ns*nextTime((float)fWait[fNum]));
	  sec = nt/ns;
	  nt=nt-(ns2*sec);
	  if((!sec)&&(!nt)){
	    nt=1;
	  }
	  timspec.it_value.tv_sec = sec;
	  timspec.it_value.tv_nsec = nt;

	  res = timerfd_settime(timerfd, 0, &timspec, 0);
	  if(res < 0){
	    perror("timerfd_settime:");
	  }
	  long size=11000000;
	  ELM* array = (ELM *) malloc(size * sizeof(ELM));
	  ELM* tmp = (ELM *) malloc(size * sizeof(ELM));
	  fill_array(array, size);
	  scramble_array(array, size);
	  gettimeofday(&starts[i],NULL);
	   cilk::future<int>* temp = new cilk::future<int>();
      cilk_future_create(temp, fun3,i, starts, ends,f_futs3,
			 array, tmp, size);
      f_futs3=temp;

	i++;
      }
    }

  }
  return 0;
}


int main(int argc, char** argv){
  CILK_INITIAL_FUNC_PREAMBLE;
  progname = argv[0];
  ArgParser* ap = createArgumentParser(&argp);
  int ok = parseArguments(ap, argc, argv);
  if (ok) {
    fprintf(stderr,"Error parsing arguments");
    return -1;
  }
  if(verbose){
    printf("rho: %lf, ql: %d, ut: %lf\n",cilk_rho, cilk_quantum_length_us, cilk_util_bound);
  }
  if(echo){
    for(int i =0;i<argc;i++){
      printf("%s ", argv[i]);
    }
    printf("\n");
  }
  if(1!=((!!requests)+(!!duration))){
    fprintf(stderr,"Didnt specify time or calls\n");
    return -1;
  }
  if(duration){
    for(int i =0;i<numFuns;i++){
      requests=max(requests,duration*((int)(1+fWait[i])));
    }
    requests=requests+(requests<<1);
  }
  duration=duration*1000000;
  double fSum=0;
  for(int i =0;i<numFuns;i++){
    fSum+=fWait[i];
  }
  if(!fSum){
    fprintf(stderr,"Nothing to run\n");
    return -1;
  }

  int bFuns=0;
  for(int i =0;i<numFuns;i++){
    if(fWait[i]){
      bFuns++;
    }
  }
  my_srand(1);
  if(rseed){
    srand(rseed);
  }
  else{
  srand(time(NULL));
  }      
  if(pthread_barrier_init(&sBarrier, NULL, bFuns)){
    fprintf(stderr,"Error initializing barrier\n");
    return -1;
  }

  struct timeval ** starts=(struct timeval**)calloc(numFuns, sizeof(struct timeval*));
  struct timeval ** ends=(struct timeval**)calloc(numFuns, sizeof(struct timeval*));
  for(int i =0;i<numFuns;i++){
    starts[i]=(struct timeval*)calloc(requests, sizeof(struct timeval));
    ends[i]=(struct timeval*)calloc(requests, sizeof(struct timeval));
  }


  
  

  cilk::future<int>* t[numFuns];
  for(int i =0;i<numFuns;i++){
    t[i]= new cilk::future<int>();
  }
  for(int i =0;i<numFuns;i++){
    if(fWait[i]){
      cilk_future_create(t[i], runner,i, starts[i], ends[i]);
    }
  }
  for(int i =0;i<numFuns;i++){
    if(fWait[i]){
      if(verbose){
      printf("Waiting on %d\n", i);
      }
      cilk_future_get(t[i]);
      if(verbose){
      printf("got %d\n", i);
      }
    }
  }


  char output[64]="";
  for(int i=0;i<numFuns;i++){
    if(fWait[i]){
    sprintf(output,"jdata_noprio/data%d.txt", i);
    FILE* fp=fopen(output,"a");

    if(echo){
      for(int a =0;a<argc;a++){
	fprintf(fp, "%s ", argv[a]);
      }
    }
    fprintf(fp, "\n");
    unsigned long* h0=(unsigned long*)ends[i], *h1=(unsigned long*)starts[i];
    int tIndex=0;
    while(h0[(tIndex<<1)]&&h0[(tIndex<<1)+1]&&h1[(tIndex<<1)]&&h1[(tIndex<<1)+1]&&tIndex<requests){
      fprintf(fp,"%d %ld us\n",tIndex, difftimevals(ends[i][tIndex],starts[i][tIndex]));
      tIndex++;
    }
    }
  }
  return 0;
  CILK_FUNC_EPILOGUE;
  
}
