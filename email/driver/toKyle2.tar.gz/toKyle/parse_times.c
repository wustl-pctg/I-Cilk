#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include <string.h>

#define nfuns 4
#define bgreq 131072
#define big 750
#define nreqs 150000
#define initSize 131072
#define prio 0
#define noprio 1
#define amt 2


//set from here
#define utils 1 //num util vals tested
#define rho 1 //num rho vals tested
#define nthreads 3 //num of dif thread configs tested (i.e 50 cons, 100 cons)
#define max_threads 180 //highest number of cons tested
#define nqnl 1 //num quant len vals tested

double uVals[utils]={.9}; //util vals
double rVals[rho]={ 2}; //rho vals
int tVals[nthreads]={120,150,180}; //thread vals
int qVals[nqnl]={250}; //quantlen vals
//to here

int ops=1;
typedef struct ev_round{
  int*** events;
  int con;
  int* iters;
  //int amt;
}ev_round;

#define min(X, Y)  ((X) < (Y) ? (X) : (Y))
#define max(X, Y)  ((X) < (Y) ? (Y) : (X))


static int dblcomp(const void* a, const void *b) {
  return *(double*)a - *(double*)b;
}



double
getMedian(double* trialTimes, int trialNumber)
{
  double* tt = calloc(trialNumber, sizeof(double));//mycalloc(trialNumber, sizeof(double));
  memcpy(tt, trialTimes, trialNumber*sizeof(double));
  qsort(tt, trialNumber, sizeof(double), dblcomp);
  double median;
  if (trialNumber & 1) median = tt[trialNumber >> 1];
  else median = ((tt[(trialNumber-1) >> 1] + tt[((trialNumber-1) >> 1)+1])/2.0);
  free(tt);
  return median;
}
double getMean(double* trialTimes, int trialNumber)
{
  double total = 0.0;
  for (int x = 0; x<trialNumber; x++) {
    total += (double)trialTimes[x];
  }
  return total/(double)trialNumber;
}

double
getSD(double* trialTimes, int trialNumber)
{
  double sum = 0.0;
  double mean;
  double sd = 0.0;
  int i;

  for(i=0; i<trialNumber; i++) {
    sum += trialTimes[i];
  }

  mean = sum/(double)trialNumber;

  for(i=0; i<trialNumber; i++)
    sd += pow(trialTimes[i] - mean, 2);

  return sqrt(sd/(trialNumber-1));
}

double 
getMin(double* trialTimes, int trialNumber) {
  double m = trialTimes[0];
  for(int i=0; i<trialNumber; i++)
    if (m > trialTimes[i]) {
      m = trialTimes[i];
    }
  return m;
}


double 
getMax(double* trialTimes, int trialNumber) {
  double m = trialTimes[0];
  for(int i=0; i<trialNumber; i++)
    if (m < trialTimes[i]) m = trialTimes[i];
  return m;
}


static int intcomp(const void* a, const void*b){
  return *(int*)b-*(int*)a;

}
int sumIter(int* iter, int con){
  int sum=0;
  for(int i =0;i<con;i++){
    sum+=iter[i];
  }
  return sum;
}
double getMedianEV(int *** events, int con, int* iter, int evNum){
  int total=sumIter(iter, con);
  int cur=0;
  int * arr=calloc(total, sizeof(int));
  for(int i=0;i<con;i++){
    for(int j=0;j<iter[i];j++){
      arr[cur]=events[i][j][evNum];
      cur++;
    }
  }
  qsort(arr,total, sizeof(int), intcomp);
  for(int i =0;i<total;i++){
    // printf("arr[%d]=%d\n", i, arr[i]);
  }
  int median=0;
  if (total & 1) median = arr[total >> 1];
  else median = (arr[(total-1) >> 1] + arr[((total-1) >> 1)+1])>>1;
  free(arr);
  return (double)median;
}
double getMinEV(int *** events, int con, int* iter, int evNum){
  double ret=2147483648;
  for(int i=0;i<con;i++){
    for(int j=0;j<iter[i];j++){
      ret=min(ret, events[i][j][evNum]);
    }
  }
  return ret;
}
double getMaxEV(int *** events, int con, int* iter, int evNum){
  double ret=0;
  for(int i=0;i<con;i++){
    for(int j=0;j<iter[i];j++){
      ret=max(ret, events[i][j][evNum]);
    }
  }
  return ret;
}
double getAvgEV(int *** events, int con, int* iter, int evNum){
  double sum=0;
  int total=0;
  for(int i=0;i<con;i++){
    for(int j=0;j<iter[i];j++){
      sum+=events[i][j][evNum];
      total++;
    }
  }
  return sum/total;
}

double getStdDevEV(int *** events, int con, int* iter, int evNum){
  double avg=getAvgEV(events, con, iter, evNum);
  double stddev=0.0;
  for(int i =0;i<con;i++){
    for(int j=0;j<iter[i];j++){
      stddev+=pow((double)(events[i][j][evNum]) - avg, 2);
    }
  }
  return sqrt(stddev/(sumIter(iter,con)));
}
/*int summaryEV(ev_round* rounds, int num_rounds){
  for(int i =0;i<num_rounds;i++){
    printf("Round %d: [Con: %d, Iter: %lf, Events: %d]\n", 
	   i,
	   rounds[i].con,
	   (sumIter(rounds[i].iters, rounds[i].con)/((double)rounds[i].con)),
	   rounds[i].amt);
    for(int j=0;j<rounds[i].amt;j++){
      printf("\tEvent[%d]: \n\t\tAverage : %lf us \n\t\tMedian  : %lf us \n\t\tMax     : %lf us \n\t\tMin     : %lf us \n\t\tStdDev  : %lf us\n\n", 
	     j,
	     getAvgEV(rounds[i].events, rounds[i].con, rounds[i].iters, j),
	     getMedianEV(rounds[i].events, rounds[i].con, rounds[i].iters, j),
	     getMaxEV(rounds[i].events, rounds[i].con, rounds[i].iters, j),
	     getMinEV(rounds[i].events, rounds[i].con, rounds[i].iters, j),
	     getStdDevEV(rounds[i].events, rounds[i].con, rounds[i].iters, j));
    }
  }
}

int parse1(char* fname){
  FILE* data=fopen(fname,"r");
  if(!data){
    printf("Bad data file\n");
    return 0;
  }
  char buf[256]="";
  char w1[128]="",w2[128]="";
  int con=0, iter=0, amt=0, time=0;
  ev_round * rounds=calloc(128, sizeof(ev_round)); //stores past rounds of data
  int round_num=0;
  int *** events; //[<con num>][<iterations>][<event id>]
  int * iters;
  while(fgets(buf, 256, data)){
    if(!strncmp(buf, "START", 5)){
      if(sscanf(buf,"%s %d %d %d %s\n", w1,&con,&iter,&amt,w2)!=5){
	printf("Error starting parseing data at: %s\n", buf);
	return 0;
      }
      //      printf("Did start parse data at: %s\n", buf);
      events=calloc(con, sizeof(int**));
      iters=calloc(con, sizeof(int));
      for(int i =0;i<con;i++){
	events[i]=calloc(iter, sizeof(int*));
	for(int j =0;j<iter;j++){
	  events[i][j]=calloc(amt, sizeof(int));
	}
      }
    }
    if(!strncmp(buf, "END", 3)){
      if(sscanf(buf,"%s %d %d %d %s\n", w1,&con,&iter,&amt,w2)!=5){
	printf("Error ending parseing data at: %s\n", buf);
	return 0;
      }
      //      printf("Did end parse data at: %s\n", buf);
      rounds[round_num].events=events;
      rounds[round_num].con=con;
      rounds[round_num].iters=iters;
      rounds[round_num].amt=amt;
      round_num++;
    }
    if(!strncmp(buf, "Event:", 6)){
      if(sscanf(buf,"%s %d %d %d %s %d\n", w1,&con,&iter,&amt,w2, &time)!=6){
	//	printf("Didnt parse data at: %s\n", buf);
      }
      else{
	//	printf("Did parse data at: %s\n", buf);
	iters[con]=iter;
	events[con][iter][amt]=time;
      }
    }
  }
  summaryEV(rounds, round_num);
  return 0;
}

void summary2(double * ctimes, double* htimes, int cindex, int hindex){
  printf("Total Requests: %d\n\tHits  : %d\n\t\tAvg: %lf\n\t\tMed: %lf\n\t\tMin: %lf\n\t\tMax: %lf\n\t\tStd: %lf\n\tMisses: %d\n\t\tAvg: %lf\n\t\tMed: %lf\n\t\tMin: %lf\n\t\tMax: %lf\n\t\tStd: %lf\n", 
	 cindex+hindex, 
	 cindex, 
	 getMean(ctimes, cindex),
	 getMedian(ctimes, cindex),
	 getMin(ctimes, cindex),
	 getMax(ctimes, cindex),
	 getSD(ctimes, cindex),
	 hindex,
	 getMean(htimes, hindex),
	 getMedian(htimes, hindex),
	 getMin(htimes, hindex),
	 getMax(htimes, hindex),
	 getSD(htimes, hindex));

}



void parseTimes2(char* dir){ 
  double* ctimes=calloc(initSize, sizeof(double));
  double* htimes=calloc(initSize, sizeof(double));
  printf("%p %p\n", ctimes, htimes);
  char f[16]="";
  int findex=0;
  char buf[256]="";
  int cindex=0, hindex=0;
  int cresize=0, hresize=0;

  while(1){
    sprintf(f,"%s/out%d.txt", dir,findex);
    FILE* data=fopen(f,"r");
    if(!data){
      break;
    }
    

    char w1=0,w2[4]="",w3[32]="",type=0;
    double val=0;
    while(fgets(buf, 256, data)){
      //      printf("buf: %s\n", buf);
      sscanf(buf,"%c %s %s %c %lf", &type, w2,w3, &w1, &val);
      if(type=='C'){
	ctimes[cindex]=val;
	cindex++;

	if(cindex==(initSize<<cresize)){
	  cresize++;
	  double* narr=calloc(initSize<<cresize, sizeof(double));
	  memcpy(narr, ctimes, (initSize<<(cresize-1))*sizeof(double));
	  free(ctimes);
	  ctimes=narr;
	}


      }
      else if(type=='H'){
	htimes[hindex]=val;
	hindex++;
	if(hindex==(initSize<<hresize)){
	  hresize++;
	  double* narr=calloc(initSize<<hresize, sizeof(double));
	  memcpy(narr, htimes, (initSize<<(hresize-1))*sizeof(double));
	  free(htimes);
	  htimes=narr;
	}
      }
    }
    findex++;
    fclose(data);
  }
  summary2(ctimes, htimes, cindex, hindex);
}




int getThreads(char* line){
  int len=strlen(line);
  for(int i =0;i<len;i++){
    if(!strncmp(line+i, "-t ",3)){
      return atoi(line+i+2);
    }
  }
  return 0;
}

int getRPS(char* line){
  int len=strlen(line);
  for(int i =0;i<len-5;i++){
    if(!strncmp(line+i, "--rps ",3)){
      int index= atoi(line+i+5);
      if(index==250){
	return 0;
      }
      if(index==1000){
	return 1;
      }
    }
  }
  return 2;
}
void printOP(FILE* fp,int i){
  if(i==0){
    fprintf(fp,"Continue");
  }
  else{
    fprintf(fp,"Wait");
  }
}
void printRPS(FILE*fp, int i){
  if(i==0){
    fprintf(fp,"250 ");
  }
  else if(i==1){
    fprintf(fp,"1000");
  }
  else {
    fprintf(fp,"MAX ");
  }
}
void summary(double * hits[ops][speeds][threads],  double * misses[ops][speeds][threads],  int hIndex[ops][speeds][threads],  int mIndex[ops][speeds][threads]){
  FILE* fp=stdout;
  for(int i =0;i<ops;i++){
    printOP(fp, i);
    fprintf(fp,":\n\t");
    for(int j=0;j<speeds;j++){
      fprintf(fp, "RPS: ");
      printRPS(fp, j);
      fprintf(fp,":\n\t\t");
      for(int k=0;k<threads;k++){
	fprintf(fp,"Threads: %d\n\t\t\t", k+1);
	fprintf(fp,"Hits: \n\t\t\t\t");
	fprintf(fp,"Mean:   %lf\n\t\t\t\t", getMean(hits[i][j][k], hIndex[i][j][k]));
	fprintf(fp,"Median: %lf\n\t\t\t\t", getMedian(hits[i][j][k], hIndex[i][j][k]));
	fprintf(fp,"Min   : %lf\n\t\t\t\t", getMin(hits[i][j][k], hIndex[i][j][k]));
	fprintf(fp,"Max   : %lf\n\t\t\t\t", getMax(hits[i][j][k], hIndex[i][j][k]));
	fprintf(fp,"StdDev: %lf\n\t\t\t", getSD(hits[i][j][k], hIndex[i][j][k]));
	fprintf(fp,"Misses : \n\t\t\t\t");
	fprintf(fp,"Mean:   %lf\n\t\t\t\t", getMean(misses[i][j][k], mIndex[i][j][k]));
	fprintf(fp,"Median: %lf\n\t\t\t\t", getMedian(misses[i][j][k], mIndex[i][j][k]));
	fprintf(fp,"Min   : %lf\n\t\t\t\t", getMin(misses[i][j][k], mIndex[i][j][k]));
	fprintf(fp,"Max   : %lf\n\t\t\t\t", getMax(misses[i][j][k], mIndex[i][j][k]));
	fprintf(fp,"StdDev: %lf\n\t\t", getSD(misses[i][j][k], mIndex[i][j][k]));
	


      }
      printf("\n\t");
    }
    printf("\n");
  }
}
void summaryMSP(double * hits[ops][speeds][threads],  double * misses[ops][speeds][threads],  int hIndex[ops][speeds][threads],  int mIndex[ops][speeds][threads], double realRPS[ops][speeds][threads]){
  FILE* fp=stdout;
  for(int i =0;i<ops;i++){
    for(int j=0;j<speeds;j++){
      for(int k=0;k<threads;k++){
	if((hIndex[i][j][k]+mIndex[i][j][k])){
	  fprintf(fp,"%d Requests, %.2lf Requests/Second, %d Thread(s)\n", (k+1)*(nreqs/(k+1)), k+1,realRPS[i][j][k]/((double)(k+1))); 
	  fprintf(fp,"\tRes: Mean Median Min Max StdDev\n");
	  fprintf(fp,"\tHits(%d): %.2lf %.2lf %.2lf %.2lf %.2lf\n",hIndex[i][j][k],
		  getMean(hits[i][j][k], hIndex[i][j][k]),
		  getMedian(hits[i][j][k], hIndex[i][j][k]),
		  getMin(hits[i][j][k], hIndex[i][j][k]),
		  getMax(hits[i][j][k], hIndex[i][j][k]),
		  getSD(hits[i][j][k], hIndex[i][j][k]));
	
	  fprintf(fp,"\tMisses(%d): %.2lf %.2lf %.2lf %.2lf %.2lf\n",mIndex[i][j][k],
		  getMean(misses[i][j][k], mIndex[i][j][k]),
		  getMedian(misses[i][j][k], mIndex[i][j][k]),
		  getMin(misses[i][j][k], mIndex[i][j][k]),
		  getMax(misses[i][j][k], mIndex[i][j][k]),
		  getSD(misses[i][j][k], mIndex[i][j][k]));
	  printf("\n");
	  qsort(hits[i][j][k], hIndex[i][j][k], sizeof(double), dblcomp);
	  hits[i][j][k]=hits[i][j][k]+(hIndex[i][j][k]/20);
	  hIndex[i][j][k]=((hIndex[i][j][k]*18)/20);
	  fprintf(fp,"\tHits(90%): %.2lf %.2lf %.2lf %.2lf %.2lf\n",hIndex[i][j][k],
		  getMean(hits[i][j][k], hIndex[i][j][k]),
		  getMedian(hits[i][j][k], hIndex[i][j][k]),
		  getMin(hits[i][j][k], hIndex[i][j][k]),
		  getMax(hits[i][j][k], hIndex[i][j][k]),
		  getSD(hits[i][j][k], hIndex[i][j][k]));
	  qsort(misses[i][j][k], mIndex[i][j][k], sizeof(double), dblcomp);

	  misses[i][j][k]=misses[i][j][k]+(mIndex[i][j][k]/20);
	  mIndex[i][j][k]=((mIndex[i][j][k]*18)/20);

	  fprintf(fp,"\tMisses(90%): %.2lf %.2lf %.2lf %.2lf %.2lf\n",mIndex[i][j][k],
		  getMean(misses[i][j][k], mIndex[i][j][k]),
		  getMedian(misses[i][j][k], mIndex[i][j][k]),
		  getMin(misses[i][j][k], mIndex[i][j][k]),
		  getMax(misses[i][j][k], mIndex[i][j][k]),
		  getSD(misses[i][j][k], mIndex[i][j][k]));
	}
      }
      fprintf(fp,"\n\n");
    }
  }

}
void summarySP(double * hits[ops][speeds][threads],  double * misses[ops][speeds][threads],  int hIndex[ops][speeds][threads],  int mIndex[ops][speeds][threads], double realRPS[ops][speeds][threads]){
  FILE* fp=stdout;
  for(int i =0;i<ops;i++){
    for(int j=0;j<speeds;j++){
      for(int k=0;k<threads;k++){
	fprintf(fp, "Type: "); 
	printOP(fp, i); 
	fprintf(fp,"(%d Ops), %d Thread(s), ", nreqs, k+1); 
	printRPS(fp,j);
	fprintf(fp,"Requests/Sec");
	if(i){
	  fprintf(fp,"(%.2lf Total -> %.2lf per thread)\n", realRPS[i][j][k], realRPS[i][j][k]/((double)(k+1)));
	}
	else{
	  fprintf(fp,"\n");
	}
	fprintf(fp,"\tRes: Mean Median Min Max StdDev\n");
	fprintf(fp,"\tHits: %.2lf %.2lf %.2lf %.2lf %.2lf\n",
		getMean(hits[i][j][k], hIndex[i][j][k]),
		getMedian(hits[i][j][k], hIndex[i][j][k]),
		getMin(hits[i][j][k], hIndex[i][j][k]),
		getMax(hits[i][j][k], hIndex[i][j][k]),
		getSD(hits[i][j][k], hIndex[i][j][k]));
	fprintf(fp,"\tMisses: %.2lf %.2lf %.2lf %.2lf %.2lf\n",
		getMean(misses[i][j][k], mIndex[i][j][k]),
		getMedian(misses[i][j][k], mIndex[i][j][k]),
		getMin(misses[i][j][k], mIndex[i][j][k]),
		getMax(misses[i][j][k], mIndex[i][j][k]),
		getSD(misses[i][j][k], mIndex[i][j][k]));
      }
      fprintf(fp,"\n\n");
    }
  }
}
void parser4(char* pd){
  int hIndex[ops][speeds][threads]={0};
  int mIndex[ops][speeds][threads]={0};
  double realRPS[ops][speeds][threads]={0};
  double * hits[ops][speeds][threads];
  double * misses[ops][speeds][threads];
  for(int i =0;i<ops;i++){
    for(int j=0;j<speeds;j++){
      for(int k=0;k<threads;k++){
	hits[i][j][k]=calloc(initSize, sizeof(double));
	misses[i][j][k]=calloc(initSize, sizeof(double));
      }
    }
  }
  char dir[64]="";
  char path[64]="";
  char buf[256]="";
  char w1[16],w2[16],w3[16];
  double val=0;
  strcpy(dir, pd);
  for(int i =0;i<threads;i++){

    sprintf(path,"%s/data%d.txt", dir, i);
    FILE* fp=fopen(path, "r");
    int tIndex=0, sIndex=0, wIndex=0;
    while(fgets(buf, 256, fp)){

      if((buf[0]=='.')){
	tIndex=getThreads(buf)-1;
	sIndex=0;//getRPS(buf);
	wIndex=0;//isX(buf,"waitres");
      }
      else if(buf[0]=='R'){
	sscanf(buf, "%s %lf", w1,&val);
	realRPS[wIndex][sIndex][tIndex]=val;
      }
      else if(buf[0]=='H'){
	sscanf(buf, "%s %s %lf %s", w1,w2,&val, w3);
	hits[wIndex][sIndex][tIndex][hIndex[wIndex][sIndex][tIndex]]=val;
	hIndex[wIndex][sIndex][tIndex]++;

      }
      else if(buf[0]=='M'){
	sscanf(buf, "%s %s %lf %s", w1,w2,&val, w3);
	misses[wIndex][sIndex][tIndex][mIndex[wIndex][sIndex][tIndex]]=val;
	mIndex[wIndex][sIndex][tIndex]++;	
      }
    }
  }
  summaryMSP(hits, misses, hIndex, mIndex, realRPS);
}*/
double valToRho(int i){
  return rVals[i];
  /*
  if(i==0){
    return 1.5;
  }
  if(i==1){
    return 1.75;
  }
  return 2.0;*/
}
double valToUtil(int i){
  return uVals[i];
  /*  if(i==0){
    return .75;
  }
  return .9;*/
}
int valToQnl(int i){
  return qVals[i];
  /*  if(i==0){
    return 500;
    }
    return 1000;*/

}

int valToQnl2(int i){
    return 1000;
}
int valToThread(int i){
  return tVals[i];
  /*if(i==0){
    return 90;
  }
  return 120;
  if(i==1){
  return 150;
  }
  return 180;*/
}

void summaryProxy_CMP(double *****hits[2],double ***** misses[2],
		      double ***** hits_size[2],double ***** misses_size[2],
		      int ****hits_index[2],int **** misses_index[2],
		      double ****req_per_sec[2],
		      double **** a_util_arr[2],double **** m_util_arr[2],double **** a_qnl_arr[2],
		      double***** resize_times[2],
		      double***** resize_sizes[2],
		      int****resize_index[2],
		      double***** stat_times[2],
		      double***** stat_sizes[2],
		      int****stat_index[2]){


double * hits_big=calloc(nreqs, sizeof(double));
double * resize_scaled=calloc(big*10, sizeof(double));
 double * stat_scaled=calloc(big*10, sizeof(double));
  double * hits_small=calloc(nreqs, sizeof(double));
  double * hits_scaled=calloc(nreqs, sizeof(double));

  double * misses_big=calloc(nreqs, sizeof(double));
  double * misses_small=calloc(nreqs, sizeof(double));
  double * misses_scaled=calloc(nreqs, sizeof(double));

  for(int i=0;i<nthreads;i++){
    for(int j=0;j<utils;j++){
      for(int k=0;k<rho;k++){
	for(int l=0;l<nqnl;l++){
	int hb=0,hs=0,mb=0, ms=0;
	for(int s =0;s<hits_index[prio][i][j][k][l];s++){
	  if(hits_size[prio][i][j][k][l][s]>big){
	    hits_big[hb]=(hits[prio][i][j][k][l][s])/hits_size[prio][i][j][k][l][s];
	    hb++;
	  }
	  else{
	    hits_small[hs]=(hits[prio][i][j][k][l][s])/hits_size[prio][i][j][k][l][s];
	    hs++;
	  }
	  hits_scaled[s]=(hits[prio][i][j][k][l][s])/hits_size[prio][i][j][k][l][s];
	}
	
	for(int s =0;s<misses_index[prio][i][j][k][l];s++){
	  if(misses_size[prio][i][j][k][l][s]>big){
	    misses_big[mb]=misses[prio][i][j][k][l][s]/misses_size[prio][i][j][k][l][s];
	    mb++;
	  }
	  else{
	    misses_small[ms]=misses[prio][i][j][k][l][s]/misses_size[prio][i][j][k][l][s];
	    ms++;
	  }
	  misses_scaled[s]=misses[prio][i][j][k][l][s]/misses_size[prio][i][j][k][l][s];
	}
	

	
	printf("Clients: %d, Utils: %.2lf, Rho: %.2lf QuanLen: %d\n",
	       valToThread(i), valToUtil(j), valToRho(k), valToQnl(l));
	printf("\t\tAvg_Utils->%.2lf, Max_Utils->%.2lf, Avg_L(us)->%.2lf:\n",
	       a_util_arr[prio][i][j][k][l],
	       m_util_arr[prio][i][j][k][l],
	       a_qnl_arr[prio][i][j][k][l]);
	printf("Hits: %d Misses: %d Errors: %d\n",
	       hits_index[prio][i][j][k][l],
	       misses_index[prio][i][j][k][l],
	       nreqs-(hits_index[prio][i][j][k][l]+misses_index[prio][i][j][k][l]));
	printf("\tPrio:\n");
	printf("\t\tLabel, Mean, Median, Min, Max, SD\n");
	printf("\t\tHits(Raw(us)): %.2lf %.2lf %.2lf %.2lf %.2lf\n",
	       getMean(hits[prio][i][j][k][l], hits_index[prio][i][j][k][l]),
	       getMedian(hits[prio][i][j][k][l],hits_index[prio][i][j][k][l]),
	       getMin(hits[prio][i][j][k][l], hits_index[prio][i][j][k][l]),
	       getMax(hits[prio][i][j][k][l], hits_index[prio][i][j][k][l]),
	       getSD(hits[prio][i][j][k][l], hits_index[prio][i][j][k][l]));
	printf("\t\tHits(Scaled(us/bytes)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(hits_scaled, hits_index[prio][i][j][k][l]),
	       getMedian(hits_scaled,hits_index[prio][i][j][k][l]),
	       getMin(hits_scaled, hits_index[prio][i][j][k][l]),
	       getMax(hits_scaled, hits_index[prio][i][j][k][l]),
	       getSD(hits_scaled, hits_index[prio][i][j][k][l]));
	printf("\t\tHits(>750(us/bytes)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(hits_big, hb),
	       getMedian(hits_big,hb),
	       getMin(hits_big,hb),
	       getMax(hits_big,hb),
	       getSD(hits_big, hb));
	printf("\t\tHits(<=750(us/bytes)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(hits_small, hs),
	       getMedian(hits_small,hs),
	       getMin(hits_small, hs),
	       getMax(hits_small, hs),
	       getSD(hits_small, hs));
	memset(hits_big, 0, nreqs*sizeof(double));
	memset(hits_small, 0, nreqs*sizeof(double));
	memset(hits_scaled, 0, nreqs*sizeof(double));
	hb=0;
	hs=0;
	for(int s =0;s<hits_index[noprio][i][0][0][0];s++){
	  if(hits_size[noprio][i][0][0][0][s]>big){
	    hits_big[hb]=(hits[noprio][i][0][0][0][s])/hits_size[noprio][i][0][0][0][s];
	    hb++;
	  }
	  else{
	    hits_small[hs]=(hits[noprio][i][0][0][0][s])/hits_size[noprio][i][0][0][0][s];
	    hs++;
	  }
	  hits_scaled[s]=(hits[noprio][i][0][0][0][s])/hits_size[noprio][i][0][0][0][s];
	}
	printf("\n");
		printf("\tNoprio:\n");
	printf("\t\tHits(Raw(us)): %.2lf %.2lf %.2lf %.2lf %.2lf\n",
	       getMean(hits[noprio][i][0][0][0], hits_index[noprio][i][0][0][0]),
	       getMedian(hits[noprio][i][0][0][0],hits_index[noprio][i][0][0][0]),
	       getMin(hits[noprio][i][0][0][0], hits_index[noprio][i][0][0][0]),
	       getMax(hits[noprio][i][0][0][0], hits_index[noprio][i][0][0][0]),
	       getSD(hits[noprio][i][0][0][0], hits_index[noprio][i][0][0][0]));
	printf("\t\tHits(Scaled(us/bytes)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(hits_scaled, hits_index[noprio][i][0][0][0]),
	       getMedian(hits_scaled,hits_index[noprio][i][0][0][0]),
	       getMin(hits_scaled, hits_index[noprio][i][0][0][0]),
	       getMax(hits_scaled, hits_index[noprio][i][0][0][0]),
	       getSD(hits_scaled, hits_index[noprio][i][0][0][0]));
	printf("\t\tHits(>750(us/bytes)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(hits_big, hb),
	       getMedian(hits_big,hb),
	       getMin(hits_big,hb),
	       getMax(hits_big,hb),
	       getSD(hits_big, hb));
	printf("\t\tHits(<=750(us/bytes)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(hits_small, hs),
	       getMedian(hits_small,hs),
	       getMin(hits_small, hs),
	       getMax(hits_small, hs),
	       getSD(hits_small, hs));

	       printf("\n");
	printf("\tPrio:\n");
	printf("\t\tMisses(Raw(us)): %.2lf %.2lf %.2lf %.2lf %.2lf\n",
	       getMean(misses[prio][i][j][k][l], misses_index[prio][i][j][k][l]),
	       getMedian(misses[prio][i][j][k][l],misses_index[prio][i][j][k][l]),
	       getMin(misses[prio][i][j][k][l], misses_index[prio][i][j][k][l]),
	       getMax(misses[prio][i][j][k][l], misses_index[prio][i][j][k][l]),
	       getSD(misses[prio][i][j][k][l], misses_index[prio][i][j][k][l]));
	printf("\t\tMisses(Scaled(us/bytes)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(misses_scaled, misses_index[prio][i][j][k][l]),
	       getMedian(misses_scaled,misses_index[prio][i][j][k][l]),
	       getMin(misses_scaled, misses_index[prio][i][j][k][l]),
	       getMax(misses_scaled, misses_index[prio][i][j][k][l]),
	       getSD(misses_scaled, misses_index[prio][i][j][k][l]));
	printf("\t\tMisses(>750(us/bytes)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(misses_big, mb),
	       getMedian(misses_big,mb),
	       getMin(misses_big,mb),
	       getMax(misses_big,mb),
	       getSD(misses_big, mb));
	printf("\t\tMisses(<=750(us/bytes)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(misses_small, ms),
	       getMedian(misses_small,ms),
	       getMin(misses_small, ms),
	       getMax(misses_small, ms),
	       getSD(misses_small, ms));


	memset(misses_big, 0, nreqs*sizeof(double));
	memset(misses_small, 0, nreqs*sizeof(double));
	memset(misses_scaled, 0, nreqs*sizeof(double));
	mb=0;
	ms=0;
	for(int s =0;s<misses_index[noprio][i][0][0][0];s++){
	  if(misses_size[noprio][i][0][0][0][s]>big){
	    misses_big[mb]=(misses[noprio][i][0][0][0][s])/misses_size[noprio][i][0][0][0][s];
	    mb++;
	  }
	  else{
	    misses_small[ms]=(misses[noprio][i][0][0][0][s])/misses_size[noprio][i][0][0][0][s];
	    ms++;
	  }
	  misses_scaled[s]=(misses[noprio][i][0][0][0][s])/misses_size[noprio][i][0][0][0][s];
	}
	printf("\n");
	printf("\tNoprio:\n");
	printf("\t\tMisses(Raw(us)): %.2lf %.2lf %.2lf %.2lf %.2lf\n",
	       getMean(misses[noprio][i][0][0][0], misses_index[noprio][i][0][0][0]),
	       getMedian(misses[noprio][i][0][0][0],misses_index[noprio][i][0][0][0]),
	       getMin(misses[noprio][i][0][0][0], misses_index[noprio][i][0][0][0]),
	       getMax(misses[noprio][i][0][0][0], misses_index[noprio][i][0][0][0]),
	       getSD(misses[noprio][i][0][0][0], misses_index[noprio][i][0][0][0]));
	printf("\t\tMisses(Scaled(us/bytes)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(misses_scaled, misses_index[noprio][i][0][0][0]),
	       getMedian(misses_scaled,misses_index[noprio][i][0][0][0]),
	       getMin(misses_scaled, misses_index[noprio][i][0][0][0]),
	       getMax(misses_scaled, misses_index[noprio][i][0][0][0]),
	       getSD(misses_scaled, misses_index[noprio][i][0][0][0]));
	printf("\t\tMisses(>750(us/bytes)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(misses_big, mb),
	       getMedian(misses_big,mb),
	       getMin(misses_big,mb),
	       getMax(misses_big,mb),
	       getSD(misses_big, mb));
	printf("\t\tMisses(<=750(us/bytes)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(misses_small, ms),
	       getMedian(misses_small,ms),
	       getMin(misses_small, ms),
	       getMax(misses_small, ms),
	       getSD(misses_small, ms));
	int rb=0;
	for(int s =0;s<resize_index[prio][i][j][k][l];s++){
	    resize_scaled[rb]=(resize_times[prio][i][j][k][l][s])/resize_sizes[prio][i][j][k][l][s];
	    rb++;
	  }
	int rb1=rb;
	rb=0;
	for(int s =0;s<stat_index[prio][i][j][k][l];s++){
	  stat_scaled[rb]=(stat_times[prio][i][j][k][l][s])/(stat_sizes[prio][i][j][k][l][s]+1.0);
	    rb++;
	  }
	printf("\n");
	printf("\tPrio:\n");
	printf("\t\tCacheResizing(Scaled(us/size))): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(resize_scaled, rb1),
	       getMedian(resize_scaled,rb1),
	       getMin(resize_scaled,rb1),
	       getMax(resize_scaled,rb1),
	       getSD(resize_scaled, rb1));
	printf("\t\tStatCollection(Scaled(us/size))): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(stat_scaled, rb),
	       getMedian(stat_scaled,rb),
	       getMin(stat_scaled,rb),
	       getMax(stat_scaled,rb),
	       getSD(stat_scaled, rb));
	
	rb=0;
	for(int s =0;s<resize_index[noprio][i][0][0][0];s++){
	    resize_scaled[rb]=(resize_times[noprio][i][0][0][0][s])/resize_sizes[noprio][i][0][0][0][s];
	    rb++;
	  }
	rb1=rb;
	rb=0;
	for(int s =0;s<stat_index[noprio][i][0][0][0];s++){
	  stat_scaled[rb]=(stat_times[noprio][i][0][0][0][s])/(stat_sizes[noprio][i][0][0][0][s]+1.0);
	    rb++;
	  }
		printf("\n");
	printf("\tNoprio:\n");
	printf("\t\tCacheResizing(Scaled(us/size))): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(resize_scaled, rb1),
	       getMedian(resize_scaled,rb1),
	       getMin(resize_scaled,rb1),
	       getMax(resize_scaled,rb1),
	       getSD(resize_scaled, rb1));
	printf("\t\tStatCollection(Scaled(us/size))): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(stat_scaled, rb),
	       getMedian(stat_scaled,rb),
	       getMin(stat_scaled,rb),
	       getMax(stat_scaled,rb),
	       getSD(stat_scaled, rb));

      }
    }
  }
  }
}

int rhoToVal(double i){
  /*  if(i==1.5){
  return 0;
  }
  if(i==1.75){
    return 1;
  }
  return 2;*/
  for(int j =0;j<rho;j++){
    if(rVals[j]==i){
      return j;
    }
  }
  printf("Error: RHO\n");
  exit(0);
}

int qnlToVal(int i){
    for(int j =0;j<nqnl;j++){
    if(qVals[j]==i){
      return j;
    }
  }
  printf("ErrorQNL\n");
  exit(0);
  /*  if(i==500){
    return 0;
  }
  return 1;*/
}

int utilToVal(double i){
    for(int j =0;j<utils;j++){
    if(uVals[j]==i){
      return j;
    }
  }
    printf("Error UTIL: %lf\n", i);
  exit(0);
  /*  if(i==.75){
  return 0;
  }
  return 1;*/
}
int threadToVal(int i){
    for(int j =0;j<nthreads;j++){
    if(tVals[j]==i){
      return j;
    }
  }
  printf("Error\n");
  exit(0);
  /*  if(i==90){
    return 0;
  }
  return 1;
  if(i==150){
    return 1;
  }
  return 2;*/

}
double isX(char* line, const char* x){
  int xlen=strlen(x);
  int llen=strlen(line);
  for(int i =0;i<llen-xlen;i++){
    if(!strncmp(line+i, x, xlen)){
      return (double)atof(line+i+xlen);
    }
  }
  return -1;
}
int isFirst(int i){
  if(i==0||i==90){
    return 1;
  }
  return 0;
  
}
int rewindItr(int i){
  for(int j=0;j<nthreads;j++){
    if(i<tVals[j]){
      return j;
    }
  }
  printf("Error rewind: %d\n", i);
  exit(0);

    //  }
    //  return 3;
}
int parseProxy(char* prio_path, char* noprio_path){

  double**** a_util_arr[amt], ****m_util_arr[amt], ****a_qnl_arr[amt];

  double**** req_per_sec[amt];
  double***** stat_times[amt];
  double***** stat_sizes[amt];
  double***** resize_times[amt];
  double***** resize_sizes[amt];
  double ***** hits[amt];
  double ***** misses[amt];
  double ***** hits_size[amt];
  double ***** misses_size[amt];
  int **** hits_index[amt];
  int **** misses_index[amt];

  int **** stat_index[amt];
  int **** resize_index[amt];
  for(int p=0;p<amt;p++){
    resize_times[p]=calloc(nthreads, sizeof(double****));
    resize_sizes[p]=calloc(nthreads, sizeof(double****));
    stat_times[p]=calloc(nthreads, sizeof(double****));
    stat_sizes[p]=calloc(nthreads, sizeof(double****));
    stat_index[p]=calloc(nthreads, sizeof(int***));
    resize_index[p]=calloc(nthreads, sizeof(int***));
    
    hits[p]=calloc(nthreads,sizeof(double****));
    misses[p]=calloc(nthreads,sizeof(double****));
    hits_size[p]=calloc(nthreads,sizeof(double****));
    misses_size[p]=calloc(nthreads,sizeof(double****));
    hits_index[p]=calloc(nthreads, sizeof(int***));
    misses_index[p]=calloc(nthreads, sizeof(int***));
    

    a_util_arr[p]=calloc(nthreads, sizeof(double***));
    m_util_arr[p]=calloc(nthreads, sizeof(double***));
    a_qnl_arr[p]=calloc(nthreads, sizeof(double***));
    req_per_sec[p]=calloc(nthreads, sizeof(double***));
    for(int i =0;i<nthreads;i++){

          resize_times[p][i]=calloc(utils, sizeof(double***));
    resize_sizes[p][i]=calloc(utils, sizeof(double***));
        stat_times[p][i]=calloc(utils, sizeof(double***));
    stat_sizes[p][i]=calloc(utils, sizeof(double***));
  stat_index[p][i]=calloc(utils, sizeof(int**));
      resize_index[p][i]=calloc(utils, sizeof(int**));

    
      a_util_arr[p][i]=calloc(utils, sizeof(double**));
      m_util_arr[p][i]=calloc(utils, sizeof(double**));
      a_qnl_arr[p][i]=calloc(utils,sizeof(double**));
      req_per_sec[p][i]=calloc(utils,sizeof(double**));
      hits_index[p][i]=calloc(utils, sizeof(int**));
      misses_index[p][i]=calloc(utils, sizeof(int**));
      hits[p][i]=calloc(utils, sizeof(double***));
      misses[p][i]=calloc(utils, sizeof(double***));
      hits_size[p][i]=calloc(utils, sizeof(double***));
      misses_size[p][i]=calloc(utils, sizeof(double***));
      for(int j=0;j<utils;j++){


	resize_times[p][i][j]=calloc(rho, sizeof(double**));
	resize_sizes[p][i][j]=calloc(rho, sizeof(double**));
        stat_times[p][i][j]=calloc(rho, sizeof(double**));
	stat_sizes[p][i][j]=calloc(rho, sizeof(double**));
	stat_index[p][i][j]=calloc(rho, sizeof(int*));
	resize_index[p][i][j]=calloc(rho, sizeof(int*));

	
	a_util_arr[p][i][j]=calloc(rho, sizeof(double*));
	m_util_arr[p][i][j]=calloc(rho, sizeof(double*));
	a_qnl_arr[p][i][j]=calloc(rho,sizeof(double*));
	req_per_sec[p][i][j]=calloc(rho,sizeof(double*));
	

	hits_index[p][i][j]=calloc(rho, sizeof(int*));
	misses_index[p][i][j]=calloc(rho, sizeof(int*));
	hits[p][i][j]=calloc(rho,sizeof(double**));
	misses[p][i][j]=calloc(rho,sizeof(double**));
	hits_size[p][i][j]=calloc(rho,sizeof(double**));
	misses_size[p][i][j]=calloc(rho,sizeof(double**));
	for(int k=0;k<rho;k++){


	stat_index[p][i][j][k]=calloc(nqnl, sizeof(int));
	resize_index[p][i][j][k]=calloc(nqnl, sizeof(int));

	
	a_util_arr[p][i][j][k]=calloc(nqnl, sizeof(double));
	m_util_arr[p][i][j][k]=calloc(nqnl, sizeof(double));
	a_qnl_arr[p][i][j][k]=calloc(nqnl,sizeof(double));
	req_per_sec[p][i][j][k]=calloc(nqnl,sizeof(double));
	

	hits_index[p][i][j][k]=calloc(nqnl, sizeof(int));
	misses_index[p][i][j][k]=calloc(nqnl, sizeof(int));


	 resize_times[p][i][j][k]=calloc(nqnl, sizeof(double*));
	  resize_sizes[p][i][j][k]=calloc(nqnl, sizeof(double*));
	  stat_times[p][i][j][k]=calloc(nqnl, sizeof(double*));
	  stat_sizes[p][i][j][k]=calloc(nqnl, sizeof(double*));

	  
	  hits[p][i][j][k]=calloc(nqnl, sizeof(double*));
	  misses[p][i][j][k]=calloc(nqnl, sizeof(double*));
	  hits_size[p][i][j][k]=calloc(nqnl, sizeof(double*));
	  misses_size[p][i][j][k]=calloc(nqnl, sizeof(double*));
	for(int l=0;l<nqnl;l++){
          resize_times[p][i][j][k][l]=calloc(bgreq, sizeof(double));
	  resize_sizes[p][i][j][k][l]=calloc(bgreq, sizeof(double));
	  stat_times[p][i][j][k][l]=calloc(bgreq, sizeof(double));
	  stat_sizes[p][i][j][k][l]=calloc(bgreq, sizeof(double));

	  
	  hits[p][i][j][k][l]=calloc(nreqs, sizeof(double));
	  misses[p][i][j][k][l]=calloc(nreqs, sizeof(double));
	  hits_size[p][i][j][k][l]=calloc(nreqs, sizeof(double));
	  misses_size[p][i][j][k][l]=calloc(nreqs, sizeof(double));
	}
	}
      }
    }
  }
  char prio_dir[64]="", noprio_dir[64]="";
  char path[128]="", buf[256]="", buf2[256]="";
  double a_util=0,m_util=0,a_qnl=0;
  double val=0, val1=0;
  long req_size=0;
  FILE* d_fp, * u_fp;
  int tIndex=0;
  int uIndex=0;
  int rIndex=0;
  int qIndex=0;
  char w1[16],w2[16],w3[16], w4[16];
  strcpy(prio_dir, prio_path);
  strcpy(noprio_dir, noprio_path);
  sprintf(path,"%s/utils.txt", prio_dir);
  u_fp=fopen(path,"r");
  for(int i=0;i<max_threads;i++){
    sprintf(path,"%s/data%d.txt", prio_dir, i);
    d_fp=fopen(path,"r");
    rewind(u_fp);
    int first=1;
    while(fgets(buf, 256, d_fp)){
      if((buf[0]=='.')){
	if(first){
	  int ufinds=-1;
	  while(ufinds<(rho*utils*nqnl*rewindItr(i))){
	    fgets(buf2, 256, u_fp);
	    if(buf2[0]=='.'){
	      ufinds++;
	    }
	  }

	  //	  fgets(buf2, 256, u_fp);
	  //	  fgets(buf2, 256, u_fp);
	  //	  fgets(buf2, 256, u_fp);
	  //	  fgets(buf2, 256, u_fp);
	  //  printf("%d -> %d: %s\n", i, rewindItr(i),buf2);
	}

	if(!first){
	  fgets(buf2, 256, u_fp);
	  //	  printf("Buf[else2]: %s\n", buf2);
	}
	first=0;
	
	//	printf("Buf: %s\n", buf);
	tIndex=threadToVal((int)(isX(buf,"-t ")));
	//	printf("%d -> %d\n", tIndex, (int)isX(buf,"-t "));
	//	fgets(buf2,256,u_fp);
	//	printf("%d -> %d: %s\n", i, rewindItr(i), buf2);
	//	printf("Buf2: %s\n", buf2);
	uIndex=utilToVal((double)isX(buf2,"--cilkutil"));
	//	printf("%d -> %lf\n", uIndex, isX(buf2,"--cilkutil"));
	rIndex=rhoToVal((double)isX(buf2,"--cilkrho"));
	qIndex=qnlToVal((int)isX(buf2,"--quantlen"));
	if((int)(isX(buf,"-t "))!=(int)(isX(buf2,"--cons "))){
	  printf("Error\n");
	  printf("Buf: %s", buf);
	  printf("Buf2: %s\n", buf2);
	}
	//		printf("[%d][%d][%d][%d][%d]\n", prio, tIndex, uIndex, rIndex, qIndex);
	//	
		

	while(fgets(buf2, 256, u_fp)){
	  //	  printf("WHILE[2]: %s\n", buf2);
	  if(buf2[0]=='S'){
	    //	printf("Buf: %s\n", buf);
	    sscanf(buf2, "%s %lf %lf %s", w1,&val1, &val, w3);
	    stat_times[prio][tIndex][uIndex][rIndex][qIndex][stat_index[prio][tIndex][uIndex][rIndex][qIndex]]=val;
	    stat_sizes[prio][tIndex][uIndex][rIndex][qIndex][stat_index[prio][tIndex][uIndex][rIndex][qIndex]]=val1;
	    //	    printf("[%d][%d][%d][%d][%d][%d]=%lf\n",prio,tIndex,uIndex,rIndex,qIndex,stat_index[prio][tIndex][uIndex][rIndex][qIndex],stat_times[prio][tIndex][uIndex][rIndex][qIndex][stat_index[prio][tIndex][uIndex][rIndex][qIndex]]);
	    stat_index[prio][tIndex][uIndex][rIndex][qIndex]++;

	
      }

      else if(buf2[0]=='R'){

	//	printf("Buf: %s\n", buf);
	sscanf(buf2, "%s %lf %lf %s", w1,&val1, &val, w3);
	resize_times[prio][tIndex][uIndex][rIndex][qIndex][resize_index[prio][tIndex][uIndex][rIndex][qIndex]]=val;
	resize_sizes[prio][tIndex][uIndex][rIndex][qIndex][resize_index[prio][tIndex][uIndex][rIndex][qIndex]]=val1;
	resize_index[prio][tIndex][uIndex][rIndex][qIndex]++;
      }
	
	   
      else if(buf2[0]=='A'){
	a_util_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	//	printf("Here\n");
	fgets(buf2,256,u_fp);
	//	printf("Buf2: %s\n", buf2);
	m_util_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	fgets(buf2,256,u_fp);
	//	printf("Buf2: %s\n", buf2);
	a_qnl_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+10);

	  /*printf("Buf[else]: %s\n", buf2);
	//	fgets(buf2, 256, u_fp);
	fgets(buf2, 256, u_fp);
	printf("Buf[else]: %s\n", buf2);
	fgets(buf2, 256, u_fp);
	printf("Buf[else]: %s\n", buf2);*/
	break;
      }
	}
	   
	//	printf("%d -> %lf\n", rIndex, isX(buf2,"--cilkrho"));
	//	fgets(buf2,256,u_fp);
	//	printf("Buf2: %s -> %lf\n", buf2,(double)atof(buf2+9));
	/*	a_util_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	//	printf("Here\n");
	fgets(buf2,256,u_fp);
	//	printf("Buf2: %s\n", buf2);
	m_util_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	fgets(buf2,256,u_fp);
	//	printf("Buf2: %s\n", buf2);
	a_qnl_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+10);*/
	//	printf("%lf %lf %lf\n",a_util_arr[prio][tIndex][uIndex][rIndex][qIndex],m_util_arr[prio][tIndex][uIndex][rIndex][qIndex],a_qnl_arr[prio][tIndex][uIndex][rIndex][qIndex]);
	//	printf("%d %d %d\n",tIndex, uIndex, rIndex);
	   }
    
      
      else if(buf[0]=='R'){
	//	printf("Buf: %s\n", buf);
	sscanf(buf, "%s %lf", w1,&val);
	req_per_sec[prio][tIndex][uIndex][rIndex][qIndex]=val;
      }
      else if(buf[0]=='H'){
	//	printf("Buf: %s\n", buf);

	sscanf(buf, "%s %s %lf %lf %s", w1,w2,&val1, &val, w3);

	hits[prio][tIndex][uIndex][rIndex][qIndex][hits_index[prio][tIndex][uIndex][rIndex][qIndex]]=val;
	hits_size[prio][tIndex][uIndex][rIndex][qIndex][hits_index[prio][tIndex][uIndex][rIndex][qIndex]]=val1;
	hits_index[prio][tIndex][uIndex][rIndex][qIndex]++;
      }
      else if(buf[0]=='M'){
	//	printf("Buf: %s\n", buf);
	sscanf(buf, "%s %s %lf %lf %s", w1,w2,&val1, &val, w3);
	misses[prio][tIndex][uIndex][rIndex][qIndex][misses_index[prio][tIndex][uIndex][rIndex][qIndex]]=val;
	misses_size[prio][tIndex][uIndex][rIndex][qIndex][misses_index[prio][tIndex][uIndex][rIndex][qIndex]]=val1;
	misses_index[prio][tIndex][uIndex][rIndex][qIndex]++;
      }
      else{
	//	printf("HERE\n");
      }
    }
    fclose(d_fp);
  }

  //    rewind(u_fp);
  sprintf(path,"%s/utils.txt", noprio_dir);
  u_fp=fopen(path,"r");
    for(int i=0;i<max_threads;i++){
      sprintf(path,"%s/data%d.txt", noprio_dir, i);
      d_fp=fopen(path,"r");
          rewind(u_fp);
    int first=1;
    int savePrev=0;
    while(fgets(buf, 256, d_fp)){
      if((buf[0]=='.')){
	if(first){
	  int ufinds=-1;
	  while(ufinds<(rewindItr(i))){
	    fgets(buf2, 256, u_fp);
	    if(buf2[0]=='.'){
	      ufinds++;
	    }
	  }

	  //	  fgets(buf2, 256, u_fp);
	  //	  fgets(buf2, 256, u_fp);
	  //	  fgets(buf2, 256, u_fp);
	  //	  fgets(buf2, 256, u_fp);
	  //  printf("%d -> %d: %s\n", i, rewindItr(i),buf2);
	}
	if(((!first)&&(!savePrev))){
	  fgets(buf2, 256, u_fp);
	}
	savePrev=0;
	first=0;
	
	//	printf("Buf: %s\n", buf);
	tIndex=threadToVal((int)(isX(buf,"-t ")));
	//	printf("%d -> %d\n", tIndex, (int)isX(buf,"-t "));
	//	fgets(buf2,256,u_fp);
	//	printf("%d -> %d: %s\n", i, rewindItr(i), buf2);
	//	printf("Buf2: %s\n", buf2);
	uIndex=0;//utilToVal((double)isX(buf2,"--cilkutil"));
	//	printf("%d -> %lf\n", uIndex, isX(buf2,"--cilkutil"));
	rIndex=0;//rhoToVal((double)isX(buf2,"--cilkrho"));
	qIndex=0;//qnlToVal((int)isX(buf2,"--quantlen"));
	//		printf("[%d][%d][%d][%d][%d]\n", noprio, tIndex, uIndex, rIndex, qIndex);
	//		printf("Buf: %s", buf);
	//			printf("Buf2: %s\n", buf2);
		
	if((int)(isX(buf,"-t "))!=(int)(isX(buf2,"--cons "))){
	  printf("Error\n");
	  printf("Buf: %s", buf);
	  printf("Buf2: %s\n", buf2);
	}
	while(fgets(buf2, 256, u_fp)){
	  //	  printf("WHILE[2]: %s\n", buf2);
	  if(buf2[0]=='S'){
	    //	printf("Buf: %s\n", buf);

	    sscanf(buf2, "%s %lf %lf %s", w1,&val1, &val, w3);
	    stat_times[noprio][tIndex][uIndex][rIndex][qIndex][stat_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val;
	    stat_sizes[noprio][tIndex][uIndex][rIndex][qIndex][stat_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val1;
	    stat_index[noprio][tIndex][uIndex][rIndex][qIndex]++;
	
      }

      else if(buf2[0]=='R'){

	//	printf("Buf: %s\n", buf);
	sscanf(buf2, "%s %lf %lf %s", w1,&val1, &val, w3);
	resize_times[noprio][tIndex][uIndex][rIndex][qIndex][resize_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val;
	resize_sizes[noprio][tIndex][uIndex][rIndex][qIndex][resize_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val1;
	resize_index[noprio][tIndex][uIndex][rIndex][qIndex]++;
      }
	
	   
      else if(buf2[0]=='A'){
	a_util_arr[noprio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	//	printf("Here\n");
	fgets(buf2,256,u_fp);
	//	printf("Buf2: %s\n", buf2);
	m_util_arr[noprio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	fgets(buf2,256,u_fp);
	//	printf("Buf2: %s\n", buf2);
	a_qnl_arr[noprio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+10);

	  /*printf("Buf[else]: %s\n", buf2);
	//	fgets(buf2, 256, u_fp);
	fgets(buf2, 256, u_fp);
	printf("Buf[else]: %s\n", buf2);
	fgets(buf2, 256, u_fp);
	printf("Buf[else]: %s\n", buf2);*/
	break;
      }
      else{
	savePrev=1;
	break;
      }
	}
      }
      else if(buf[0]=='R'){
	//	printf("Buf: %s\n", buf);
	sscanf(buf, "%s %lf", w1,&val);
	req_per_sec[noprio][tIndex][uIndex][rIndex][qIndex]=val;
      }
      else if(buf[0]=='H'){
	//	printf("Buf: %s\n", buf);
	sscanf(buf, "%s %s %lf %lf %s", w1,w2,&val1, &val, w3);
	hits[noprio][tIndex][uIndex][rIndex][qIndex][hits_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val;
	hits_size[noprio][tIndex][uIndex][rIndex][qIndex][hits_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val1;
	hits_index[noprio][tIndex][uIndex][rIndex][qIndex]++;
      }
      else if(buf[0]=='M'){
	//	printf("Buf: %s\n", buf);
	sscanf(buf, "%s %s %lf %lf %s", w1,w2,&val1, &val, w3);
	misses[noprio][tIndex][uIndex][rIndex][qIndex][misses_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val;
	misses_size[noprio][tIndex][uIndex][rIndex][qIndex][misses_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val1;
	misses_index[noprio][tIndex][uIndex][rIndex][qIndex]++;
      }
    }
    }
                summaryProxy_CMP(hits,misses,hits_size,misses_size,hits_index, misses_index,
        			 req_per_sec,a_util_arr, m_util_arr,a_qnl_arr,
        			 resize_times, resize_sizes, resize_index, stat_times, stat_sizes, stat_index);
}
void summaryEmail_CMP(double *****msgs[2],double ***** sorts[2],
		double ***** msgs_size[2],double ***** sorts_size[2],
		int ****msgs_index[2],int **** sorts_index[2],
		double ****req_per_sec[2],
		      double **** a_util_arr[2],double **** m_util_arr[2],double **** a_qnl_arr[2],
		      int ****comp_index[2], double***** comp_times[2]){

  double * msgs_scaled=calloc(nreqs, sizeof(double));
  double * sorts_scaled=calloc(nreqs, sizeof(double));

  for(int i=0;i<nthreads;i++){
    for(int j=0;j<utils;j++){
      for(int k=0;k<rho;k++){
	for(int l=0;l<nqnl;l++){
	for(int s =0;s<msgs_index[prio][i][j][k][l];s++){
	  msgs_scaled[s]=(msgs[prio][i][j][k][l][s])/msgs_size[prio][i][j][k][l][s];
	}
	
	for(int s =0;s<sorts_index[prio][i][j][k][l];s++){
	  sorts_scaled[s]=sorts[prio][i][j][k][l][s]/(log(sorts_size[prio][i][j][k][l][s])*sorts_size[prio][i][j][k][l][s]+1.0);
	}
	

	
	printf("Clients: %d, Utils: %.2lf, Rho: %.2lf, QuanLen: %d\n",
	       valToThread(i), valToUtil(j), valToRho(k), valToQnl(l));
	printf("\t\tAvg_Utils->%.2lf, Max_Utils->%.2lf, Avg_L(us)->%.2lf:\n",
	       a_util_arr[prio][i][j][k][l],
	       m_util_arr[prio][i][j][k][l],
	       a_qnl_arr[prio][i][j][k][l]);
	printf("\tPrio:\n");
	printf("\t\tLabel, Mean, Median, Min, Max, SD\n");
	printf("\t\tMsgs(Raw(us)): %.2lf %.2lf %.2lf %.2lf %.2lf\n",
	       getMean(msgs[prio][i][j][k][l], msgs_index[prio][i][j][k][l]),
	       getMedian(msgs[prio][i][j][k][l],msgs_index[prio][i][j][k][l]),
	       getMin(msgs[prio][i][j][k][l], msgs_index[prio][i][j][k][l]),
	       getMax(msgs[prio][i][j][k][l], msgs_index[prio][i][j][k][l]),
	       getSD(msgs[prio][i][j][k][l], msgs_index[prio][i][j][k][l]));
	printf("\t\tMsgs(Scaled(us/bytes)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(msgs_scaled, msgs_index[prio][i][j][k][l]),
	       getMedian(msgs_scaled,msgs_index[prio][i][j][k][l]),
	       getMin(msgs_scaled, msgs_index[prio][i][j][k][l]),
	       getMax(msgs_scaled, msgs_index[prio][i][j][k][l]),
	       getSD(msgs_scaled, msgs_index[prio][i][j][k][l]));
	memset(msgs_scaled, 0, nreqs*sizeof(double));
	for(int s =0;s<msgs_index[noprio][i][0][0][0];s++){
	  msgs_scaled[s]=(msgs[noprio][i][0][0][0][s])/msgs_size[noprio][i][0][0][0][s];
	}
	printf("\n");
	printf("\tNoprio:\n");
	printf("\t\tMsgs(Raw(us)): %.2lf %.2lf %.2lf %.2lf %.2lf\n",
	       getMean(msgs[noprio][i][0][0][0], msgs_index[noprio][i][0][0][0]),
	       getMedian(msgs[noprio][i][0][0][0],msgs_index[noprio][i][0][0][0]),
	       getMin(msgs[noprio][i][0][0][0], msgs_index[noprio][i][0][0][0]),
	       getMax(msgs[noprio][i][0][0][0], msgs_index[noprio][i][0][0][0]),
	       getSD(msgs[noprio][i][0][0][0], msgs_index[noprio][i][0][0][0]));
	printf("\t\tMsgs(Scaled(us/bytes)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(msgs_scaled, msgs_index[noprio][i][0][0][0]),
	       getMedian(msgs_scaled,msgs_index[noprio][i][0][0][0]),
	       getMin(msgs_scaled, msgs_index[noprio][i][0][0][0]),
	       getMax(msgs_scaled, msgs_index[noprio][i][0][0][0]),
	       getSD(msgs_scaled, msgs_index[noprio][i][0][0][0]));
	
	printf("\n");
	printf("\tPrio:\n");
	printf("\t\tSorts(Raw(us)): %.2lf %.2lf %.2lf %.2lf %.2lf\n",
	       getMean(sorts[prio][i][j][k][l], sorts_index[prio][i][j][k][l]),
	       getMedian(sorts[prio][i][j][k][l],sorts_index[prio][i][j][k][l]),
	       getMin(sorts[prio][i][j][k][l], sorts_index[prio][i][j][k][l]),
	       getMax(sorts[prio][i][j][k][l], sorts_index[prio][i][j][k][l]),
	       getSD(sorts[prio][i][j][k][l], sorts_index[prio][i][j][k][l]));
	printf("\t\tSorts(Scaled(us/len)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(sorts_scaled, sorts_index[prio][i][j][k][l]),
	       getMedian(sorts_scaled,sorts_index[prio][i][j][k][l]),
	       getMin(sorts_scaled, sorts_index[prio][i][j][k][l]),
	       getMax(sorts_scaled, sorts_index[prio][i][j][k][l]),
	       getSD(sorts_scaled, sorts_index[prio][i][j][k][l]));


	memset(sorts_scaled, 0, nreqs*sizeof(double));

	for(int s =0;s<sorts_index[noprio][i][0][0][0];s++){
	  sorts_scaled[s]=(sorts[noprio][i][0][0][0][s])/(log(sorts_size[noprio][i][0][0][0][s])*sorts_size[noprio][i][0][0][0][s]+1.0);
	}
	printf("\n");
		printf("\tNoprio:\n");
	printf("\t\tSorts(Raw(us)): %.2lf %.2lf %.2lf %.2lf %.2lf\n",
	       getMean(sorts[noprio][i][0][0][0], sorts_index[noprio][i][0][0][0]),
	       getMedian(sorts[noprio][i][0][0][0],sorts_index[noprio][i][0][0][0]),
	       getMin(sorts[noprio][i][0][0][0], sorts_index[noprio][i][0][0][0]),
	       getMax(sorts[noprio][i][0][0][0], sorts_index[noprio][i][0][0][0]),
	       getSD(sorts[noprio][i][0][0][0], sorts_index[noprio][i][0][0][0]));
	printf("\t\tSorts(Scaled(us/len)): %.4lf %.4lf %.4lf %.4lf %.4lf\n",
	       getMean(sorts_scaled, sorts_index[noprio][i][0][0][0]),
	       getMedian(sorts_scaled,sorts_index[noprio][i][0][0][0]),
	       getMin(sorts_scaled, sorts_index[noprio][i][0][0][0]),
	       getMax(sorts_scaled, sorts_index[noprio][i][0][0][0]),
	       getSD(sorts_scaled, sorts_index[noprio][i][0][0][0]));
	printf("\n");
	printf("\tPrio:\n");
	printf("\t\tCompress: %.2lf %.2lf %.2lf %.2lf %.2lf\n",
	       getMean(comp_times[prio][i][j][k][l], comp_index[prio][i][j][k][l]),
	       getMedian(comp_times[prio][i][j][k][l],comp_index[prio][i][j][k][l]),
	       getMin(comp_times[prio][i][j][k][l], comp_index[prio][i][j][k][l]),
	       getMax(comp_times[prio][i][j][k][l], comp_index[prio][i][j][k][l]),
	       getSD(comp_times[prio][i][j][k][l], comp_index[prio][i][j][k][l]));
	printf("\n");
	printf("\tNoprio:\n");
	printf("\t\tCompress: %.2lf %.2lf %.2lf %.2lf %.2lf\n",
	       getMean(comp_times[noprio][i][0][0][0], comp_index[noprio][i][0][0][0]),
	       getMedian(comp_times[noprio][i][0][0][0],comp_index[noprio][i][0][0][0]),
	       getMin(comp_times[noprio][i][0][0][0], comp_index[noprio][i][0][0][0]),
	       getMax(comp_times[noprio][i][0][0][0], comp_index[noprio][i][0][0][0]),
	       getSD(comp_times[noprio][i][0][0][0], comp_index[noprio][i][0][0][0]));
	
      }
    }
  }
  }

}
int parseEmail(char* prio_data, char* noprio_data){


    double**** a_util_arr[2], ****m_util_arr[2], ****a_qnl_arr[2];

  double**** req_per_sec[2];
  double***** comp_times[2];
  double ***** msgs[2];
  double ***** sorts[2];
  double ***** msgs_size[2];
  double ***** sorts_size[2];
  int **** msgs_index[2];
  int **** sorts_index[2];

  int **** comp_index[2];


    for(int p=0;p<2;p++){
    comp_times[p]=calloc(nthreads, sizeof(double****));
    comp_index[p]=calloc(nthreads, sizeof(int***));
    
    msgs[p]=calloc(nthreads,sizeof(double****));
    sorts[p]=calloc(nthreads,sizeof(double****));
    msgs_size[p]=calloc(nthreads,sizeof(double****));
    sorts_size[p]=calloc(nthreads,sizeof(double****));
    msgs_index[p]=calloc(nthreads, sizeof(int***));
    sorts_index[p]=calloc(nthreads, sizeof(int***));
    

    a_util_arr[p]=calloc(nthreads, sizeof(double***));
    m_util_arr[p]=calloc(nthreads, sizeof(double***));
    a_qnl_arr[p]=calloc(nthreads, sizeof(double***));
    req_per_sec[p]=calloc(nthreads, sizeof(double***));
    for(int i =0;i<nthreads;i++){

      comp_times[p][i]=calloc(utils, sizeof(double***));
      comp_index[p][i]=calloc(utils, sizeof(int**));

    
      a_util_arr[p][i]=calloc(utils, sizeof(double**));
      m_util_arr[p][i]=calloc(utils, sizeof(double**));
      a_qnl_arr[p][i]=calloc(utils,sizeof(double**));
      req_per_sec[p][i]=calloc(utils,sizeof(double**));
      msgs_index[p][i]=calloc(utils, sizeof(int**));
      sorts_index[p][i]=calloc(utils, sizeof(int**));
      msgs[p][i]=calloc(utils, sizeof(double***));
      sorts[p][i]=calloc(utils, sizeof(double***));
      msgs_size[p][i]=calloc(utils, sizeof(double***));
      sorts_size[p][i]=calloc(utils, sizeof(double***));
      for(int j=0;j<utils;j++){


        comp_times[p][i][j]=calloc(rho, sizeof(double**));
	comp_index[p][i][j]=calloc(rho, sizeof(int*));

	
	a_util_arr[p][i][j]=calloc(rho, sizeof(double*));
	m_util_arr[p][i][j]=calloc(rho, sizeof(double*));
	a_qnl_arr[p][i][j]=calloc(rho,sizeof(double*));
	req_per_sec[p][i][j]=calloc(rho,sizeof(double*));
	

	msgs_index[p][i][j]=calloc(rho, sizeof(int*));
	sorts_index[p][i][j]=calloc(rho, sizeof(int*));
	msgs[p][i][j]=calloc(rho,sizeof(double**));
	sorts[p][i][j]=calloc(rho,sizeof(double**));
	msgs_size[p][i][j]=calloc(rho,sizeof(double**));
	sorts_size[p][i][j]=calloc(rho,sizeof(double**));
	for(int k=0;k<rho;k++){


	comp_index[p][i][j][k]=calloc(nqnl, sizeof(int));

	
	a_util_arr[p][i][j][k]=calloc(nqnl, sizeof(double));
	m_util_arr[p][i][j][k]=calloc(nqnl, sizeof(double));
	a_qnl_arr[p][i][j][k]=calloc(nqnl,sizeof(double));
	req_per_sec[p][i][j][k]=calloc(nqnl,sizeof(double));
	

	msgs_index[p][i][j][k]=calloc(nqnl, sizeof(int));
	sorts_index[p][i][j][k]=calloc(nqnl, sizeof(int));


	  comp_times[p][i][j][k]=calloc(nqnl, sizeof(double*));

	  
	  msgs[p][i][j][k]=calloc(nqnl, sizeof(double*));
	  sorts[p][i][j][k]=calloc(nqnl, sizeof(double*));
	  msgs_size[p][i][j][k]=calloc(nqnl, sizeof(double*));
	  sorts_size[p][i][j][k]=calloc(nqnl, sizeof(double*));
	for(int l=0;l<nqnl;l++){
	  comp_times[p][i][j][k][l]=calloc(bgreq, sizeof(double));

	  
	  msgs[p][i][j][k][l]=calloc(nreqs, sizeof(double));
	  sorts[p][i][j][k][l]=calloc(nreqs, sizeof(double));
	  msgs_size[p][i][j][k][l]=calloc(nreqs, sizeof(double));
	  sorts_size[p][i][j][k][l]=calloc(nreqs, sizeof(double));
	}
	}
      }
    }
  }

  
  char prio_dir[64]="", noprio_dir[64]="";
  char path[128]="", buf[256]="", buf2[256]="";
  double a_util=0,m_util=0,a_qnl=0;
  double val=0, val1=0;
  long req_size=0;
  FILE* d_fp, * u_fp;
  int tIndex=0;
  int uIndex=0;
  int rIndex=0;
  int qIndex=0;
  char w1[16],w2[16],w3[16], w4[16];
  strcpy(prio_dir, prio_data);
  strcpy(noprio_dir, noprio_data);
  sprintf(path,"%s/utils.txt", prio_dir);
  printf("path: %s\n", path);
  u_fp=fopen(path,"r");
  printf("u_fp: %p\n", u_fp);
  int getD=1;
  for(int i=0;i<max_threads;i++){
    sprintf(path,"%s/data%d.txt", prio_dir, i);
    d_fp=fopen(path,"r");
    rewind(u_fp);
    int first=1;
    while(fgets(buf, 256, d_fp)){
      //printf("%s", buf);
      if((buf[0]=='.')){
	if(first){
	  int ufinds=-1;
	  while(ufinds<(rho*utils*nqnl*rewindItr(i))){
	    fgets(buf2, 256, u_fp);
	    //	    printf("Buf[loopxcomp]: %s\n", buf2);
	    if(buf2[0]=='.'){
	      ufinds++;
	    }
	    }

	  /*	  fgets(buf2, 256, u_fp);
	  	  fgets(buf2, 256, u_fp);
	  	  fgets(buf2, 256, u_fp);
	  	  fgets(buf2, 256, u_fp);*/
	  //	    printf("%d -> %d: %s\n", i, rewindItr(i),buf2);
	}

	if(!first){
	  //	  fgets(buf2, 256, u_fp);
	  //	  printf("Buf[else2]: %s\n", buf2);
	}
	first=0;
	
	//		printf("USINGBuf: %s\n", buf2);
	tIndex=threadToVal((int)(isX(buf,"-t ")));
	//	printf("%d -> %d\n", tIndex, (int)isX(buf,"-t "));
	//	fgets(buf2,256,u_fp);
	//	printf("%d -> %d: %s\n", i, rewindItr(i), buf2);
	//	printf("Buf2: %s\n", buf2);
	uIndex=utilToVal((double)isX(buf2,"--cilkutil"));
	//	printf("%d -> %lf\n", uIndex, isX(buf2,"--cilkutil"));
	rIndex=rhoToVal((double)isX(buf2,"--cilkrho"));
	qIndex=qnlToVal((int)isX(buf2,"--quantlen"));
	if(rIndex>=rho||qIndex>=nqnl||uIndex>=utils||tIndex>>nthreads){
	  printf("[%d][%d][%d][%d]\n", tIndex, uIndex, rIndex, qIndex);
	  printf("error\n");
	}
	if((int)(isX(buf,"--seed "))!=(int)(isX(buf2,"--cons "))){
	  printf("Error\n");
	  printf("Buf: %s", buf);
	  printf("Buf2: %s\n", buf2);
	  
	}
	//	printf("[%d][%d][%d][%d]\n", tIndex, uIndex, rIndex, qIndex);
	/*	printf("Buf21: %s\n", buf2);
	fgets(buf2,256,u_fp);
	a_util_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	printf("Buf22: %s\n", buf2);
	fgets(buf2,256,u_fp);

	m_util_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	printf("Buf23: %s\n", buf2);
	fgets(buf2,256,u_fp);
	printf("Buf24: %s\n", buf2);
	a_qnl_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+10);
	fgets(buf2,256,u_fp);*/
	//	printf("[%d][%d][%d][%d][%d]\n", prio, tIndex, uIndex, rIndex, qIndex);
			//		printf("Buf: %s", buf);
			//			printf("Buf2: %s\n", buf2);
		
	//	if(0){
	while(fgets(buf2, 256, u_fp)){
	  //	  printf("WHILE[2]: %s\n", buf2);
	  //  while(1){
	  
	  if(buf2[0]=='C'){
	 	if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //		  printf("start c[%d][%d][%d][%d][%d]: %p %d\n",prio, tIndex, uIndex, rIndex, qIndex, comp_times[prio][tIndex][uIndex][rIndex][qIndex],comp_index[prio][tIndex][uIndex][rIndex][qIndex]);

	}   
	    sscanf(buf2, "%s %s %lf %s", w1, w2,&val, w3);
	    comp_times[prio][tIndex][uIndex][rIndex][qIndex][comp_index[prio][tIndex][uIndex][rIndex][qIndex]]=val;

	    comp_index[prio][tIndex][uIndex][rIndex][qIndex]++;
	 	if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //	  printf("end c\n");
	}   
	
      }
      else if(buf2[0]=='A'){
		if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //	  printf("start a\n");
	}
				if(1){
	a_util_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	//	printf("IN HERE: %s\n", buf2);
	fgets(buf2,256,u_fp);
	//	printf("IN HERE2: %s\n", buf2);
	m_util_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	fgets(buf2,256,u_fp);
	//	printf("IN HERE3: %s\n", buf2);
	a_qnl_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+10);
	fgets(buf2,256,u_fp);
	//	printf("IN HERE4: %s\n", buf2);
	//	fgets(buf2,256,u_fp);
		if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //	  printf("end ma\n");
	}
		}
		else{
	fgets(buf2,256,u_fp);
	//	fgets(buf2,256,u_fp);
	fgets(buf2,256,u_fp);
	fgets(buf2,256,u_fp);
		}
		getD=0;
	break;
      }
	  }
	}
      //}

      else if(buf[0]=='R'){
	if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
	  //	  printf("start r\n");
	}
	sscanf(buf, "%s %lf", w1,&val);
	req_per_sec[prio][tIndex][uIndex][rIndex][qIndex]=val;
		if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //	  printf("end r\n");
	}
      }
      else if(buf[0]=='M'){
		if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //	  printf("start m\n");
	}
	sscanf(buf, "%s %s %lf %s", w1,w2,&val, w3);
	msgs[prio][tIndex][uIndex][rIndex][qIndex][msgs_index[prio][tIndex][uIndex][rIndex][qIndex]]=val;
	msgs_size[prio][tIndex][uIndex][rIndex][qIndex][msgs_index[prio][tIndex][uIndex][rIndex][qIndex]]=strlen(w2);
	msgs_index[prio][tIndex][uIndex][rIndex][qIndex]++;
		if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //	  printf("end m\n");
	}

      }
      else if(buf[0]=='S'){
	if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //	  printf("start s\n");
	}

	sscanf(buf, "%s %lf  %s %lf %s", w1,&val1, w2, &val, w3);
	sorts[prio][tIndex][uIndex][rIndex][qIndex][sorts_index[prio][tIndex][uIndex][rIndex][qIndex]]=val;
	sorts_size[prio][tIndex][uIndex][rIndex][qIndex][sorts_index[prio][tIndex][uIndex][rIndex][qIndex]]=val1;
	sorts_index[prio][tIndex][uIndex][rIndex][qIndex]++;
	
      }
      else{

      }
    }
  }
  getD=1;
  //  printf("HELLO\n");
  rewind(u_fp);
  sprintf(path,"%s/utils.txt", noprio_dir);
  u_fp=fopen(path,"r");
  for(int i=0;i<max_threads;i++){
    sprintf(path,"%s/data%d.txt", noprio_dir, i);
    d_fp=fopen(path,"r");
    rewind(u_fp);
    int first=1;
    int savePrev=0;
    while(fgets(buf, 256, d_fp)){

      if((buf[0]=='.')){
	if(first){
	  int ufinds=-1;
	  while(ufinds<(rewindItr(i))){
	    fgets(buf2, 256, u_fp);
	    if(buf2[0]=='.'){
	      ufinds++;
	    }
	  }

	  //	  fgets(buf2, 256, u_fp);
	  //	  fgets(buf2, 256, u_fp);
	  //	  fgets(buf2, 256, u_fp);
	  //	  fgets(buf2, 256, u_fp);
	  //  printf("%d -> %d: %s\n", i, rewindItr(i),buf2);
	}

	if(((!first)&&(!savePrev))){
	  	  fgets(buf2, 256, u_fp);
	}
	savePrev=0;
	first=0;

	//	printf("Buf: %s\n", buf);
	tIndex=threadToVal((int)(isX(buf,"-t ")));
	//	printf("%d -> %d\n", tIndex, (int)isX(buf,"-t "));
	//	fgets(buf2,256,u_fp);
	//	printf("%d -> %d: %s\n", i, rewindItr(i), buf2);
	//	printf("Buf2: %s\n", buf2);
	uIndex=0;//utilToVal((double)isX(buf2,"--cilkutil"));
	//	printf("%d -> %lf\n", uIndex, isX(buf2,"--cilkutil"));
	rIndex=0;//rhoToVal((double)isX(buf2,"--cilkrho"));
	qIndex=0;//qnlToVal((int)isX(buf2,"--quantlen"));
	//			printf("[%d][%d][%d][%d][%d]\n", noprio, tIndex, uIndex, rIndex, qIndex);
			if((int)(isX(buf,"--seed "))!=(int)(isX(buf2,"--cons "))){
			  printf("Error\n");
			  printf("Buf: %s", buf);
			  printf("Buf2: %s\n", buf2);
	
			}
			fgets(buf2,256,u_fp);
			a_util_arr[noprio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);

			/*	fgets(buf2,256,u_fp);

	m_util_arr[noprio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	fgets(buf2,256,u_fp);
	a_qnl_arr[noprio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+10);
	fgets(buf2,256,u_fp);*/
			//		if(0){			
	while(fgets(buf2, 256, u_fp)){
	  //	  printf("WHILE[2]: %s\n", buf2);
	  if(buf2[0]=='C'){
	    //	    	printf("Buf: %s\n", buf);
	    sscanf(buf2, "%s %s %lf %s", w1, w2,&val, w3);
	    comp_times[noprio][tIndex][uIndex][rIndex][qIndex][comp_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val;
	    comp_index[noprio][tIndex][uIndex][rIndex][qIndex]++;
	
      }
      else if(buf2[0]=='A'){
	if(1){
	a_util_arr[noprio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);

	fgets(buf2,256,u_fp);

	m_util_arr[noprio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	fgets(buf2,256,u_fp);
	a_qnl_arr[noprio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+10);
	}
	getD=0;
	break;
      }
      else{
	savePrev=1;

	//	printf("SBuf: %s\n", buf2);
	break;
      }
	  //	}
      }
      }
    //
      else if(buf[0]=='R'){
	sscanf(buf, "%s %lf", w1,&val);
	req_per_sec[noprio][tIndex][uIndex][rIndex][qIndex]=val;
      }
      else if(buf[0]=='M'){
	sscanf(buf, "%s %s %lf %s", w1,w2,&val, w3);
	msgs[noprio][tIndex][uIndex][rIndex][qIndex][msgs_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val;
	msgs_size[noprio][tIndex][uIndex][rIndex][qIndex][msgs_index[noprio][tIndex][uIndex][rIndex][qIndex]]=strlen(w2);
	msgs_index[noprio][tIndex][uIndex][rIndex][qIndex]++;
      }
      else if(buf[0]=='S'){
	sscanf(buf, "%s %lf  %s %lf %s", w1,&val1, w2, &val, w3);
	sorts[noprio][tIndex][uIndex][rIndex][qIndex][sorts_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val;
	sorts_size[noprio][tIndex][uIndex][rIndex][qIndex][sorts_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val1;

	sorts_index[noprio][tIndex][uIndex][rIndex][qIndex]++;
      }
      else{

      }
    }
  }

      summaryEmail_CMP(msgs,sorts,msgs_size,sorts_size,msgs_index, sorts_index,
  		     req_per_sec,a_util_arr, m_util_arr,a_qnl_arr, comp_index, comp_times);

}



int parseEmail_ncmp(char* prio_data, char* noprio_data){


    double**** a_util_arr[2], ****m_util_arr[2], ****a_qnl_arr[2];

  double**** req_per_sec[2];
  double***** comp_times[2];
  double ***** msgs[2];
  double ***** sorts[2];
  double ***** msgs_size[2];
  double ***** sorts_size[2];
  int **** msgs_index[2];
  int **** sorts_index[2];

  int **** comp_index[2];


    for(int p=0;p<2;p++){
    comp_times[p]=calloc(nthreads, sizeof(double****));
    comp_index[p]=calloc(nthreads, sizeof(int***));
    
    msgs[p]=calloc(nthreads,sizeof(double****));
    sorts[p]=calloc(nthreads,sizeof(double****));
    msgs_size[p]=calloc(nthreads,sizeof(double****));
    sorts_size[p]=calloc(nthreads,sizeof(double****));
    msgs_index[p]=calloc(nthreads, sizeof(int***));
    sorts_index[p]=calloc(nthreads, sizeof(int***));
    

    a_util_arr[p]=calloc(nthreads, sizeof(double***));
    m_util_arr[p]=calloc(nthreads, sizeof(double***));
    a_qnl_arr[p]=calloc(nthreads, sizeof(double***));
    req_per_sec[p]=calloc(nthreads, sizeof(double***));
    for(int i =0;i<nthreads;i++){

      comp_times[p][i]=calloc(utils, sizeof(double***));
      comp_index[p][i]=calloc(utils, sizeof(int**));

    
      a_util_arr[p][i]=calloc(utils, sizeof(double**));
      m_util_arr[p][i]=calloc(utils, sizeof(double**));
      a_qnl_arr[p][i]=calloc(utils,sizeof(double**));
      req_per_sec[p][i]=calloc(utils,sizeof(double**));
      msgs_index[p][i]=calloc(utils, sizeof(int**));
      sorts_index[p][i]=calloc(utils, sizeof(int**));
      msgs[p][i]=calloc(utils, sizeof(double***));
      sorts[p][i]=calloc(utils, sizeof(double***));
      msgs_size[p][i]=calloc(utils, sizeof(double***));
      sorts_size[p][i]=calloc(utils, sizeof(double***));
      for(int j=0;j<utils;j++){


        comp_times[p][i][j]=calloc(rho, sizeof(double**));
	comp_index[p][i][j]=calloc(rho, sizeof(int*));

	
	a_util_arr[p][i][j]=calloc(rho, sizeof(double*));
	m_util_arr[p][i][j]=calloc(rho, sizeof(double*));
	a_qnl_arr[p][i][j]=calloc(rho,sizeof(double*));
	req_per_sec[p][i][j]=calloc(rho,sizeof(double*));
	

	msgs_index[p][i][j]=calloc(rho, sizeof(int*));
	sorts_index[p][i][j]=calloc(rho, sizeof(int*));
	msgs[p][i][j]=calloc(rho,sizeof(double**));
	sorts[p][i][j]=calloc(rho,sizeof(double**));
	msgs_size[p][i][j]=calloc(rho,sizeof(double**));
	sorts_size[p][i][j]=calloc(rho,sizeof(double**));
	for(int k=0;k<rho;k++){


	comp_index[p][i][j][k]=calloc(nqnl, sizeof(int));

	
	a_util_arr[p][i][j][k]=calloc(nqnl, sizeof(double));
	m_util_arr[p][i][j][k]=calloc(nqnl, sizeof(double));
	a_qnl_arr[p][i][j][k]=calloc(nqnl,sizeof(double));
	req_per_sec[p][i][j][k]=calloc(nqnl,sizeof(double));
	

	msgs_index[p][i][j][k]=calloc(nqnl, sizeof(int));
	sorts_index[p][i][j][k]=calloc(nqnl, sizeof(int));


	  comp_times[p][i][j][k]=calloc(nqnl, sizeof(double*));

	  
	  msgs[p][i][j][k]=calloc(nqnl, sizeof(double*));
	  sorts[p][i][j][k]=calloc(nqnl, sizeof(double*));
	  msgs_size[p][i][j][k]=calloc(nqnl, sizeof(double*));
	  sorts_size[p][i][j][k]=calloc(nqnl, sizeof(double*));
	for(int l=0;l<nqnl;l++){
	  comp_times[p][i][j][k][l]=calloc(bgreq, sizeof(double));

	  
	  msgs[p][i][j][k][l]=calloc(nreqs, sizeof(double));
	  sorts[p][i][j][k][l]=calloc(nreqs, sizeof(double));
	  msgs_size[p][i][j][k][l]=calloc(nreqs, sizeof(double));
	  sorts_size[p][i][j][k][l]=calloc(nreqs, sizeof(double));
	}
	}
      }
    }
  }

  
  char prio_dir[64]="", noprio_dir[64]="";
  char path[128]="", buf[256]="", buf2[256]="";
  double a_util=0,m_util=0,a_qnl=0;
  double val=0, val1=0;
  long req_size=0;
  FILE* d_fp, * u_fp;
  int tIndex=0;
  int uIndex=0;
  int rIndex=0;
  int qIndex=0;
  char w1[16],w2[16],w3[16], w4[16];
  strcpy(prio_dir, prio_data);
  strcpy(noprio_dir, noprio_data);
  sprintf(path,"%s/utils.txt", prio_dir);
  printf("path: %s\n", path);
  u_fp=fopen(path,"r");
  printf("u_fp: %p\n", u_fp);
  int getD=1;
  for(int i=0;i<max_threads;i++){
    sprintf(path,"%s/data%d.txt", prio_dir, i);
    d_fp=fopen(path,"r");
    rewind(u_fp);
    int first=1;
    while(fgets(buf, 256, d_fp)){
      //printf("%s", buf);
      if((buf[0]=='.')){
	if(first){
	  int ufinds=-1;
	  while(ufinds<(rho*utils*nqnl*rewindItr(i))){
	    fgets(buf2, 256, u_fp);
	    //	    printf("Buf[loopxcomp]: %s\n", buf2);
	    if(buf2[0]=='.'){
	      ufinds++;
	    }
	    }


	  //	    printf("%d -> %d: %s\n", i, rewindItr(i),buf2);
	}

	if(!first){
	  //	  fgets(buf2, 256, u_fp);
	  //	  printf("Buf[else2]: %s\n", buf2);
	}
	first=0;
	
	//		printf("USINGBuf: %s\n", buf2);
	tIndex=threadToVal((int)(isX(buf,"-t ")));
	//	printf("%d -> %d\n", tIndex, (int)isX(buf,"-t "));
	//	fgets(buf2,256,u_fp);
	//	printf("%d -> %d: %s\n", i, rewindItr(i), buf2);
	//	printf("Buf2: %s\n", buf2);
	uIndex=utilToVal((double)isX(buf2,"--cilkutil"));
	//	printf("%d -> %lf\n", uIndex, isX(buf2,"--cilkutil"));
	rIndex=rhoToVal((double)isX(buf2,"--cilkrho"));
	qIndex=qnlToVal((int)isX(buf2,"--quantlen"));
	if(rIndex>=rho||qIndex>=nqnl||uIndex>=utils||tIndex>>nthreads){
	  printf("[%d][%d][%d][%d]\n", tIndex, uIndex, rIndex, qIndex);
	  printf("error\n");
	}
	if((int)(isX(buf,"--seed "))!=(int)(isX(buf2,"--cons "))){
	  printf("Error\n");
	  printf("Buf: %s", buf);
	  printf("Buf2: %s\n", buf2);
	  
	}
	//	printf("[%d][%d][%d][%d]\n", tIndex, uIndex, rIndex, qIndex);
	//		printf("Buf21: %s\n", buf2);
	fgets(buf2,256,u_fp);
	a_util_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	//	printf("Buf22: %s\n", buf2);
	fgets(buf2,256,u_fp);

	m_util_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	//	printf("Buf23: %s\n", buf2);
	fgets(buf2,256,u_fp);
	//	printf("Buf24: %s\n", buf2);
	a_qnl_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+10);
	fgets(buf2,256,u_fp);
	//	printf("[%d][%d][%d][%d][%d]\n", prio, tIndex, uIndex, rIndex, qIndex);
			//		printf("Buf: %s", buf);
			//			printf("Buf2: %s\n", buf2);
		
	//	if(0){
	/*	while(fgets(buf2, 256, u_fp)){
	  //	  printf("WHILE[2]: %s\n", buf2);
	  //  while(1){
	  
	  if(buf2[0]=='C'){
	 	if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //		  printf("start c[%d][%d][%d][%d][%d]: %p %d\n",prio, tIndex, uIndex, rIndex, qIndex, comp_times[prio][tIndex][uIndex][rIndex][qIndex],comp_index[prio][tIndex][uIndex][rIndex][qIndex]);

	}   
	    sscanf(buf2, "%s %s %lf %s", w1, w2,&val, w3);
	    comp_times[prio][tIndex][uIndex][rIndex][qIndex][comp_index[prio][tIndex][uIndex][rIndex][qIndex]]=val;

	    comp_index[prio][tIndex][uIndex][rIndex][qIndex]++;
	 	if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //	  printf("end c\n");
	}   
	
      }
      else if(buf2[0]=='A'){
		if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //	  printf("start a\n");
	}
				if(1){
	a_util_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	//	printf("IN HERE: %s\n", buf2);
	fgets(buf2,256,u_fp);
	//	printf("IN HERE2: %s\n", buf2);
	m_util_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	fgets(buf2,256,u_fp);
	//	printf("IN HERE3: %s\n", buf2);
	a_qnl_arr[prio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+10);
	fgets(buf2,256,u_fp);
	//	printf("IN HERE4: %s\n", buf2);
	//	fgets(buf2,256,u_fp);
		if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //	  printf("end ma\n");
	}
		}
		else{
	fgets(buf2,256,u_fp);
	//	fgets(buf2,256,u_fp);
	fgets(buf2,256,u_fp);
	fgets(buf2,256,u_fp);
		}
		getD=0;
	break;
      }
	  }
	}
	//}*/
      }

      else if(buf[0]=='R'){
	if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
	  //	  printf("start r\n");
	}
	sscanf(buf, "%s %lf", w1,&val);
	req_per_sec[prio][tIndex][uIndex][rIndex][qIndex]=val;
		if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //	  printf("end r\n");
	}
      }
      else if(buf[0]=='M'){
		if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //	  printf("start m\n");
	}
	sscanf(buf, "%s %s %lf %s", w1,w2,&val, w3);
	msgs[prio][tIndex][uIndex][rIndex][qIndex][msgs_index[prio][tIndex][uIndex][rIndex][qIndex]]=val;
	msgs_size[prio][tIndex][uIndex][rIndex][qIndex][msgs_index[prio][tIndex][uIndex][rIndex][qIndex]]=strlen(w2);
	msgs_index[prio][tIndex][uIndex][rIndex][qIndex]++;
		if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //	  printf("end m\n");
	}

      }
      else if(buf[0]=='S'){
	if(tIndex==0&&qIndex==0&&rIndex==1&&uIndex==0){
		  //	  printf("start s\n");
	}

	sscanf(buf, "%s %lf  %s %lf %s", w1,&val1, w2, &val, w3);
	sorts[prio][tIndex][uIndex][rIndex][qIndex][sorts_index[prio][tIndex][uIndex][rIndex][qIndex]]=val;
	sorts_size[prio][tIndex][uIndex][rIndex][qIndex][sorts_index[prio][tIndex][uIndex][rIndex][qIndex]]=val1;
	sorts_index[prio][tIndex][uIndex][rIndex][qIndex]++;
	
      }
      else{

      }
    }
  }
  getD=1;
  //  printf("HELLO\n");
  rewind(u_fp);
  sprintf(path,"%s/utils.txt", noprio_dir);
  u_fp=fopen(path,"r");
  for(int i=0;i<max_threads;i++){
    sprintf(path,"%s/data%d.txt", noprio_dir, i);
    d_fp=fopen(path,"r");
    rewind(u_fp);
    int first=1;
    int savePrev=0;
    while(fgets(buf, 256, d_fp)){

      if((buf[0]=='.')){
	if(first){
	  int ufinds=-1;
	  while(ufinds<(rewindItr(i))){
	    fgets(buf2, 256, u_fp);
	    if(buf2[0]=='.'){
	      ufinds++;
	    }
	  }

	  //	  fgets(buf2, 256, u_fp);
	  //	  fgets(buf2, 256, u_fp);
	  //	  fgets(buf2, 256, u_fp);
	  //	  fgets(buf2, 256, u_fp);
	  //  printf("%d -> %d: %s\n", i, rewindItr(i),buf2);
	}

	if(((!first)&&(!savePrev))){
	  //	  fgets(buf2, 256, u_fp);
	}
	savePrev=0;
	first=0;

	//	printf("Buf: %s\n", buf);
	tIndex=threadToVal((int)(isX(buf,"-t ")));
	//	printf("%d -> %d\n", tIndex, (int)isX(buf,"-t "));
	//	fgets(buf2,256,u_fp);
	//	printf("%d -> %d: %s\n", i, rewindItr(i), buf2);
	//	printf("Buf2: %s\n", buf2);
	uIndex=0;//utilToVal((double)isX(buf2,"--cilkutil"));
	//	printf("%d -> %lf\n", uIndex, isX(buf2,"--cilkutil"));
	rIndex=0;//rhoToVal((double)isX(buf2,"--cilkrho"));
	qIndex=0;//qnlToVal((int)isX(buf2,"--quantlen"));
	//			printf("[%d][%d][%d][%d][%d]\n", noprio, tIndex, uIndex, rIndex, qIndex);
			if((int)(isX(buf,"--seed "))!=(int)(isX(buf2,"--cons "))){
			  printf("Error\n");
			  printf("Buf: %s", buf);
			  printf("Buf2: %s\n", buf2);
	
			}
			fgets(buf2,256,u_fp);
			/*a_util_arr[noprio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);

				fgets(buf2,256,u_fp);

					m_util_arr[noprio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	fgets(buf2,256,u_fp);
	a_qnl_arr[noprio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+10);
	fgets(buf2,256,u_fp);*/
	/*
			//		if(0){			
	while(fgets(buf2, 256, u_fp)){
	  //	  printf("WHILE[2]: %s\n", buf2);
	  if(buf2[0]=='C'){
	    //	    	printf("Buf: %s\n", buf);
	    sscanf(buf2, "%s %s %lf %s", w1, w2,&val, w3);
	    comp_times[noprio][tIndex][uIndex][rIndex][qIndex][comp_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val;
	    comp_index[noprio][tIndex][uIndex][rIndex][qIndex]++;
	
      }
      else if(buf2[0]=='A'){
	if(1){
	a_util_arr[noprio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);

	fgets(buf2,256,u_fp);

	m_util_arr[noprio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	fgets(buf2,256,u_fp);
	a_qnl_arr[noprio][tIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+10);
	}
	getD=0;
	break;
      }
      else{
	savePrev=1;

	//	printf("SBuf: %s\n", buf2);
	break;
      }
	  //	}
	  }*/
      }
    //
      else if(buf[0]=='R'){
	sscanf(buf, "%s %lf", w1,&val);
	req_per_sec[noprio][tIndex][uIndex][rIndex][qIndex]=val;
      }
      else if(buf[0]=='M'){
	sscanf(buf, "%s %s %lf %s", w1,w2,&val, w3);
	msgs[noprio][tIndex][uIndex][rIndex][qIndex][msgs_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val;
	msgs_size[noprio][tIndex][uIndex][rIndex][qIndex][msgs_index[noprio][tIndex][uIndex][rIndex][qIndex]]=strlen(w2);
	msgs_index[noprio][tIndex][uIndex][rIndex][qIndex]++;
      }
      else if(buf[0]=='S'){
	sscanf(buf, "%s %lf  %s %lf %s", w1,&val1, w2, &val, w3);
	sorts[noprio][tIndex][uIndex][rIndex][qIndex][sorts_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val;
	sorts_size[noprio][tIndex][uIndex][rIndex][qIndex][sorts_index[noprio][tIndex][uIndex][rIndex][qIndex]]=val1;

	sorts_index[noprio][tIndex][uIndex][rIndex][qIndex]++;
      }
      else{

      }
    }
  }

      summaryEmail_CMP(msgs,sorts,msgs_size,sorts_size,msgs_index, sorts_index,
  		     req_per_sec,a_util_arr, m_util_arr,a_qnl_arr, comp_index, comp_times);

}
int funToVal(double i){
  if(i==2){
    return 0;
  }
  if(i==3){
    return 1;
  }
  return 0;
}
double valToFun(int i){
  if(i==0){
    return 5;
  }
  //  if(i==1){
  //    return 3;
  //  }
  return 5;
  //  return 4;
}
void funName(int i){
  if(i==0){
    printf("Low->SW(1024, 16):");
  }
  if(i==1){
    printf("MedHigh->Fib(36):");
  }
    if(i==2){
    printf("High->MM(1024,64):");
  }
    if(i==3){
    printf("MedLow->Sort(1.1*10^7):");
  }
}
int summaryJsched_CMP(double***** f0[2][nfuns], int**** f0_index[2][nfuns],
		  double**** a_util_arr[2], double ****m_util_arr[2], double ****a_qnl_arr[2]){


      for(int j=0;j<utils;j++){
	for(int k=0;k<rho;k++){
	  for(int l=0;l<nqnl;l++){
	    for(int i=0;i<ops;i++){
	      printf("\nUtils: %.2lf, Rho: %.2lf, QuanLen: %d, Jobs/Sec: %lf\n",
		     valToUtil(j), valToRho(k), valToQnl(l),valToFun(i));
	      printf("\t\tAvg_Utils->%.2lf, Max_Utils->%.2lf, Avg_L(us)->%.2lf:\n",
		     a_util_arr[prio][i][j][k][l],
		     m_util_arr[prio][i][j][k][l],
		     a_qnl_arr[prio][i][j][k][l]);

	      for(int f=0;f<nfuns;f++){
	      //
		printf("\n\t");
		funName(f);
		printf("Prio:\n");
		printf("\t\tLabel, Mean, Median, Min, Max, SD\n");
		printf("\t\tTime(ms): %.2lf %.2lf %.2lf %.2lf %.2lf\n",
		   getMean(f0[prio][f][i][j][k][l], f0_index[prio][f][i][j][k][l]),
		   getMedian(f0[prio][f][i][j][k][l],f0_index[prio][f][i][j][k][l]),
		   getMin(f0[prio][f][i][j][k][l], f0_index[prio][f][i][j][k][l]),
		   getMax(f0[prio][f][i][j][k][l], f0_index[prio][f][i][j][k][l]),
		   getSD(f0[prio][f][i][j][k][l], f0_index[prio][f][i][j][k][l]));
		printf("\n\t");
		funName(f);
		printf("Noprio:\n");
		printf("\t\tTime(ms): %.2lf %.2lf %.2lf %.2lf %.2lf\n",
		   getMean(f0[noprio][f][i][0][0][0], f0_index[noprio][f][i][0][0][0]),
		   getMedian(f0[noprio][f][i][0][0][0],f0_index[noprio][f][i][0][0][0]),
		   getMin(f0[noprio][f][i][0][0][0], f0_index[noprio][f][i][0][0][0]),
		   getMax(f0[noprio][f][i][0][0][0], f0_index[noprio][f][i][0][0][0]),
		   getSD(f0[noprio][f][i][0][0][0], f0_index[noprio][f][i][0][0][0]));
		
	}
      }
    }
  }
}
  

}

void parseJobs(char* prio_path, char* noprio_path){
      double**** a_util_arr[2], ****m_util_arr[2], ****a_qnl_arr[2];

  double**** req_per_sec[2];
  double***** f0[2][nfuns];
  int**** f0_index[2][nfuns];





  for(int f=0;f<nfuns;f++){
    for(int p=0;p<2;p++){
      a_util_arr[p]=calloc(ops, sizeof(double***));
      m_util_arr[p]=calloc(ops, sizeof(double***));
      a_qnl_arr[p]=calloc(ops, sizeof(double***));
      
      f0[p][f]=calloc(ops, sizeof(double****));
      f0_index[p][f]=calloc(ops, sizeof(int***));
    for(int i =0;i<ops;i++){
      a_util_arr[p][i]=calloc(utils, sizeof(double**));
      m_util_arr[p][i]=calloc(utils, sizeof(double**));
      a_qnl_arr[p][i]=calloc(utils,sizeof(double**));	
      
      f0[p][f][i]=calloc(utils, sizeof(double***));
      f0_index[p][f][i]=calloc(utils, sizeof(int**));
      for(int j=0;j<utils;j++){
	a_util_arr[p][i][j]=calloc(rho, sizeof(double*));
	m_util_arr[p][i][j]=calloc(rho, sizeof(double*));
	a_qnl_arr[p][i][j]=calloc(rho,sizeof(double*));	
	
	f0[p][f][i][j]=calloc(rho, sizeof(double**));
	f0_index[p][f][i][j]=calloc(rho, sizeof(int*));
	for(int k=0;k<rho;k++){
	  a_util_arr[p][i][j][k]=calloc(nqnl, sizeof(double));
	  m_util_arr[p][i][j][k]=calloc(nqnl, sizeof(double));
	  a_qnl_arr[p][i][j][k]=calloc(nqnl,sizeof(double));
	  
	  f0[p][f][i][j][k]=calloc(nqnl, sizeof(double*));
	  f0_index[p][f][i][j][k]=calloc(nqnl, sizeof(int));
	  for(int l=0;l<nqnl;l++){
	    f0[p][f][i][j][k][l]=calloc(nreqs, sizeof(double));
	  }
	}
      }
    }
  }
  }
  
  char prio_dir[64]="", noprio_dir[64]="";
  char path[128]="", buf[256]="", buf2[256]="";
  double a_util=0,m_util=0,a_qnl=0;
  double val=0, val1=0;
  long req_size=0;
  FILE* d_fp, * u_fp;
  int oIndex=0;
  int uIndex=0;
  int rIndex=0;
  int qIndex=0;
  char w1[16],w2[16],w3[16], w4[16];
  strcpy(prio_dir, prio_path);
  strcpy(noprio_dir, noprio_path);
  sprintf(path,"%s/utils.txt", prio_dir);
  u_fp=fopen(path,"r");
  for(int i=0;i<nfuns;i++){
    sprintf(path,"%s/data%d.txt", prio_dir, i);
    d_fp=fopen(path,"r");
    rewind(u_fp);
    int first=1;
    
    while(fgets(buf, 256, d_fp)){
      if((buf[0]=='.')){
	if(first){
	  int ufinds=0;
	  while(ufinds<(rho*utils*nqnl*rewindItr(i))){
	    fgets(buf2, 256, u_fp);
	    if(buf2[0]=='.'){
	      ufinds++;
	    }
	  }
	}

	if(!first){
	  fgets(buf2, 256, u_fp);
	}
	first=0;

	oIndex=0;//funToVal((double)(isX(buf,"-f0 ")));
	uIndex=0;//utilToVal((double)isX(buf2,"--cilkutil"));
	rIndex=0;//rhoToVal((double)isX(buf2,"--cilkrho"));
	qIndex=0;//qnlToVal2((int)isX(buf2,"--quantlen"));
	if((double)isX(buf2,"--cilkutil")!=(double)isX(buf,"--cilkutil")){
	  printf("Error1\n");
	}
	if((double)isX(buf2,"--cilkrho")!=(double)isX(buf,"--cilkrho")){
	  printf("Error1\n");
	}
	if((double)isX(buf2,"--quantlen")!=(double)isX(buf,"--quantlen")){
	  printf("Error1\n");
	}
	//	printf("[%d][%d][%d][%d][%d]\n", prio, oIndex, uIndex, rIndex, qIndex);

		

	fgets(buf2, 256, u_fp);
	a_util_arr[prio][oIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);

	fgets(buf2,256,u_fp);

	m_util_arr[prio][oIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+9);
	fgets(buf2,256,u_fp);
	a_qnl_arr[prio][oIndex][uIndex][rIndex][qIndex]=(double)atof(buf2+10);
      }
      else{
	sscanf(buf,"%s %lf %s", w1, &val, w2);
	f0[prio][i][oIndex][uIndex][rIndex][qIndex][f0_index[prio][i][oIndex][uIndex][rIndex][qIndex]]=val/1000.0;
	f0_index[prio][i][oIndex][uIndex][rIndex][qIndex]++;
      }
    }
  }
  rewind(u_fp);
  for(int i=0;i<nfuns;i++){
    sprintf(path,"%s/data%d.txt", noprio_dir, i);
    d_fp=fopen(path,"r");
      while(fgets(buf, 256, d_fp)){
	if((buf[0]=='.')){
	  oIndex=funToVal((double)(isX(buf,"-f0 ")));
	  uIndex=0;
	  rIndex=0;
	  qIndex=0;
	  //	  printf("[%d][%d][%d][%d][%d]\n", prio, oIndex, uIndex, rIndex, qIndex);

	}
	else{
	  sscanf(buf,"%s %lf %s", w1, &val, w2);
	  f0[noprio][i][oIndex][uIndex][rIndex][qIndex][f0_index[noprio][i][oIndex][uIndex][rIndex][qIndex]]=val/1000.0;
	  f0_index[noprio][i][oIndex][uIndex][rIndex][qIndex]++;
      }
      }
  }
    summaryJsched_CMP(f0, f0_index, a_util_arr, m_util_arr, a_qnl_arr);
}
int main(int argc, char** argv){
  //parseProxy(argv[1],argv[2]);
  //    parseEmail(argv[1],argv[2]);
         parseEmail_ncmp(argv[1],argv[2]);
  //parseJobs(argv[1],argv[2]);
  
}
