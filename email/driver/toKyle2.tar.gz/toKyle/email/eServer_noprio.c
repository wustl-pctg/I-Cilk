#include <cilk/cilk_main.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/timerfd.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <netdb.h>
#include <sys/un.h>
#include <fcntl.h>
#include "../jsched/utils/util.h"
#include "../jsched/utils/arg.h"
#include "../jsched/utils/timing.h"


#define msg_amt 300 //amount of pages
#define page_size 100 //size of each page
#define msg_size 32 //size of message
#define max_items 30000 //max messages
#define LISTENQ 1023 //amount of buffered clients
#define READ_SIZE 32 //size of read for each request from a client



typedef struct sockaddr SA; 
typedef void handler_t(int);



//cilk variables (unused, just want prio/not prio to take same arguments)
int cilk_quantum_length_us ;
double cilk_rho ;
double cilk_util_bound ;
double cilk_init_desire ;
int cilk_rr_worker_count ;
int cilk_reserved_w_per_lvl ;

//port number
char* portspec=NULL;

//compression variables
int ds; //dictionary size
int bs; //buffer size
int cs; //chunk size
int verbose=0; //verbose mode (0-3)
int cons=0;  //number of connections
int bgsec=0; //frequency of compression background task (seconds)
int max_users=0; //will be set to cons


//arguments (run -h to see them printed)
#define Version "0.1"
static ArgOption args[] = {
  // Kind,         Type,    name,         reqd, variable,                 help
  { KindOption,   Integer, "-v",            0, &verbose,                 "Turn on verbosity (0-3)" },
  { KindOption,   String,  "--port",        0, &portspec,                "port num" },
  { KindOption,   Integer, "--dictsize",    0, &ds,                      "dict size" },
  { KindOption,   Integer, "--bufsize",     0, &bs,                      "buffer size" },
  { KindOption,   Integer, "--chunksize",   0, &cs,                      "chunk size" },
  { KindOption,   Integer, "--cons",        0, &cons,                    "number of clients" },
  { KindOption,   Integer, "--bgsec",       0, &bgsec,                   "interval for bg task" },
  { KindOption,   Integer, "--quantlen",    0, &cilk_quantum_length_us,  "cilk_quant_len" },
  { KindOption,   Double,  "--cilkrho",     0, &cilk_rho,                "cilkrho" },
  { KindOption,   Double,  "--cilkutil",    0, &cilk_util_bound,         "cilk_util_bound" },
  { KindOption,   Double,  "--cilkinit",    0, &cilk_init_desire,        "cilk_init_desire" },
  { KindOption,   Integer, "--cilkWrks",    0, &cilk_rr_worker_count,    "cilk_rr_worker_count" },
  { KindOption,   Integer, "--cilkres",     0, &cilk_reserved_w_per_lvl, "cilk_reserved_w_per_lvl" },
  { KindHelp,     Help,    "-h" },
  { KindEnd }
};
static ArgDefs argp = { args, "Email Nopriority", Version, NULL };


//struct storing indices between compression loops
struct Out {
  int i;
  int j;
  char k;
};


//struct for holding a parsed request from clients
typedef struct reqNode{
  char buf[msg_size]; //the request itself
  int cat_flag; //tells whether previous line was incomplete
  struct reqNode* next;
  struct reqNode* prev;
} reqNode_t;


//head struct for parsed requests
typedef struct reqHead{
  int size; 
  struct reqNode* head;
  struct reqNode* tail;
} reqHead_t;


//struct that stores a given message
//offsets are used to go between the field and its unsigned long tag
typedef struct mail{
  char from[32]; //0
  char to[32]; //32
  char date[32]; //64
  char* subj; //96
  unsigned long msg_index; //104
  unsigned long ul_from; //112
  unsigned long ul_to; //120
  unsigned long ul_date; //128
  unsigned long ul_subj; //136
} mail;

//struct that stores the mailbox for each user
typedef struct mailbox{
  char user[16];
  mail* inbox;
  volatile unsigned long inbox_len;
  char*** dec_messages;
  char** comp_messages;
  int* comp_len;
  volatile int fd;
  volatile int done;
  cilk::future<mail*> *sort_fut;
  cilk::future<int> *send_fut;
  volatile cilk::future<int> ** comp_fut;
  cilk::future<int> * bg;
}mailbox;



char** didComp=NULL;
struct timeval** compStart=NULL;
struct timeval** compEnd=NULL;
volatile unsigned long maxCon=0;
volatile unsigned long conNum=0;
mailbox* users=NULL;


int open_listenfd(char *port); //listen for new connections
int Open_listenfd(char *port); //listen wrapper 
char* getMsg(volatile int myNum, int i, char* buf); //get message for given index (if buf copy into that index)
void removeNode(reqHead_t* head,reqNode_t* node); //remove a node from LL of requests

void recursive(mail* arr, int start, int end, int offset); //sort function
int getAll(volatile int myNum, int temp);//get all futures for a user (after 'quit')
int doComp(volatile int myNum);//background function that periodically calls compress
mail* doSort(mail* arr, volatile int myNum, int offset, cilk::future<mail*>* h);//sort inbox
int event_loop(volatile int myNum);//main loop reading requests 
int compress_wrapper(volatile int myNum, int index);//outside loop of compression
int sendMail(char** info, volatile int myNum, cilk::future<int>* h);//send new msg
reqNode_t* popNext(int fd, char* buf, reqHead_t* head);//get next instruction (from LL)
int letConnect(char* port);//gets client connections and calls their event_loop and background compression
char** getInfo(int items, volatile int myNum, char* buf, reqHead_t* head);//make all the fields for new mail item
int compress_outer(volatile int myNum, int index, int calls, volatile cilk::future<int>* h);//wrapper to compress_wrapper
int decompress_wrapper(volatile int myNum, int index, mail* sorted, int sort_len);//outside loop for decompress
int decompress_outer(volatile int myNum, int index, mail* sorted, int sort_len,volatile  cilk::future<int>* h);//wrapper for decompress_wrapper

//adds node to parsed request list
//head: head of the linked list
//info: the new buffer to be added
void addNode(reqHead_t* head, char* info){
  reqNode_t* newNode=(reqNode_t*)calloc(sizeof(reqNode_t),1);
  newNode->cat_flag=0;
  strcpy(newNode->buf,info);
  newNode->prev=NULL;
  newNode->next=NULL;
  if(head->head==NULL){


    head->head=newNode;
    head->tail=newNode;
    newNode->prev=NULL;
    newNode->next=NULL;
    head->size++;
  }
  else{    
    if(head->head->cat_flag){//if cat_flag dont add node but cat buf to previous
      strcat(head->head->buf, info);
      head->head->cat_flag=0;
    }
    else{
      newNode->next=NULL;
      newNode->prev=head->tail;
      head->tail->next=newNode;
      head->tail=newNode;
      head->size++;
    }
  }

}

//turns timeval to us
//t: timeval struct to be converted
suseconds_t to_usecs(struct timeval t) {
  return t.tv_sec * 1000000 + t.tv_usec;
}


//return difference between to timeval structs in us
//t1: timeval to be subtracted from
//t2: timeval whose value with be subtracted from t1
suseconds_t difftimevals(struct timeval t1, struct timeval t2) {
  return (to_usecs(t1) - to_usecs(t2));
}

//print request linked list (debugging really)
//head: head of ll to print
//direction: print forward or backward (1 is head to tail)
//clientfd: fd of the client
//conNum_l: connection number of the client whose LL in being printed
void printLL(reqHead_t* head, int direction, int clientfd, volatile unsigned long conNum_l){
  if(direction){
    printf("----------forward start %d/%lu----------\n", clientfd,conNum_l);
    reqNode_t* iter=head->head;

    int i=1;
    while(iter!=NULL){
      printf("%d: %s\n",i, iter->buf);
      i++;
      iter=iter->next;
    }
    printf("size=%d\n", head->size);
    printf("----------forward end %d/%lu----------\n",clientfd, conNum_l);
  }
  else{
    printf("----------backward start----------\n");
    reqNode_t* iter=head->tail;

    int i=1;
    while(iter!=NULL){
      printf("%d: %s\n",i, iter->buf);
      i++;
      iter=iter->prev;
    }
    printf("size=%d\n", head->size);
    printf("----------backward end----------\n");
  }

}

//creates all the fields from a message
//items: amount of fields
//myNum: connection number of client
//buf: buffer for popnext read (if has to do IO)
//head: head of clients LL
char** getInfo(int items, volatile int myNum, char* buf, reqHead_t* head){
  char** info=(char**)calloc(items, sizeof(char*));
  for(int i =0;i<items;i++){
    if(i==items-1){
      info[i]=(char*)calloc(msg_size, sizeof(char));
    }
    else{
      info[i]=(char*)calloc(64, sizeof(char));
    }
    reqNode_t* cur=popNext(users[myNum].fd, buf, head);
    strcpy(info[i], cur->buf);
    free(cur);
  }
  strcat(info[2],"\n\0");
  return info;
}

//remove node from request linked list
//head: head of LL
//node: node to be removed
void removeNode(reqHead_t* head,reqNode_t* node){
  if(head->head==NULL){
    return;
  }
  if(node->prev==NULL&&node->next==NULL){
    head->head=NULL;
    head->tail=NULL;
  }
  else if(node->prev==NULL&&node->next!=NULL){
    head->head=node->next;
    head->head->prev=NULL;
  }
  else if(node->next==NULL&&node->prev!=NULL){
    node->prev->next=NULL;
    head->tail=node->prev;
  }
  else{
    node->prev->next=node->next;
    node->next->prev=node->prev;
  }
  head->size--;
  
}




//converts UL offset to a field
//offset: offset to be converted
int offset_to_type(int offset){
  if(offset==112){
    return 0;
  }
  if(offset==120){
    return 32;
  }
  if(offset==128){
    return 64;
  }
  if(offset==136){
    return 96;
  }
  return 0;
}


//just CAS wrapper
//i: conNum in users array
int CASincr(int i){
  return __atomic_add_fetch(&users[i].inbox_len, 1, __ATOMIC_RELAXED);
}

//from a field gets it UL offset val
//m: mail struct whose UL is being got
//offset: offset to field to get to UL
unsigned long getOffset(mail* m, int offset){
  unsigned long ret=*(unsigned long*)((char*)m+offset);
  return ret;
}


//get field from UL offset
//m: mail struct whose field is being got
//offset: offset to UL to get to field
char* getType(mail* m, int offset){
  if(offset==96){
    return m->subj;
  }
  return (char*)((char*)m+offset);
}

//test two mail structs (for quicksort)
//m1: mail struct 1 to be compared
//m2: mail struct 2 to be compared
//offset: which field/UL is being used to sort
int test(mail* m1, mail* m2, int offset){
  unsigned long u1=getOffset(m1, offset), u2=getOffset(m2, offset);
  if(u1!=u2||offset==128){
    return u1<u2;
  }
  else{
    int type_offset=offset_to_type(offset);
    char* c1=getType(m1, type_offset), *c2=getType(m2, type_offset);
    int index=8;
    while(c1[index]&&c2[index]){
      if(c1[index]!=c2[index]){
	return c1[index]<c2[index];
      }
      index++;
    }
    if(!c1[index]&&!c2[index]){
      return 0;
    }
    if(c1[index]){
      return 0;
    }
    return 1;
  }
}

//converts char to lowerCase
//c: char to be converted
char toLower(char c){
  if(c<97){
    return c-32;
  }
  return c;
}

//for creating UL tag for each buffer
//str: string being converted to UL
unsigned long str_to_ul(char* str){
  int index=0;
  unsigned long val=0;
  while(str[index]&&index<8){
    unsigned long temp=toLower(str[index]);
    val+=temp<<(56-(index<<3));
    index++;
  }
  return val;
}

//swap for quicksort
//a: mail item 1 being swapped
//b: mail item 2 being swapped
void swap(mail* a, mail *b){
  mail temp=*a;
  *a=*b;
  *b=temp;
}

//work part of quicksort
//arr: array being sorted
//start: start index into array
//end: end index into array (inclusive)
//offset: UL/field being sorted
int work(mail* arr, int start, int end, int offset){
  mail pivot=arr[start+((end-start)>>1)];
  int min=start-1;
  int max=end+1;
  while(1){
    min++;
    while(test(arr+min, &pivot, offset)){
      min++;
    }
    max--;
    while(test(&pivot, arr+max, offset)){
      max--;
    }
    if(min>=max){
      return max;
    }
    swap(arr+min, arr+max);


  }

}


//recursive part of quicksort
//arr: array being sorted
//start: start index into array
//end: end index into array (inclusive)
//offset: UL/field being sorted
void recursive(mail* arr, int start, int end, int offset){
  if(end>start){
    cilk_enable_spawn_in_this_func();
    int p=work(arr, start, end, offset);
    cilk_spawn3_void(recursive,arr, start, p, offset);
    recursive(arr, p+1, end, offset);
    cilk_sync2();
  }
}


//called in event loop on client requests to decide what to do
//op: operation from client request
int type_to_offset(char* op){
  int offset=0;
  if(!strncmp(op, "s from", 6)){
    offset=112;
  }
  if(!strncmp(op, "s to", 4)){
    offset=120;
  }
  if(!strncmp(op, "s date", 6)){
    offset=128;
  }
  if(!strncmp(op, "s subj", 6)){
    offset=136;
  }
  if(!strncmp(op, "quit", 4)){
    offset=-1;
  }
  if(!strncmp(op, "print", 5)){
    offset=-2;
  }
  
  return offset;
            
}

//gets local time of new message
//m: struct whose date field is being created
void doTime(mail* m){
  time_t t = time(NULL);
  struct tm tm = *localtime(&t);
  char month=tm.tm_mon + 1;
  short year=tm.tm_year + 1900;
  char day=tm.tm_mday;
  char hour=tm.tm_hour;
  char min=tm.tm_min;
  char sec=tm.tm_sec;

  sprintf(m->date,"%d-%d-%d at [%dh:%dm:%ds]",month, day, year, hour, min, sec);
  unsigned long temp=year;
  unsigned long val=temp<<48;
  temp=month;
  val+=temp<<40;
  temp=day;
  val+=temp<<32;
  temp=hour;
  val+=temp<<24;
  temp=min;
  val+=min<<16;
  val+=sec;
  m->ul_date=val;
  
}

//prints mail (not used unless print call or decompress used)
//m: mail struct to be printed
//myNum: local conNum for the client
//include_msg: bool 
void printMail(mail* m, volatile int myNum, int include_msg){
  if(include_msg){
    printf("\n%s: %s -> %s\nSubject: %s\n------------------------------\n%s\n\n", m->date, m->from, m->to, m->subj, getMsg(myNum, m->msg_index,NULL));
  }
  else{
    printf("\n%s: %s -> %s\nSubject: %s\n------------------------------\nMESSAGE NOT AVAILABLE\n\n", m->date, m->from, m->to, m->subj);
  }
}


//listen on port wrapped (from csapp)
//port: port to listen on
int Open_listenfd(char *port) {
  int rc;

  if ((rc = open_listenfd(port)) < 0) {
    fprintf(stderr,"error in open\n");
  }
  return rc;
}

//real listen (from csapp)
//port: port to listen on
int open_listenfd(char *port) {
  struct addrinfo hints, *listp, *p;
  int listenfd, rc, optval=1;

  /* Get a list of potential server addresses */
  memset(&hints, 0, sizeof(struct addrinfo));
  hints.ai_socktype = SOCK_STREAM;             /* Accept connections */
  hints.ai_flags = AI_PASSIVE | AI_ADDRCONFIG; /* ... on any IP address */
  hints.ai_flags |= AI_NUMERICSERV;            /* ... using port number */
  if ((rc = getaddrinfo(NULL, port, &hints, &listp)) != 0) {
    fprintf(stderr, "getaddrinfo failed (port %s): %s\n",
	    port, gai_strerror(rc));
    return -2;
  }

  /* Walk the list for one that we can bind to */
  for (p = listp; p; p = p->ai_next) {
    /* Create a socket descriptor */
    listenfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
    if (listenfd < 0) {
      continue;  /* Socket failed, try the next */
    }

    /* Eliminates "Address already in use" error from bind */
    setsockopt(listenfd, SOL_SOCKET,    //line:netp:csapp:setsockopt
	       SO_REUSEADDR, (const void *) &optval , sizeof(int));

    /* Bind the descriptor to the address */
    if (bind(listenfd, p->ai_addr, p->ai_addrlen) == 0) {
      break; /* Success */
    }

    if (close(listenfd) < 0) { /* Bind failed, try the next */
      fprintf(stderr, "open_listenfd close failed: %s\n",
	      strerror(errno));
      return -1;
    }
  }

  /* Clean up */
  freeaddrinfo(listp);
  if (!p) { /* No address worked */
    return -1;
  }

  /* Make it a listening socket ready to accept connection requests */
  if (listen(listenfd, LISTENQ) < 0) {
    close(listenfd);
    return -1;
  }
  return listenfd;
}

//gets the message for a given index
//myNum: clients local conNum
//i: message index
//buf: if buf then add it to message
char* getMsg(volatile int myNum, int i, char* buf){
  if(buf){
    strcpy(users[myNum].dec_messages[((i/page_size))][((i%page_size))], buf);
  }
  return (char*)(users[myNum].dec_messages[((i/page_size))][((i%page_size))]);
}

//initial loop called by main that accepts/setups up new clients
//port: portnum to listen on
int letConnect(char* port){

  cilk_enable_spawn_in_this_func();
  int listenfd, clientfd; 
  socklen_t clientlen;
  struct sockaddr_storage clientaddr;
  listenfd=Open_listenfd(port);
  int old_flags=fcntl(listenfd, F_GETFL,0);
  if(fcntl(listenfd, F_SETFL, old_flags|O_NONBLOCK)<0){
    fprintf(stderr,"Error setting client fd\n");
    fprintf(stderr,"%s\n", strerror(errno));
    return 0;
  }


  //loop which will continue running until specified amount of connections have connected
  while(cons>maxCon){
    clientlen=sizeof(struct sockaddr_storage);
    //start accepting connections from clients
    if((clientfd=cilk_accept_sync(listenfd, (SA*) &clientaddr, &clientlen))<0){    
      fprintf(stderr,"server is not able to connect to clients\n");
      fprintf(stderr, "%s\n",strerror(errno));
      return 0;
    }
    old_flags=fcntl(clientfd, F_GETFL,0);
    if(fcntl(clientfd, F_SETFL, old_flags|O_NONBLOCK)<0){
      fprintf(stderr,"Error setting client fd\n");
      fprintf(stderr,"%s\n", strerror(errno));
      return 0;
    }

    char username[16]="";
    int ret_val=cilk_read_sync(clientfd, username, 5);
    if(ret_val==-1){
      fprintf(stderr,"Error logging in new user\n");
      return 0;
    }

    if(ret_val){
      //initial all variables for mailbox
      if(verbose){
	printf("Logging in as %s\n", username);
      }
      int personal_con=conNum;
      strcpy(users[personal_con].user, username);
      users[personal_con].inbox=(mail*)calloc(max_items, sizeof(mail));
      users[personal_con].inbox_len=0;
      users[personal_con].done=0;
      users[personal_con].sort_fut=NULL;
      users[personal_con].send_fut=NULL;
      users[personal_con].comp_len=(int*)calloc(msg_amt, sizeof(int));
      users[personal_con].bg=NULL;
      users[personal_con].comp_fut=(volatile cilk::future<int>**)calloc(msg_amt, sizeof(cilk::future<int>*));
      users[personal_con].dec_messages=(char***)calloc(msg_amt, sizeof(char**));
      users[personal_con].comp_messages=(char**)calloc(msg_amt, sizeof(char*));
      for(int i=0;i<msg_amt;i++){
	users[personal_con].comp_fut[i]=NULL;
	users[personal_con].dec_messages[i]=(char**)calloc(page_size, sizeof(char*));
	users[personal_con].comp_messages[i]=NULL;
	char* new_data=(char*)calloc(page_size*msg_size,1);
	for(int j =0;j<page_size;j++){
	  users[personal_con].dec_messages[i][j]=(new_data+(msg_size*j));

	}
      }


      users[personal_con].comp_len[0]=0;
      users[personal_con].fd=clientfd;

      __atomic_add_fetch(&conNum,1,__ATOMIC_RELAXED);
      __atomic_add_fetch(&maxCon, 1, __ATOMIC_RELAXED);
      int e_ret=0;
      cilk_spawn3(e_ret,event_loop, personal_con);
      cilk::future<int>* temp= new cilk::future<int>();			    
      users[personal_con].bg=temp;
      //commented out now, uncomment to include background compression
      //cilk_pspawn(CompP,&c_ret, doComp, personal_con);
      //cilk_future_create(users[personal_con].bg, doComp, personal_con);


    }
  }
  cilk_sync2();
  return 0;
}

//get all outstanding futures for a given client
//myNum: local conNum for the given client
//temp: local version of how many current connections still exist
int getAll(volatile int myNum, int temp){

  users[myNum].done=1;
  int i=myNum;
  if(users[i].sort_fut){
    mail* ret=cilk_future_get(users[i].sort_fut);
    if(verbose>1){
      printf("[%d]got sort at %p\n",i, ret);
    }
  }

  if(users[i].send_fut){
    int ret=cilk_future_get(users[i].send_fut);
    if(verbose>1){
      printf("[%d]got send at %d\n", i,ret);
    }
  }
  //uncomment if include background compression
  /*    if(users[i].bg){
	int ret=cilk_future_get(users[i].bg);
	printf("[%d]got bg at %d\n",i,ret);
	}
	for(int j=0;j<msg_amt;j++){
	if(users[i].comp_fut[j]){
	int ret=cilk_future_get(users[i].comp_fut[j]);
	if(verbose>1){
	printf("[%d][%d]got comp/dec at %d\n", i,j,ret);
	}
	}

	}*/
  return 0;
}


//get digits of an int
//a: int whose digits are being calculated
int calcDig(int a){
  int d=1;
  while(a/10){
    d++;
    a=a/10;
  }
  return d;
}


//called when user requests to sort inbox
//arr:inbox array
//myNum: local conNum for client
//offset: field to sort by
//h: prev sort future
mail* doSort(mail* arr, volatile int myNum, int offset, cilk::future<mail*>* h){

  int len=users[myNum].inbox_len;
  if(verbose>1){
    printf("%s: sorting[%d]...\n", arr[0].to, myNum);
  }
  mail* toSort=(mail*)calloc(len,sizeof(mail));
  int i=0;
  while(arr[i].ul_from&&i<len){
    toSort[i]=arr[i];
    i++;
  }
  recursive(toSort, 0, i-1, offset);
  if(h){
    mail* sorted=NULL;
    if(verbose>2){
      printf("Getting sort[%d]... < %ld \n", myNum, users[myNum].inbox_len);
    }
    sorted=cilk_future_get(h);	
    if(sorted){
      free(sorted);
    }
  }
  char type=2;
  char b[16]="";
  sprintf(b,"%c%d",type, i);
  int ret_val= cilk_write_sync(users[myNum].fd, b, 1+calcDig(i));
  if(ret_val==-1){
    fprintf(stderr, "Issue writing cached file to client\n");
  }
  if(verbose>1){
    printf("%s: sorted[%d] %d items\n", arr[0].to,myNum, i);
  }
  return toSort;
}


//gets next command from LL
//head: head of LL
//fd: if LL is empty read from this fd
//buf: buf to read from fd into
reqNode_t* popNext(int fd, char* buf, reqHead_t* head){
  while(1){
    if(head->head!=NULL&&(!head->head->cat_flag)){
      reqNode_t* ret= head->head;
      removeNode(head, head->head);      
      if(verbose>2){
	printf("Next Command: %s\n", ret->buf);
      }
      return ret;
    }
    else{
      memset(buf, 0, READ_SIZE+16);
      int ret_val=cilk_read_sync(fd, buf, READ_SIZE);
      if(ret_val==-1){
	fprintf(stderr,"failed on: %s\n", buf);
	fprintf(stderr,"Error reading request\n");
	return NULL;
      }

      if(ret_val){


	int cat_flag=0;
	if(buf[0]=='\n'){
	  head->tail->cat_flag=0;
	}
	if(buf[strlen(buf)-1]!='\n'){
	  cat_flag=1;
	}
	char* parseReq=strtok_r(buf, "\n", &buf);
	while(parseReq!=NULL){

	  addNode(head,(parseReq));
	  parseReq=strtok_r(NULL, "\n", &buf);
	}
	head->tail->cat_flag=cat_flag;
      }
    }
  }
}


//the loop spawned for each connections
//myNum: local conNum for client
int event_loop(volatile int myNum){
  //CilkPrioCommandDefine(int, event_loop, (volatile int myNum), {
  if(verbose>1){
    printf("looping at %d/%d\n", myNum, users[myNum].fd);
  }
  //linked list of buffered commands
  reqHead_t *head=(reqHead_t*)calloc(sizeof(reqHead_t),1);
  head->size=0;
  head->tail=NULL;
  head->head=NULL;

  char* buf=(char*)calloc(READ_SIZE+16, 1);
  reqNode_t* cur=NULL;
  while(1){
    //get first request
    cur=popNext(users[myNum].fd, buf, head);
    if(!cur){
      return -1;
    }
    //type_to_offset basically is instruction parser (not robust)
    int ret=type_to_offset(cur->buf);

    if(ret>0){
      free(cur);
      //sort



      cilk::future<mail*>* temp= new cilk::future<mail*>();

      cilk_future_create(temp, doSort, users[myNum].inbox,myNum,  ret,users[myNum].sort_fut);
      users[myNum].sort_fut=temp;
    }
    else if(!ret){
      free(cur);
      //new mail, fill fields then spawn send (pop next 3 then just spawn sooner)
      char** info=getInfo(3, myNum, buf, head);
	
      cilk::future<int>* temp2= new cilk::future<int>();

      cilk_future_create(temp2, sendMail,info, myNum,users[myNum].send_fut);
      users[myNum].send_fut=temp2;
    }
    else if(ret==-2){
      //would be print
      if(0){
	int index=0;
	char buf[16]="";
	sscanf(cur->buf,"%s %d",buf, &index);
	if(index<users[myNum].inbox_len){
	  cilk::future<int>* temp3= new cilk::future<int>();			    
	  cilk_future_create(temp3, decompress_outer, myNum, (((index+page_size)-1)/page_size)*page_size, (mail*)NULL, users[myNum].inbox_len, temp3);
	}
	else{
	  if(verbose>1){
	    printf("%s %d: That message index does not exist yet!\n", buf, index);
	  }
	}
      }
	
    }

    //quit
    else if(ret==-1){
      free(cur);
      int temp=__atomic_sub_fetch(&maxCon, 1, __ATOMIC_RELAXED);
      if(verbose>1){
	printf("Quit[%d]: %d\n", myNum, temp);
      }
      getAll(myNum, temp);
      return 0;
    }
  }
  return 0;
}




//finds matching chunks in dict
//dict: dictionary
//buf: buf to try and match
//out: indices to search around
//bs: buffer size
//ds: dictionary size
void match(char * dict, char * buff, struct Out * o, int bs, int ds)
{
  int i=0, j=0;
  int ti,tq,tj;
  for (int q=0;q<ds;q++)
    {
      ti = q;
      tq = q;
      tj = 0;
      for(int p=0;p<bs-1;p++)
	{
	  if (dict[tq] == buff[p])
	    {
	      tj++;
	      tq = (tq == ds-1) ? q : tq+1;
	    }
	  else break;
	}
        
      if (tj > j)
	{
	  j = tj;
	  i = ti;
	}
    }
  o->i = i;
  o->j = j;
  o->k = buff[j];
}


//shift function used in compress
//b: buffer being shifted
//len: len of b
//s: amount to shift down by
void shift( char* b, int len, int s )
{
  for(int i=0;i<len-s;i++)
    b[i] = b[s+i];
}
//helper function for compress (creates tag for indices)
//i,j,k: indices
//out: tag to be created
void writeIntermediate(int i, int j, int k, uint32_t *out) {
  *out = 0;
  *out = *out | (i << (6+8)) | (j << 8) | (int) k;
}

//compress a given chunk
//chunk: chunk to be compressed
//count: basically just chunksize
//cs: chunk size
//bs: buffer size
//ds: dictionary size
//resulting data from compression
//length: length of compressed item
void compress(char *chunk, int count, int cs, int bs, int ds, uint32_t **outBuff, int &length) {
  for (int i = count; i < cs + 1; i++) 
    chunk[i] = '\0';
    
  *outBuff = (uint32_t *)malloc(count * sizeof(uint32_t));
  length = 0;
  char *dict = (char *)malloc(ds * sizeof(char));
  char *buff = (char *)malloc(bs * sizeof(char));
  for (int i = 0; i < bs; i++) 
    buff[i] = chunk[i];
    
  for (int i = 0; i < ds; i++) 
    dict[i] = '\0';
    
  chunk += bs;

  Out out;
  while (buff[0] != '\0') {
    match(dict, buff, &out, bs, ds);
    *(*outBuff + length) = 0;
    *(*outBuff + length) = *(*outBuff + length) | (out.i << (6+8)) | (out.j << 8) | (int) out.k;
    length++;
    if (out.k == '\0')
      break;

    shift(dict, ds, out.j + 1);
    for (int i = 0; i < out.j + 1; i++)
      dict[ds - (out.j + 1) + i] = buff[i];

    shift(buff, bs, out.j + 1);
    for (int i = 0; i < out.j + 1; i++) {
      buff[bs - (out.j + 1) + i] = chunk[i];
      if (chunk[i] == '\0') {
	chunk = &chunk[i];
	break;
      }
    }

    if (chunk[0] != '\0')
      chunk += out.j + 1;
  }
  free(dict);
  free(buff);
}

//decompress a compressed buffer
//s: buffer to be decompressed
//dict: dict to use in decompression
//ds: dictionary size
//buff: buffer used in decompression
//bs: buffer size
//cs: chunk size
//bn: stores how far into decompression
//line: to get indices for decompression
//to_write: stores decompressed result
void decompress(char* s, char* dict, int ds, char* buff, int bs, int cs, int* bn, uint32_t line, int* to_write)
{
  Out out;
  out.k = line & 0xFF;
  line >>= 8;
  out.j = line & 0x3f;
  line >>= 6;
  out.i = line & 0x3FFFF;
  shift(dict,ds,*bn);
  for(int p=0;p<*bn;p++)
    dict[ds-*bn+p] = buff[p];

  int d = out.i;
  for(int p=0;p<out.j;p++)
    {
      s[p] = dict[d];
      d = (d+1 == ds) ? out.i : d+1;
    }
  s[out.j] = out.k;
  for(int p=0;p<out.j+1;p++)
    buff[p] = s[p];
  *bn = out.j+1;        
  if (out.k!='\0') 
    {
      out.j++;
      s[out.j] = '\0';
      *to_write=out.j;
    }
}

//called when doing decompression on a page
//myNum: local conNum for client
//index: which page is being decompressed
//sorted: array to be decompressed
//sort_len: size of array
//h: future for previous compression/decompression
int decompress_outer(volatile int myNum, int index, mail* sorted, int sort_len, volatile cilk::future<int>* h){
  int compressed=0;
  /*    cilk::future<int>* expec=users[myNum].comp_fut[(index/page_size)-1];
	__atomic_compare_exchange(&users[myNum].comp_fut[(index/page_size)-1],
	&expec,
	&h,
	1,__ATOMIC_RELAXED, __ATOMIC_RELAXED);*/
  volatile cilk::future<int>* expec=NULL;
  expec = __atomic_exchange_n(&users[myNum].comp_fut[(index/page_size)-1], h, __ATOMIC_SEQ_CST);

  if(expec){
    if(verbose>2){
      printf("[%d][%d]Waiting on compress\n", myNum, index);
    }
    compressed=cilk_future_get((cilk::future<int>*)expec);
    if(verbose>2){
      printf("[%d][%d]Compressed = %d\n", myNum, index,compressed);
    }
  }
  if(compressed){
    if(verbose>2){
      printf("[%d][%d]Running Decompression\n", myNum, index);
    }
    decompress_wrapper( myNum, index, sorted, sort_len);
    if(verbose>2){
      printf("[%d][%d]Finish Decompression\n", myNum, index);
    }
  }
    
  else{
    for(int i =index-page_size;i<index;i++){
      if(i<sort_len){
	if(sorted){
	  if(verbose>1){
	    printf("%d/%d\n", i, sort_len);
	    int include_msg=1;
	    if(sorted[i].msg_index<index-page_size||sorted[i].msg_index>=index){
	      include_msg=0;
	    }
	    else{
	      printMail(&sorted[i], myNum, include_msg);
	    }
	  }
	}
	else{
	  if(verbose){
	    printf("%d/%d\n", i, sort_len);
	    printMail(&users[myNum].inbox[i], myNum,1);
	  }
	}
      }
    }
     
  }
  return 0;
}

//wrapper that calls decompress
//myNum: local conNum for client
//index: page index
//sorted: array to be decompressed
//sort_len: size of array being decompressed
int decompress_wrapper(volatile int myNum, int index, mail* sorted, int sort_len){
  int32_t line = 0;
  bool done = false;
  int bn = 0;
  char s[bs];
  int dec_l=0;
  int agr_d=0;
  int len=msg_size*page_size;
  char* dec_data=(char*)calloc(len,1);
  char* data=users[myNum].comp_messages[(index/page_size)-1];
  int dsize=users[myNum].comp_len[(index/page_size)-1];
  while(!done)
    {
      char dict[ds];
      char buff[bs];
      for(;;)
	{
	  memcpy(&line,data+dec_l, 4);
	  dec_l+=4;
	  if (line < 0)
	    {
	      if (dec_l>=dsize)
		done = true;
	      break;
	    }

	  int to_write=0;
	  decompress(s, dict, ds, buff,bs, cs, &bn, line, &to_write);
	  memcpy(dec_data+agr_d, s, to_write);
	  agr_d+=to_write;
	  if (dec_l>=dsize)
	    {
	      done = true;
	      break;
	    }
	}
    }
  char* new_data=(char*)calloc(page_size*msg_size,1);
  char* parseReq=strtok_r(dec_data, "\n", &dec_data);
  int m_index=0;
  while(parseReq!=NULL&&m_index<page_size){
    users[myNum].dec_messages[(index/page_size-1)][m_index]=(new_data+(msg_size*m_index));
    strcpy(users[myNum].dec_messages[(index/page_size-1)][m_index], parseReq);
    strcat(users[myNum].dec_messages[(index/page_size-1)][m_index],"\n\0");
    if((((index/page_size)-1)*page_size+m_index)<sort_len){
      if(sorted){
	if(verbose>1){
	  printf("%d/%d\n",((index/page_size)-1)*page_size+m_index , sort_len);
	  int include_msg=1;
	  if(sorted[((index/page_size)-1)*page_size+m_index].msg_index<index-page_size||sorted[((index/page_size)-1)*page_size+m_index].msg_index>=index){
	    include_msg=0;
	  }
	  else{
	    printMail(&users[myNum].inbox[((index/page_size)-1)*page_size+m_index], myNum, include_msg);
	  }
	}
      }
      else{
	if(verbose){
	  printf("%d/%d\n",((index/page_size)-1)*page_size+m_index , sort_len);
	  printMail(&users[myNum].inbox[((index/page_size)-1)*page_size+m_index], myNum,1);
	}
      }
    }
    m_index++;
    parseReq=strtok_r(NULL, "\n", &dec_data);
    
  }
  free(dec_data);
  return 0;
}

//called when compressing a page
//myNum: local conNum for client
//index: page index
//calls: index for timing variables
//h: previous future for last compress/decompress
int compress_outer(volatile int myNum, int index, int calls, volatile cilk::future<int>* h){
  int compressed=0;

  volatile cilk::future<int>* expec=NULL;
  expec = __atomic_exchange_n(&users[myNum].comp_fut[(index/page_size)-1], h, __ATOMIC_SEQ_CST);

  if(expec){
    if(verbose>2){
      printf("[%d][%d]Waiting on decompress\n", myNum, index);
    }
    compressed=cilk_future_get((cilk::future<int>*)expec);
    if(verbose>2){
      printf("[%d][%d]Decompressed = %d\n", myNum, index,compressed);
    }
  }

  if(!compressed){
    didComp[myNum][calls]=1;
    if(verbose>2){
      printf("[%d][%d]Running Compression\n", myNum, index);
    }
    compress_wrapper( myNum, index);
    if(verbose>2){
      printf("[%d][%d]Finish Compresion\n", myNum, index);
    }
  }
  gettimeofday(&compEnd[myNum][calls],NULL);
  return 1;
}


//wrapper that calls compress
//myNum: local conNum for client
//index: page index 
int compress_wrapper(volatile int myNum, int index){
  char* all_data=(char*)calloc((index)*msg_size,1);
  char* comp_data=(char*)calloc((index)*msg_size,1);
  int init=0;
  int slen=0;
  int agr_slen=0;
  char* to_free=getMsg(myNum, index-page_size, NULL);
  for(int i =index-page_size;i<index;i++){
    char* msg=getMsg(myNum, i, NULL);
    slen=strlen(msg);
    memcpy(all_data+init+agr_slen, msg, slen);
    agr_slen+=slen;
  }
  free(to_free);
  int max=(agr_slen/cs);
  int comp_index=-1;
  int agr_l=0;
  int agr_write=0;
  while(comp_index<max){
    comp_index++;
    char *chunk2 = (char *)malloc((cs + 1) * sizeof(char));
    memcpy(chunk2, all_data+cs*comp_index, cs);
    int count=cs;
    uint32_t *outBuff = NULL;
    int length = 0;
    compress(chunk2, count, cs, bs, ds, &outBuff, length);
    memcpy(comp_data+agr_l, outBuff, 4*length);
    agr_l+=length*4;
    agr_write+=length;
    free(chunk2);
    free(outBuff);
  }
  users[myNum].comp_len[(index/page_size)-1]=agr_l;
  users[myNum].comp_messages[(index/page_size)-1]=(char*)realloc(comp_data,agr_l+16);
  memset(users[myNum].comp_messages[(index/page_size)-1]+agr_l,0, 16);

  free(all_data);
  return 1;
  
}

//send a new mail item
//info: stores all the information for the fields of the new mail item
//myNum: local conNum for client
//h: previous send call 
int sendMail(char** info, volatile int myNum, cilk::future<int>* h){


  int sent=0;
  mail new_mail;
  strcpy(new_mail.from, users[myNum].user);
  strcpy(new_mail.to, info[0]);
  free(info[0]);
  new_mail.ul_from=str_to_ul(new_mail.from);
  new_mail.ul_from=str_to_ul(new_mail.to);
  new_mail.subj=info[1];
  new_mail.ul_from=str_to_ul(new_mail.subj);
  doTime(&new_mail);
  for(int i =0;i<conNum;i++){
    if(!strcmp(users[i].user, new_mail.to)){
      int index=CASincr(i)-1;
      new_mail.msg_index=index;
      users[i].inbox[index]=new_mail;
      getMsg(i, index, info[2]);
      sent++;
    }
   
  }
  //get before writing back result
  if(h){
    int did_send=cilk_future_get(h);	
    if(!did_send){
      printf("Returned false\n");
    }
  }
  char end=3;
  int ret_val= cilk_write_sync(users[myNum].fd, &end, 1);
  if(ret_val==-1){
    fprintf(stderr, "Issue writing cached file to client\n");
  }

  free(info[2]);
  free(info);
  if(verbose>2){
    printf("new mail %s -> %s\n", new_mail.from, new_mail.to);
  }
  if(!sent){
    printf("Failed to send mail to %s\n",new_mail.to);
  }
  return sent;
}
  
int main(int argc, char** argv){
  CILK_INITIAL_FUNC_PREAMBLE;
  portspec=(char*)calloc(16, sizeof(char));
  strcpy(portspec,"6005");
  progname = argv[0];
  ArgParser* ap = createArgumentParser(&argp);
  int ok = parseArguments(ap, argc, argv);
  if (ok) {
    fprintf(stderr,"Error parsing arguments");
    return -1;
  }
  max_users=cons;
  if(verbose){
    printf("rho: %lf, ql: %d, ut: %lf\n",cilk_rho, cilk_quantum_length_us, cilk_util_bound);
  }

  didComp=(char**)calloc(max_users, sizeof(char*));
  compEnd=(struct timeval**)calloc(max_users, sizeof(struct timeval*));
  compStart=(struct timeval**)calloc(max_users, sizeof(struct timeval*));
  for(int i=0;i<max_users;i++){
    compEnd[i]=(struct timeval*)calloc(msg_amt<<3, sizeof(struct timeval));
    compStart[i]=(struct timeval*)calloc(msg_amt<<3, sizeof(struct timeval));
    didComp[i]=(char*)calloc(msg_amt<<3, sizeof(char));
  }
  FILE* ufp=fopen("edata_noprio/utils.txt","a");
  for(int i =0;i<argc;i++){
    fprintf(ufp,"%s ", argv[i]);
  }
  fprintf(ufp,"\n");
  users=(mailbox*)calloc(max_users,sizeof(mailbox));
  if(verbose){
    printf("Running on verbosity: %d\n", verbose);
  }

  cilk_enable_spawn_in_this_func();
  int c_ret=0;
  cilk_spawn3(c_ret,letConnect,portspec);
  cilk_sync2();
  for(int j=0;j<max_users;j++){
    unsigned long* ulr=(unsigned long*)compStart[j], *ulw=(unsigned long*)compEnd[j];
    int i=0;
    while(ulr[(i<<1)]&&ulr[(i<<1)+1]&&ulw[(i<<1)]&&ulw[(i<<1)+1]&&i<1000){
      if(didComp[j][i]){
	fprintf(ufp,"Comp: %d %ld us\n", (int)didComp[j][i], difftimevals(compEnd[j][i], compStart[j][i]));
      }
      i++;
    }
  }
  return 0;
  CILK_FUNC_EPILOGUE;
}

//background task for given client that periodically compressed inbox
//myNum: local conNum for client
int doComp(volatile int myNum){
  int timerfd = timerfd_create(CLOCK_MONOTONIC,0);
  int old_flags=fcntl(timerfd, F_GETFL,0);
  if(fcntl(timerfd, F_SETFL, old_flags|O_NONBLOCK)<0){
    fprintf(stderr,"Error setting client fd\n");
    fprintf(stderr,"%s\n", strerror(errno));
    return 0;
  }
  int calls=0;
  struct itimerspec timspec;
  bzero(&timspec, sizeof(timspec));
  timspec.it_interval.tv_sec = bgsec;
  timspec.it_interval.tv_nsec = 0;
  timspec.it_value.tv_sec = 0;
  timspec.it_value.tv_nsec = 1000000;

  int res = timerfd_settime(timerfd, 0, &timspec, 0);
  if(res < 0){
    perror("timerfd_settime:");
  }
  uint64_t expirations = 0;

  while(cilk_read_sync(timerfd, (char*)&expirations, sizeof(expirations))){
    if(users[myNum].done){
      return 0;
    }
    if(res < 0){ perror("read:"); continue; }
    if(users[myNum].inbox_len>page_size){
      for(int i =0;i<users[myNum].inbox_len-page_size;i+=page_size){
	if(verbose>2){
	  printf("START COMPRESS[%d][%d][%lu]\n", myNum, i+page_size, users[myNum].inbox_len);
	}
	cilk::future<int>* temp= new cilk::future<int>();
	gettimeofday(&compStart[myNum][calls],NULL);
	cilk_future_create(temp, compress_outer, myNum,i+page_size, calls,temp);
	calls++;
      }
    }
  }


  return 0;
}
