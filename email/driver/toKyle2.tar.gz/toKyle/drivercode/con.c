#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <setjmp.h>
#include <signal.h>
#include <dirent.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <errno.h>
#include <math.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <poll.h>
#include <sys/un.h>
#include "utils/util.h"
#include "utils/arg.h"
#include "utils/timing.h"
//#include "utils/dist.h"

#define quit 1
#define send 2
#define READLINE 128
typedef struct eparser{
  int tid;
  int offset;

}eparser;
typedef struct targs {
  char** requests;
  struct timeval * timesR;
  struct timeval * timesW;
  char* isCache;
  int * rsize;
  int tid;
} targs;

Barrier endLoopBarrier;
Barrier loopBarrier;
struct timeval startRun, endRun;
#define maxReq 256
int socks[maxReq];
FILE *sfiles[maxReq];
fd_set files;
int verbose=0;
int rps=0;
int sorts;
int sends;
int max=0;
int nthreads=1;
int poisson=0;
int proxy=0;
int email=0;
int nreqs=0;
int sites=0;
int portNum=6005;
int waitres=0;
int prefetch=0;
char* trace=NULL;
int echo=0;
int prio=0;
int nodata=0;
double den=((double)RAND_MAX)+1.0;
int rseed=0;

#define startSize 256
#define reqSize 256

#define maxEmailCon 30
#define Version "0.1"

char** eUsers=NULL;

static ArgOption args[] = {
  // Kind,        Method, name,         reqd, variable,  help
  { KindOption,   Integer, "-v",            0, &verbose,  "Turn on verbosity (0-2)" },
  { KindHelp,     Help,    "-h" },
  { KindOption,   String,  "--trace",       0, &trace,    "Trace file to give inputs to server" },
  { KindOption,   Integer, "--sites",       0, &sites,    "Number of sites to use"},
  { KindOption,   Integer, "--requests",    0, &nreqs,    "Number of total requests"},
  { KindOption,   Integer, "--rps",         0, &rps,      "Reqests to send per second (per threads)" },
  { KindOption,   Integer, "--port",        0, &portNum,  "Port to connect on" },
  { KindOption,   Integer, "-t",            0, &nthreads, "Number of Client threads" },
  { KindOption,   Set,     "--max",         0, &max,      "Second requests at max rate" },
  { KindOption,   Set,     "--poisson",     0, &poisson,  "Use Poisson Distribution to regulate request rate" },
  { KindOption,   Set,     "--proxy",       0, &proxy,    "To Connect to Proxy Server" },
  { KindOption,   Integer,     "--seed",    0, &rseed,    "Seed for srand" },
  { KindOption,   Set,     "--waitres",     0, &waitres,  "Set so that will wait for proxy response before continuing" },
  { KindOption,   Set,     "--echo",        0, &echo,     "Echo command line in data file" },
  { KindOption,   Set,     "--prio",        0, &prio,     "Whether driving priority/nonpriority version (for data collection)" },
  { KindOption,   Set,     "--nodata",      0, &nodata,   "turn off data collection" },
  { KindOption,   Set,     "--email",       0, &email,    "To Connect to Email Server" },
  { KindOption,   Integer, "--sorts",       0, &sorts,    "percentage of sort calls" },
  { KindOption,   Integer, "--sends",       0, &sends,    "percentage of send calls" },
  { KindOption,   Set,     "--prefetch",    0, &prefetch, "Prefetch all the data so its cached" },

  { KindEnd }
};

static ArgDefs argp = { args, "Driver For Proxy/Email Server", Version, NULL };

typedef struct sockaddr SA;
void* preader(void* arg);
void* pwriter(void* arg);
void* ereader(void* arg);
void* esendnwait(void* arg);
void* ewriter(void* arg);
void* sendnwait(void* arg);
suseconds_t to_usecs(struct timeval t) {
  return t.tv_sec * 1000000 + t.tv_usec;
}

suseconds_t difftimevals(struct timeval t1, struct timeval t2) {
  return (to_usecs(t1) - to_usecs(t2));
}

float nextTime(float rateParameter){
   return -logf(1.0f-((float)random()/den))/rateParameter;
}

void startBarrier(int tid){
  if (tid == 0) {
    myBarrier(&loopBarrier, tid);
    gettimeofday(&startRun, NULL);
  } else {
    myBarrier(&loopBarrier, tid);
  }
}

void endBarrier(int tid){
  if (tid == 0) {
    myBarrier(&loopBarrier, tid);

  } else {
    myBarrier(&loopBarrier, tid);
  }
}

int open_listenfd(char *port);
int Open_listenfd(char *port) {
  int rc;

  if ((rc = open_listenfd(port)) < 0) {
    fprintf(stderr,"error in open\n");
  }
  return rc;
}

//real listen (from csapp)
int open_listenfd(char *port) {
  struct addrinfo hints, *listp, *p;
  int listenfd, rc, optval=1;

  /* Get a list of potential server addresses */
  memset(&hints, 0, sizeof(struct addrinfo));
  hints.ai_socktype = SOCK_STREAM;             /* Accept connections */
  hints.ai_flags = AI_PASSIVE | AI_ADDRCONFIG; /* ... on any IP address */
  hints.ai_flags |= AI_NUMERICSERV;            /* ... using port number */
  if ((rc = getaddrinfo(NULL, port, &hints, &listp)) != 0) {
    fprintf(stderr, "getaddrinfo failed (port %s): %s\n",
	    port, gai_strerror(rc));
    return -2;
  }

  /* Walk the list for one that we can bind to */
  for (p = listp; p; p = p->ai_next) {
    /* Create a socket descriptor */
    listenfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
    if (listenfd < 0) {
      continue;  /* Socket failed, try the next */
    }

    /* Eliminates "Address already in use" error from bind */
    setsockopt(listenfd, SOL_SOCKET,    //line:netp:csapp:setsockopt
	       SO_REUSEADDR, (const void *) &optval , sizeof(int));

    /* Bind the descriptor to the address */
    if (bind(listenfd, p->ai_addr, p->ai_addrlen) == 0) {
      break; /* Success */
    }

    if (close(listenfd) < 0) { /* Bind failed, try the next */
      fprintf(stderr, "open_listenfd close failed: %s\n",
	      strerror(errno));
      return -1;
    }
  }

  /* Clean up */
  freeaddrinfo(listp);
  if (!p) { /* No address worked */
    return -1;
  }

  /* Make it a listening socket ready to accept connection requests */
  if (listen(listenfd, 1) < 0) {
    close(listenfd);
    return -1;
  }
  return listenfd;
}


int r_connect_proxy(int sock);
int r_connect_email(int sock);
int r_send(char *line, int sock);


//connect to server

//not we connect in order so conNum should match up with index in sock array on client
//side


int r_connect_email(int sock){
  //  int sock=0;


  //  if (sscanf(line, "connect %s %d %d", username, &portNum, &sock) != 3) return 0;
  socks[sock]= socket(AF_INET, SOCK_STREAM, 0);
  struct hostent *server;
  struct sockaddr_in serv_addr;
  server = gethostbyname("localhost");
  bzero((char *) &serv_addr, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  bcopy((char *)server->h_addr_list[0],
	(char *)&serv_addr.sin_addr.s_addr,
	server->h_length);
  serv_addr.sin_port = htons(portNum);
  if (connect(socks[sock],(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0){
    fprintf(stderr,"Failed to connect\n");
    return 0;
  }
  //  strcat(username,"\n");
  if(write(socks[sock], eUsers[sock], 5)!=5){
    return 0;
  }
  return 1;
}


int r_connect_proxy(int sock) {
  //  int sock=0;

  //char hostname[1024];
  //gethostname(hostname, 1024);
  const char *hostname = "localhost";
  //  if (sscanf(line, "connect %d %d", &portNum, &sock) != 2) return 0;

  socks[sock] = socket(AF_INET, SOCK_STREAM, 0);
  if (socks[sock] < 0)
    printf("Warning: can't open socket %d\n", sock);
  struct hostent *server;
  struct sockaddr_in serv_addr;
  server = gethostbyname(hostname);
  if (server == NULL)
    printf("Warning: can't find host for socket %d: %s\n", sock, strerror(errno));
  bzero((char *) &serv_addr, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  bcopy((char *)server->h_addr,
	(char *)&serv_addr.sin_addr.s_addr,
	server->h_length);
  serv_addr.sin_port = htons(portNum);
  if (connect(socks[sock],(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0)
    {
      printf("Warning: can't connect socket %d: %s\n", sock, strerror(errno));
      shutdown(socks[sock], SHUT_RDWR);
      socks[sock] = -1;
    } else {
    sfiles[sock] = fdopen(socks[sock], "r");
    //pthread_mutex_init(&smutex[sock], NULL);
    FD_SET(socks[sock], &files);
  }


  return 1;
}


//send data
int r_send(char *line, int sock) {
  if (socks[sock] == -1) return 0;
  int i=strlen(line);
  //  line[i]='\0';
  if(verbose){
    printf("Getting: %s", line);
  }
  if(write(socks[sock], line,i )<0){
    return 0;
  }

  return 1;
}


//for con I suggest debugging with debug.txt, each request is unique per socker 
//ie only socket 1 will ask for www.cs.cmu.edu/ and only 2 for www.cs.cmu.edu/~213/
int main(int argc, char *argv[]) {

  trace=calloc(1, 64);
  progname = argv[0];
  ArgParser* ap = createArgumentParser(&argp);
  //  addArgumentParser(ap, (ArgDefs*)getProbDistArgParsing(), 0);
  int ok = parseArguments(ap, argc, argv);
  if (ok) die("Error parsing arguments");

  if(echo){
    for (int a=0;a<argc;a++){
      printf("%s ",argv[a]);
    }
    printf("\n");
  }
  if(proxy+email!=1){
    printf("Must specify --proxy or --email (and not both)!\n");
    return 0;
  }

  if(rseed){
    srand(rseed);
  }
  else{
  srand(time(NULL));
  }
  int i;
  for (i = 0; i < maxReq; i++) {
    socks[i] = -1;
  }
  FD_ZERO(&files);


  if(email){
    eUsers=calloc(nthreads, sizeof(char*));
    for(int i =0;i<nthreads;i++){
      eUsers[i]=calloc(16, sizeof(char));
      for(int j=0;j<5;j++){
	eUsers[i][j]=(rand()%26)+65;
      }
    }
    if(sorts+sends!=100&&(!waitres)){
      fprintf(stderr,"Must specify percentages for sorts and sends!\n");
      return -1;
    }
    for(i=0;i<nthreads;i++){
      if(!r_connect_email(i)){
	fprintf(stderr,"Error connecting to email server on port %d\n", portNum);
      }
    }
    sleep(2);
      initBarrier(&loopBarrier);
      initBarrier(&endLoopBarrier);
      //    }

    int numcores=sysconf(_SC_NPROCESSORS_ONLN);
    int read_core=20, write_core=10;
    int modv=22;
  
    pthread_t* threadids_r = (pthread_t*)calloc(nthreads, sizeof(pthread_t));
    pthread_t* threadids_w = (pthread_t*)calloc(nthreads, sizeof(pthread_t));
    struct timeval** writerTimes=calloc(nthreads, sizeof(struct timeval*));
    struct timeval** readerTimes=calloc(nthreads, sizeof(struct timeval*));
    int** sortSize=calloc(nthreads, sizeof(int*));

    for(i=0;i<nthreads;i++){

      sortSize[i]=calloc(nreqs, sizeof(int));
      writerTimes[i]=calloc(2*nreqs, sizeof(struct timeval));
      readerTimes[i]=calloc(2*nreqs, sizeof(struct timeval));
    }
    if(!waitres){
      for(i =0; i<nthreads; i++) {
	pthread_attr_t attr;
	int result = pthread_attr_init(&attr);
	if (result) errdie("Can't do attr_init");

	// allocate each thread on its own core
	cpu_set_t cpuset;
	CPU_ZERO(&cpuset);
	CPU_SET(read_core, &cpuset);
    
	result = pthread_attr_setaffinity_np(&attr, sizeof(cpu_set_t), &cpuset);
	if (result) die("setaffinitity fails: %d", result);


	targs* temp_args=(targs*)malloc(sizeof(targs));
	temp_args->timesR=readerTimes[i];
	temp_args->tid=i;
	temp_args->isCache=(char*)sortSize[i];
	result = pthread_create(&threadids_r[i], &attr, ereader, (void*)temp_args);
	if (result) errdie("Can't create threads");
	pthread_attr_destroy(&attr);
      }

      for(i =0; i<nthreads; i++) {
	pthread_attr_t attr;
	int result = pthread_attr_init(&attr);
	if (result) errdie("Can't do attr_init");

	// allocate each thread on its own core
	cpu_set_t cpuset;
	CPU_ZERO(&cpuset);
	CPU_SET(write_core, &cpuset);
    
	result = pthread_attr_setaffinity_np(&attr, sizeof(cpu_set_t), &cpuset);
	if (result) die("setaffinitity fails: %d", result);
    
	targs* temp_args=(targs*)malloc(sizeof(targs));
	temp_args->timesW=writerTimes[i];
	temp_args->tid=i;
    
	result = pthread_create(&threadids_w[i], &attr, ewriter, (void*)temp_args);
	if (result) errdie("Can't create threads");
	pthread_attr_destroy(&attr);
      }
    }
else{
      for(i =0; i<nthreads; i++) {
	pthread_attr_t attr;
	int result = pthread_attr_init(&attr);
	if (result) errdie("Can't do attr_init");

	// allocate each thread on its own core
	cpu_set_t cpuset;
	CPU_ZERO(&cpuset);
	CPU_SET(write_core+(i%modv), &cpuset);
    
	result = pthread_attr_setaffinity_np(&attr, sizeof(cpu_set_t), &cpuset);
	if (result) die("setaffinitity fails: %d", result);
    
	targs* temp_args=(targs*)malloc(sizeof(targs));
	temp_args->tid=i;
	temp_args->timesR=readerTimes[i];
	temp_args->timesW=writerTimes[i];
	temp_args->isCache=(char*)sortSize[i];
	result = pthread_create(&threadids_w[i], &attr, esendnwait, (void*)temp_args);
	if (result) errdie("Can't create threads");
	pthread_attr_destroy(&attr);
      }
 }

    for(i=0;i<nthreads;i++){
      pthread_join(threadids_w[i], NULL);
    }
    if(!waitres){
    for(i=0;i<nthreads;i++){
      pthread_join(threadids_r[i], NULL);
    }
    }


    gettimeofday(&endRun, NULL);
    double secs=((double)difftimevals(endRun, startRun))/1000000.0;
    double mod=1.0;
    if(secs!=0){
      mod=1.0/secs;
    }
    double sItems=((double)nreqs*nthreads)*mod;
    printf("Requests/Sec: %lf\n", sItems);
    char q[8]="quit\n";
    for(i =0;i<nthreads;i++){
      if(!r_send(q, i)){
	fprintf(stderr,"Error sending quit\n");
      }
    }


    if(!nodata){
    char res[32]="";
    for(int j=0;j<nthreads;j++){
      if(prio){
      sprintf(res,"edata_prio/data%d.txt",j);
      }
      else{
      sprintf(res,"edata_noprio/data%d.txt",j);
      }
      FILE* fp =fopen(res,"a");
      if(echo){
	for (int a=0;a<argc;a++){
	  fprintf(fp,"%s ",argv[a]);
	}
	fprintf(fp,"\nRequests/Sec: %lf\n", sItems);
      }
      unsigned long* ulr=(unsigned long*)readerTimes[j], *ulw=(unsigned long*)writerTimes[j];
      i=0;
      while(ulr[(i<<1)]&&ulr[(i<<1)+1]&&ulw[(i<<1)]&&ulw[(i<<1)+1]&&i<nreqs){
	  
	   
	//else{ 
   	    fprintf(fp,"Msgs: "); 
	    fprintf(fp,"%d: %ld us\n", i, difftimevals(readerTimes[j][i],writerTimes[j][i])); 
	    //} 
	    i++;
      }
      i=nreqs;
      while(ulr[(i<<1)]&&ulr[(i<<1)+1]&&ulw[(i<<1)]&&ulw[(i<<1)+1]){
	if(sortSize[j][i-nreqs]){ 
	  fprintf(fp,"Sort: %d ",sortSize[j][i-nreqs]); 
	  fprintf(fp,"%d: %ld us\n", i-nreqs, difftimevals(readerTimes[j][i],writerTimes[j][i])); 

	}
	i++;
      }
       fprintf(fp,"---------------------------------------\n"); 
       fflush(fp); 
       fclose(fp); 
    } 
    }
  }
  if(proxy){
  FILE* in=fopen(trace, "r");
  char input[reqSize+4]="GET ";

    for(i=0;i<nthreads;i++){
      if(!r_connect_proxy(i)){
	fprintf(stderr,"Error connecting to proxy server on port %d\n", portNum);
      }
    }
  char** requests=calloc(sites, sizeof(char*));
  int re=0;
  char* buf=calloc(READLINE+16,sizeof(char));
  for(i=0;i<sites;i++){
    requests[i]=calloc(reqSize, sizeof(char));
    if(fgets(input+4, reqSize, in)){
      
      strcpy(requests[i], input);
      if(prefetch){

	r_send(requests[i], 0);
	int tread=0;
	while(1){
	  re=read(socks[0], buf, READLINE);
	  if(verbose>1){
	    printf("re=%d\n", re);
	  }
	  if(re<1){
	    fprintf(stderr,"Error reading\n");
	    break;
	  }
	  int b=0;
	  tread+=re;
	  for(int j=0;j<re;j++){
	    if(buf[j]==2){
	      b=1;
	    }
	    if(buf[j]==3){
	      b=1;
	    }
	  }
	  if(b){
	    break;
	  }
	}
      }
    }
  }
    struct timeval** writerTimes=calloc(nthreads, sizeof(struct timeval*));
    struct timeval** readerTimes=calloc(nthreads, sizeof(struct timeval*));
    char** isCache=calloc(nthreads, sizeof(char*));
    int** rsize=calloc(nthreads, sizeof(int*));
    for(i=0;i<nthreads;i++){
      rsize[i]=calloc(nreqs, sizeof(int));
      isCache[i]=calloc(nreqs, sizeof(char));
      writerTimes[i]=calloc(nreqs, sizeof(struct timeval));
      readerTimes[i]=calloc(nreqs, sizeof(struct timeval));
    }
    //    if(!waitres){
      //initBarrierN(&loopBarrier, 2*nthreads);
      //      initBarrierN(&endLoopBarrier,2*nthreads);
      //    }
      //    else{
      initBarrier(&loopBarrier);
      initBarrier(&endLoopBarrier);
      //    }

    int numcores=sysconf(_SC_NPROCESSORS_ONLN);
    int read_core=30, write_core=10;
    int modv=22;
  
    pthread_t* threadids_r = (pthread_t*)calloc(nthreads, sizeof(pthread_t));
    pthread_t* threadids_w = (pthread_t*)calloc(nthreads, sizeof(pthread_t));
    if(!waitres){
      for(i =0; i<nthreads; i++) {
	pthread_attr_t attr;
	int result = pthread_attr_init(&attr);
	if (result) errdie("Can't do attr_init");

	// allocate each thread on its own core
	cpu_set_t cpuset;
	CPU_ZERO(&cpuset);
	CPU_SET(read_core, &cpuset);
    
	result = pthread_attr_setaffinity_np(&attr, sizeof(cpu_set_t), &cpuset);
	if (result) die("setaffinitity fails: %d", result);


	targs* temp_args=(targs*)malloc(sizeof(targs));
	temp_args->timesR=readerTimes[i];
	temp_args->tid=i;
	temp_args->isCache=isCache[i];
	result = pthread_create(&threadids_r[i], &attr, preader, (void*)temp_args);
	if (result) errdie("Can't create threads");
	pthread_attr_destroy(&attr);
      }
      for(i =0; i<nthreads; i++) {
	pthread_attr_t attr;
	int result = pthread_attr_init(&attr);
	if (result) errdie("Can't do attr_init");

	// allocate each thread on its own core
	cpu_set_t cpuset;
	CPU_ZERO(&cpuset);
	CPU_SET(write_core, &cpuset);
    
	result = pthread_attr_setaffinity_np(&attr, sizeof(cpu_set_t), &cpuset);
	if (result) die("setaffinitity fails: %d", result);
    
	targs* temp_args=(targs*)malloc(sizeof(targs));
	temp_args->requests=requests;
	temp_args->timesW=writerTimes[i];
	temp_args->tid=i;
    
	result = pthread_create(&threadids_w[i], &attr, pwriter, (void*)temp_args);
	if (result) errdie("Can't create threads");
	pthread_attr_destroy(&attr);
      }


    } else{
      for(i =0; i<nthreads; i++) {
	pthread_attr_t attr;
	int result = pthread_attr_init(&attr);
	if (result) errdie("Can't do attr_init");

	// allocate each thread on its own core
	cpu_set_t cpuset;
	CPU_ZERO(&cpuset);
	CPU_SET(write_core+(i%modv), &cpuset);
	//	printf("Core: %d\n", write_core+(i%modv));
	result = pthread_attr_setaffinity_np(&attr, sizeof(cpu_set_t), &cpuset);
	if (result) die("setaffinitity fails: %d", result);
    
	targs* temp_args=(targs*)malloc(sizeof(targs));
	temp_args->requests=requests;
	temp_args->tid=i;
	temp_args->timesR=readerTimes[i];
	temp_args->timesW=writerTimes[i];
	temp_args->isCache=isCache[i];
	temp_args->rsize=rsize[i];
	result = pthread_create(&threadids_w[i], &attr, sendnwait, (void*)temp_args);
	if (result) errdie("Can't create threads");
	pthread_attr_destroy(&attr);
      }
    }
    // threads are all launched, now wait til they are all done

    // clean them up
    for(i=0;i<nthreads;i++){
      pthread_join(threadids_w[i], NULL);
    }
    if(!waitres){
    for(i=0;i<nthreads;i++){
      pthread_join(threadids_r[i], NULL);
    }
    }
  
    gettimeofday(&endRun, NULL);
      double secs=((double)difftimevals(endRun, startRun))/1000000.0;
      double mod=1.0;
      if(secs!=0){
      mod=1.0/secs;
      }
      double sItems=((double)nreqs*nthreads)*mod;
      printf("Requests/Sec: %lf\n", sItems);
    char q[8]="quit\n";
    for(i =0;i<nthreads;i++){
      if(!r_send(q, i)){
	fprintf(stderr,"Error sending quit\n");
      }
    }
    if(!nodata){
    char res[32]="";
    for(int j=0;j<nthreads;j++){
      if(prio){
      sprintf(res,"pdata_prio/data%d.txt",j);
      }
      else{
      sprintf(res,"pdata_noprio/data%d.txt",j);
      }
      FILE* fp =fopen(res,"a");
      if(echo){
	for (int a=0;a<argc;a++){
	  fprintf(fp,"%s ",argv[a]);
	}
	fprintf(fp,"\nRequests/Sec: %lf\n", sItems);
      }
      unsigned long* ulr=(unsigned long*)readerTimes[j], *ulw=(unsigned long*)writerTimes[j];
      for(i=0;i<nreqs;i++){
	if(ulr[(i<<1)]&&ulr[(i<<1)+1]&&ulw[(i<<1)]&&ulw[(i<<1)+1]){
	  if(isCache[j][i]==1){ 
   	    fprintf(fp,"Hit:  "); 
   	  } 
   	  else if(isCache[j][i]==2){ 
   	    fprintf(fp,"Miss: "); 
   	  } 
   	  else{ 
   	    fprintf(fp,"Error: "); 
   	  } 
   	  fprintf(fp,"%d: %d %ld us\n", i, rsize[j][i], difftimevals(readerTimes[j][i],writerTimes[j][i])); 
   	} 
       } 
       fprintf(fp,"---------------------------------------\n"); 
       fflush(fp); 
       fclose(fp); 
     } 
    }
  }
     return 0; 

}

   void* preader(void* arg){ 
     targs* targ=(targs*)arg; 
     int tid=targ->tid; 
     struct timeval* times=targ->timesR; 
     char* isCache=targ->isCache; 
     free(arg); 
     int re=0; 
     char* buf=calloc(READLINE+16, sizeof(char)); 
     int totalRead=0; 
     //  struct timeval t; 
     while(1){ 
      re=read(socks[tid], buf, READLINE);
	  if(verbose>1){
	    printf("re=%d\n", re);
	  }
      if(re<1){
	printf("Error reading from %d\n", tid);
	return NULL;
      }
      for(int i =0;i<re;i++){
	if(buf[i]==2){
	  isCache[totalRead]=2;
	  gettimeofday(&times[totalRead], NULL);
	  totalRead++;
	}
	if(buf[i]==3){
	  isCache[totalRead]=1;
	  gettimeofday(&times[totalRead], NULL);
	  totalRead++;
	}
      }
      if(verbose>1){
	printf("%d: %d\n", tid, totalRead);
      }
      if(totalRead>=nreqs){
	return NULL;
      }
    }
    return NULL;
  }


int isFull(char* buf, int size, int re){
  while(size<re){
    if(buf[size]==2||buf[size]==3){
      return 1;
    }
    size++;
  }
  return 0;
}
void myStrcpy(char* buf, char* tar, int i, int re){
  int z=0;
  while(buf[i]!=2&&buf[i]!=3&&i<re&&buf[i]){
    tar[z]=buf[i];
    i++;
    z++;
  }
}
int myAtoi(char* buf, int i){
  char temp[8]="";
  int p=0;
  while(buf[i]!=2&&buf[i]!=3){
    temp[p]=buf[i];
    p++;
    i++;
  }
  return atoi(temp);
}
   void* ereader(void* arg){ 
     targs* targ=(targs*)arg; 
     int tid=targ->tid; 
     struct timeval* times=targ->timesR; 
     int* sortSize=(int*)targ->isCache; 
     free(arg); 
     int re=0; 
     char* buf=calloc(READLINE+16, sizeof(char)); 
     int mRead=0, sRead=0; 
     int addPrev=0;
     char prevSort[8]="";
     //  struct timeval t; 
     while(1){ 
      re=read(socks[tid], buf, READLINE);
	  if(verbose>1){
	    printf("re=%d\n", re);
	  }
      if(re<1){
	printf("Error reading from %d\n", tid);
	return NULL;
      }
      for(int i =0;i<re;i++){

	if(buf[i]==2){

	  gettimeofday(&times[sRead+nreqs], NULL);
	  if(addPrev){
	    int len=strlen(prevSort);
	    for(int p=0;p<i;p++){

	      prevSort[len+p]=buf[p];
	    }
	    addPrev=0;
	    sortSize[(sRead)-1]=atoi(prevSort);
	    memset(prevSort,0,8);
	  }
	  if(isFull(buf, i+1, re)){
	    sortSize[(sRead)]=myAtoi(buf,i+1);
	  }
	  else{

	    myStrcpy(buf, prevSort, i+1, re);
	    addPrev=1;
	  }
	  sRead++;
	}
	if(buf[i]==3){
	  gettimeofday(&times[mRead], NULL);
	  if(addPrev){
	    int len=strlen(prevSort);
	    for(int p=0;p<i;p++){

	      prevSort[len+p]=buf[p];
	    }
	    addPrev=0;
	    sortSize[(sRead)-1]=atoi(prevSort);
	    memset(prevSort,0,8);
	  }
	  mRead++;
	}
      }
      if(verbose>1){
	printf("%d: %d\n", tid, (sRead+mRead));
      }
      if((sRead+mRead)>=nreqs){
	if(addPrev){
	  sortSize[(sRead)-1]=atoi(prevSort);
	}
	return NULL;
      }
    }
    return NULL;
  }

  void* pwriter(void* arg){
    targs* args=(targs*)arg;
    int tid=args->tid;
    char** requests=(char**)args->requests;
    struct timeval* times=args->timesW;
    free(args);

    int do_req=1;
    int items=0;
    //  struct timeval t;
    int totalRead=0;
    startBarrier(tid);
    if(max){
      for(int i =0;i<nreqs;i++){
	gettimeofday(&times[i], NULL);
	if(!r_send(requests[random()%sites], tid)){
	  fprintf(stderr,"Failed to send to proxy server\n");
	}

      }
    }
    else if(poisson){
      for(int i =0;i<nreqs;i++){
	usleep(1000000.0*nextTime((float)rps));
	gettimeofday(&times[i], NULL);
	if(!r_send(requests[random()%sites], tid)){
	  fprintf(stderr,"Failed to send to proxy server\n");
	}

      }
    }
    else{
      struct timeval startTime, curTime;
      suseconds_t startUS, curUS;
      gettimeofday(&startTime, NULL);
      startUS=to_usecs(startTime);
      int reqSent=0;
      for(int i =0;i<nreqs;i++){
	gettimeofday(&times[i], NULL);
	if(!r_send(requests[random()%sites], tid)){
	  fprintf(stderr,"Failed to send to proxy server\n");
	}

	reqSent++;
	if(reqSent==rps){
	  reqSent=0;
	  gettimeofday(&curTime, NULL);
	  curUS=to_usecs(curTime);
	  if(curUS<startUS){
	    printf("Error in Times\n");
	    return 0;
	  }
	  if(curUS-startUS<1000000){
	    printf("Sleep for %ld us\n", 1000000-(curUS-startUS));
	    usleep(1000000-(curUS-startUS));
	    gettimeofday(&startTime, NULL);
	    startUS=to_usecs(startTime);
	  }
	}
      }
    }
    endBarrier(tid);
    return NULL;
  }




  void* ewriter(void* arg){
    targs* args=(targs*)arg;
    int tid=args->tid;
    struct timeval* times=args->timesW;
    free(args);

    int do_req=1;
    int items=0;
    //  struct timeval t;
    int totalRead=0;
    startBarrier(tid);
    char request[reqSize]="";
    int sWrite=0, mWrite=0;
    if(max){
      for(int i =0;i<nreqs;i++){
	int todo=random()%100;
	if(todo<sends){
	  sprintf(request,"send\n%s\ns%d\nm%d\n", eUsers[random()%nthreads], mWrite, mWrite);
	  gettimeofday(&times[sWrite], NULL);
	  mWrite++;
	}
	else{
	  int sortType=random()%4;
	  if(sortType==0){
	    sprintf(request,"s from\n");
	  }
	  else if(sortType==1){
	    sprintf(request,"s to\n");
	  }
	  else if(sortType==2){
	    sprintf(request,"s date\n");
	  }
	  else{
	    sprintf(request,"s subj\n");
	  }
	  gettimeofday(&times[sWrite+nreqs], NULL);
	  sWrite++;
	}

	if(!r_send(request, tid)){
	  fprintf(stderr,"Failed to send to proxy server\n");
	}

      }
    }
    else if(poisson){
      for(int i =0;i<nreqs;i++){
	usleep(1000000.0*nextTime((float)rps));
	int todo=random()%100;
	if(todo<sends){
	  sprintf(request,"send\n%s\ns%d\nm%d\n", eUsers[random()%nthreads], sWrite, sWrite);
	  gettimeofday(&times[sWrite], NULL);
	  sWrite++;
	}
	else{
	  int sortType=random()%4;
	  if(sortType==0){
	    sprintf(request,"s from\n");
	  }
	  else if(sortType==1){
	    sprintf(request,"s to\n");
	  }
	  else if(sortType==2){
	    sprintf(request,"s date\n");
	  }
	  else{
	    sprintf(request,"s subj\n");
	  }
	  gettimeofday(&times[mWrite+nreqs], NULL);
	  mWrite++;
	}

	if(!r_send(request, tid)){
	  fprintf(stderr,"Failed to send to proxy server\n");
	}

      }
    }
    else{
      struct timeval startTime, curTime;
      suseconds_t startUS, curUS;
      gettimeofday(&startTime, NULL);
      startUS=to_usecs(startTime);
      int reqSent=0;
      for(int i =0;i<nreqs;i++){
	int todo=random()%100;
	if(todo<sends){
	  sprintf(request,"send\n%s\ns%d\nm%d\n", eUsers[random()%nthreads], sWrite, sWrite);
	  gettimeofday(&times[sWrite], NULL);
	  sWrite++;
	}
	else{
	  int sortType=random()%4;
	  if(sortType==0){
	    sprintf(request,"s from\n");
	  }
	  else if(sortType==1){
	    sprintf(request,"s to\n");
	  }
	  else if(sortType==2){
	    sprintf(request,"s date\n");
	  }
	  else{
	    sprintf(request,"s subj\n");
	  }
	  gettimeofday(&times[mWrite+nreqs], NULL);
	  mWrite++;
	}
	if(!r_send(request, tid)){
	  fprintf(stderr,"Failed to send to proxy server\n");
	}

	reqSent++;
	if(reqSent==rps){
	  reqSent=0;
	  gettimeofday(&curTime, NULL);
	  curUS=to_usecs(curTime);
	  if(curUS<startUS){
	    printf("Error in Times\n");
	    return 0;
	  }
	  if(curUS-startUS<1000000){
	    printf("Sleep for %ld us\n", 1000000-(curUS-startUS));
	    usleep(1000000-(curUS-startUS));
	    gettimeofday(&startTime, NULL);
	    startUS=to_usecs(startTime);
	  }
	}
      }
    }
    endBarrier(tid);
    return NULL;
  }


  void* sendnwait(void* arg){
    targs* args=(targs*)arg;
    int tid=args->tid;
    char** requests=(char**)args->requests;
    char* isCache=args->isCache;
    struct timeval* rtimes=args->timesR;
    struct timeval* wtimes=args->timesW;
    int* rsize=args->rsize;
    free(args);
    int do_req=1;
    int items=0;
    int re=0;
    char* buf=calloc(READLINE+16, sizeof(char));
    startBarrier(tid);

    if(max){

      for(int i =0;i<nreqs;i++){
	int index=random()%sites;
	if(!r_send(requests[index], tid)){
	  fprintf(stderr,"Failed to send to proxy server\n");
	}

	gettimeofday(&wtimes[i],NULL);
	int tread=0;
	while(1){
	  re=read(socks[tid], buf, READLINE);
	  if(verbose>1){
	    printf("re=%d\n", re);
	  }
	  if(re<1){
	    fprintf(stderr,"Error reading\n");
	    break;
	  }
	
	  volatile int b=0;
	  tread+=re;
	  for(int j=0;j<re;j++){
	    if(buf[j]==2){
	      if(verbose){
		printf("Got: %s\n", requests[index]);
	      }
	      gettimeofday(&rtimes[i],NULL);
	      isCache[i]=2;
	      b=1;
	    }
	    if(buf[j]==3){
	      if(verbose){
		printf("Got: %s\n", requests[index]);
	      }
	      gettimeofday(&rtimes[i],NULL);
	      isCache[i]=1;
	      b=1;
	    }
	    if(buf[j]==4){
	      //	      if(verbose){
		printf("[E]Got: %s\n", requests[index]);
		//	      }
	      gettimeofday(&rtimes[i],NULL);
	      isCache[i]=3;
	      b=1;
	    }
	  }
	  if(b){
	    rsize[i]=tread;
	    break;
	  }
	}

      }
    }
    else if(poisson){

      for(int i =0;i<nreqs;i++){
	usleep(1000000.0*nextTime((float)rps));
	int index=random()%sites;
	if(!r_send(requests[index], tid)){
	  fprintf(stderr,"Failed to send to proxy server\n");
	}
	gettimeofday(&wtimes[i],NULL);
	while(1){
	  re=read(socks[tid], buf, READLINE);
	  if(verbose>1){
	    printf("re=%d\n", re);
	  }
	  if(re<1){
	    fprintf(stderr,"Error reading\n");
	    break;
	  }
	
	  int b=0;
	  for(int j=0;j<re;j++){
	    if(buf[j]==2){
	      if(verbose){
		printf("Got: %s\n", requests[index]);
	      }
	      gettimeofday(&rtimes[i],NULL);
	      isCache[i]=2;
	      b=1;
	    }
	    if(buf[j]==3){
	      if(verbose){
		printf("Got: %s\n", requests[index]);
	      }
	      gettimeofday(&rtimes[i],NULL);
	      isCache[i]=1;
	      b=1;
	    }
	  }
	  if(b){
	    break;
	  }
	}

      }
    }

    else{
      struct timeval startTime, curTime;
      suseconds_t startUS, curUS;
      gettimeofday(&startTime, NULL);
      startUS=to_usecs(startTime);
      int reqSent=0;
      for(int i =0;i<nreqs;i++){
	int index=random()%sites;
	if(!r_send(requests[index], tid)){
	  fprintf(stderr,"Failed to send to proxy server\n");
	}
	gettimeofday(&wtimes[i],NULL);
	while(1){
	  re=read(socks[tid], buf, READLINE);
	  if(verbose>1){
	    printf("re=%d\n", re);
	  }
	  if(re<1){
	    fprintf(stderr,"Error reading\n");
	    break;
	  }
	  int b=0;
	  for(int j=0;j<re;j++){
	    if(buf[j]==2){
	      if(verbose){
		printf("Got: %s\n", requests[index]);
	      }
	      gettimeofday(&rtimes[i],NULL);
	      isCache[i]=2;
	      b=1;
	    }
	    if(buf[j]==3){
	      if(verbose){
		printf("Got: %s\n", requests[index]);
	      }
	      gettimeofday(&rtimes[i],NULL);
	      isCache[i]=1;
	      b=1;
	    }
	  }
	  if(b){
	    break;
	  }
	}
	reqSent++;
	if(reqSent==rps){
	  reqSent=0;
	  gettimeofday(&curTime, NULL);
	  curUS=to_usecs(curTime);
	  if(curUS<startUS){
	    printf("Error in Times\n");
	    return 0;
	  }
	  if(curUS-startUS<1000000){
	    printf("Sleep for %ld us\n", 1000000-(curUS-startUS));
	    usleep(1000000-(curUS-startUS));
	    gettimeofday(&startTime, NULL);
	    startUS=to_usecs(startTime);
	  }
	}
      }
    }
    endBarrier(tid);
    return NULL;
  }
  void* esendnwait(void* arg){
    targs* args=(targs*)arg;
    int tid=args->tid;

    int* sortSize=(int*)args->isCache;
    struct timeval* rtimes=args->timesR;
    struct timeval* wtimes=args->timesW;
    free(args);
    char request[reqSize]="";
    int do_req=1;
    int items=0;
    int re=0;
    char* buf=calloc(READLINE+16, sizeof(char));



        sprintf(request,"send\n%s\ns%d\nm%d\n", eUsers[tid],tid ,tid);
	if(!r_send(request, tid)){
	  fprintf(stderr,"Failed to send to proxy server\n");
	}

	volatile int b=0;
	while(1){
	  re=read(socks[tid], buf, READLINE);
	  if(verbose>1){
	    printf("re=%d\n", re);
	  }
	  if(re<1){
	    printf("Error reading from %d\n", tid);
	    return NULL;
	  }
	  for(int i =0;i<re;i++){
	    if(buf[i]==3){
	      b=1;
	    }
	  }
	  if(b){
	    break;
	  }
	  
	}



    startBarrier(tid);
    int mWrite=0, sWrite=0, sRead=0, mRead=0;
     int addPrev=0;
     char prevSort[8]="";
    if(max){
      for(int i =0;i<nreqs;i++){
	if(i%100||(!i)){
	sprintf(request,"send\n%s\ns%d\nm%d\n", eUsers[random()%nthreads],mWrite, mWrite);
	gettimeofday(&wtimes[mWrite], NULL);
	mWrite++;
	}
	else{
	  int sortType=random()%4;
	  sortType=2;
	  if(sortType==0){
	    sprintf(request,"s from\n");//send\n%s\ns%d\nm%d\n", eUsers[random()%nthreads],mWrite, mWrite);
	  }
	  else if(sortType==1){
	    sprintf(request,"s to\n");//send\n%s\ns%d\nm%d\n", eUsers[random()%nthreads],mWrite, mWrite);
	  }
	  else if(sortType==2){
	    sprintf(request,"s date\n");//send\n%s\ns%d\nm%d\n", eUsers[random()%nthreads],mWrite, mWrite);
	  }
	  else{
	    sprintf(request,"s subj\n");//send\n%s\ns%d\nm%d\n", eUsers[random()%nthreads],mWrite, mWrite);
	  }
	  gettimeofday(&wtimes[sWrite+nreqs], NULL);
	  //	  gettimeofday(&wtimes[mWrite], NULL);
	  sWrite++;
	  //	  mWrite++;
	}

	if(!r_send(request, tid)){
	  fprintf(stderr,"Failed to send to proxy server\n");
	}

	volatile int b=0;
	while(1){
	  re=read(socks[tid], buf, READLINE);
	  if(verbose>1){
	    printf("re=%d\n", re);
	  }
	  if(re<1){
	    printf("Error reading from %d\n", tid);
	    return NULL;
	  }
	  for(int i =0;i<re;i++){
	    
	    if(buf[i]==2){
	      b=1;
	      gettimeofday(&rtimes[nreqs+sRead], NULL);
	  if(addPrev){
	    int len=strlen(prevSort);
	    for(int p=0;p<i;p++){

	      prevSort[len+p]=buf[p];
	    }
	    addPrev=0;

	    sortSize[(sRead)-1]=atoi(prevSort);
	    memset(prevSort,0,8);
	  }
	  if(isFull(buf, i+1, re)){
	    sortSize[(sRead)]=myAtoi(buf,i+1);
	  }
	  else{
	    
	    myStrcpy(buf, prevSort, i+1, re);
	    addPrev=1;
	  }
	  sRead++;

	    }
	    if(buf[i]==3){
	      gettimeofday(&rtimes[mRead], NULL);
	      b=1;
	      if(addPrev){
		int len=strlen(prevSort);
		for(int p=0;p<i;p++){
		  
		  prevSort[len+p]=buf[p];
		}
	    addPrev=0;
	    sortSize[(sRead)-1]=atoi(prevSort);
	    memset(prevSort,0,8);
	      }
	      mRead++;
	    }
	  }
	  if(b){

	    if(addPrev){
	      sortSize[(sRead)-1]=atoi(prevSort);
	    }
	    break;
	  }
	  if(verbose>1){
	    printf("%d: %d\n", tid, (sRead+mRead));
	  }
	}
      }
    }
    endBarrier(tid);
    return NULL;
  }
