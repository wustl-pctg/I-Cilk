#!/bin/bash

foo=$(pidof $1); for w in $foo; do echo $w; kill -9 $w; done;
