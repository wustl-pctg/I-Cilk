#!/bin/bash
CILK_NWORKERS=20 ./../../bench/$1 --chunksize 1000 --bufsize 10 --dictsize 10 --port 6005 --cons $2 --bgsec $3 --quantlen $4 --cilkrho $5 --cilkutil $6 -v 0

