#!/bin/bash
CILK_NWORKERS=20 ./../../bench/$1 -f0 2 -f1 2 -f2 2 -f3 2 --duration 10
