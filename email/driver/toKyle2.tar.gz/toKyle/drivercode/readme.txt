Email:

./email -h will show you all arguments and a little description:
example run:
CILK_NWORKERS=20 ./eServer_prio --chunksize 1000 --bufsize 10 --dictsize 10 --port 6005 --cons 100 --bgsec 1 --quantlen 1000 --cilkrho 2 --cilkutil .9
(This can also be seen in re.sh which you can pass arguments to).

Dict/buf/chunk are all for compress/decompress so if running without those ignore.
cons is the amount of users that will connect to the server. bgsec is the period
of the background task (compression in this case). Right now its commented out.

to run the driver for the email server go to ~/interactive-cilk/drivercode/driver
./con -h will show all arguments and a little description
example run for email:
./con --port 6005 -t 100 --max --seed 100 --waitres --echo --prio --email --requests 500
--port is port to connect on, --max specifies that you are sleeping between requests (just request as soon as you get response). Echo just echos cmdline (i like this when running run.sh). --waitres specifies your waiting for response before sending next request. --prio says the data is priority data, --email says the data will be email data/runs an entirely different loop, --requests is the requests for EACH thread. -t is total number of connections (must equal what you run with server). --seed is for seeding srand().

Inside con.c search for modv and write_core. Write_core will be the lowest core that the driver will run on while modv will amount of cores so you might need to change those before running.


Data:

the data collection is pretty unfun. Data for email server will go to edata_prio or edata_noprio.
For each run each thread will get its own file named data<threadNum>.txt which will have the drivers cmdline followed by events and their respective times: i.e a line might say 'Msgs: <index>: <time> us'. These files hold the drivers times. Then there is utils.txt which has the times from the email server. This is formatted similarly with cmdline followed by compress times (if there are any) followed by avg util/maxutil/avg L. 
parse_times.c (gcc parse_times.c -o pt -lm) will parse these. usage: ./parsetimes path/to/prio/dir /path/to/noprio/dir
A few things to make sure of. First there are a few variables at the top you need to set (between '//set from here' and '//to here'. You need to give the amount of different rho vals/util vals/etc.. you are using and set what those values are in the corresponding arrays. The threads array must be in the order they are tested i.e if you test 50 then 100 cons, tVals must be {50,100} otherwise the code will break. Also set max_threads to the highest number of cons tests. Also you have to go to main and comment in/out whatever you are parsing. for email parseEmail is for email run with compress as bg task, parseEmail_ncmp is for email run without compress. If the code runs successfully it will print out what I was pasting in the google slides (you have to seperate one of the columns by spaces). If it doesn't work it will print error. if you see error print you probably won't be able to debug the code because its a mess so just msg me. The code is not robust but there is alot of error checking so if you don't see error things should be fine.






