#!/bin/bash
snum=256
rnum=90000
stime=2
ltime=5
verb=0
bgtime=3
dtime=50

./kp.sh proxySelf_prio;
./kp.sh proxySelf_noprio;
./kp.sh eServer_prio;
./kp.sh eServer_noprio;
./kp.sh jSched_prio;
./kp.sh jSched_noprio;

echo proxyPrio;

#for i in 90; do for j in .9; do for k in 2; do for qnL in 500; do screen -d -m ./rp.sh proxySelf_prio $i $i $bgtime $qnL $k $j;  sleep $stime; ./con --trace sites/source1.txt --sites $snum --requests $(($rnum/$i)) --port 6005 -t $i --max --proxy --seed $i --waitres --echo --prio;  sleep $ltime; ./kp.sh proxySelf_prio; done; done; done; done; 


echo proxyNoprio;

#for i in 90; do  screen -d -m ./rp.sh proxySelf_noprio $i $i $bgtime 0 0 0;  sleep $stime;  ./con --trace sites/source1.txt --sites $snum --requests $(($rnum/$i)) --port 6005 -t $i --max --proxy --seed $i --waitres --echo ;  sleep $ltime; ./kp.sh proxySelf_noprio; done; 

echo jobsPrio;

#for j in .9; do for k in 1.5; do for qnL in 1000; do for pv in 5; do  CILK_NWORKERS=40 ./../../bench/jSched_prio -f0 $pv -f1 $pv -f2 $pv -f3 $pv --seed 120 --duration $dtime --echo --quantlen $qnL --cilkrho $k --cilkutil $j; done; done; done; done;

echo jobsNoprio;

#for pv in 5; do  CILK_NWORKERS=40 ./../../bench/jSched_noprio -f0 $pv -f1 $pv -f2 $pv -f3 $pv --seed 120 --duration $dtime --echo --quantlen $qnL --cilkrho $k --cilkutil $j; done;


echo emailPrio;

#for i in 120 150 180;  do for j in .9; do for k in 2; do for qnL in 250; do screen -d -m ./re.sh eServer_prio $i $bgtime $qnL $k $j;  sleep $stime;  ./con --requests $(($rnum/$i)) --port 6005 -t $i --max --email --seed $i --waitres --echo --prio;  sleep $ltime; ./kp.sh eServer_prio; done; done; done; done; 

echo emailNoprio;

for i in 120 150 180; do screen -d -m ./re.sh eServer_noprio $i $bgtime 0 0 0;  sleep $stime;  ./con --requests $(($rnum/$i)) --port 6005 -t $i --max --email --seed $i --waitres --echo ;  sleep $ltime; ./kp.sh eServer_noprio; done; 
