#!/bin/bash

./start-docker.sh; cd bench; make;
