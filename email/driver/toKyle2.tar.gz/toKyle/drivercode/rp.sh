#!/bin/bash
CILK_NWORKERS=20 ./../../bench/$1 --seed $2 --real --port 6005 --cons $3 --bgsec $4 --quantlen $5 --cilkrho $6 --cilkutil $7
